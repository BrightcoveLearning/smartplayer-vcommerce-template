<?php

	$gUserName = "admin";
	$gPassword = "pass1";

	$username  = $_POST["username"];
	$password  = $_POST["password"];

					   
	if ($username= $gUserName && $password == $gPassword){
		setcookie("username", $username, time()+1200);
	}else{
		setcookie("username", "", time()-3600);

		echo '
		<HTML>
			<BODY>
				<FORM METHOD="POST" ACTION="index.php">
					<div class="LoginBox" style="width:200px; height:320px; border:solid 2px #8EBBBF; padding-left:70px; margin:150px auto;>
						<div class="Login">
							<H2>Login Page</H2>
							<BR><BR>
							User Name:
							<BR><INPUT TYPE="TEXT" NAME="username" SIZE="16">
							<BR><BR>
							Password:
							<BR><INPUT TYPE="PASSWORD" NAME="password" SIZE="16">
							<BR><BR> <BR><BR>
							<INPUT TYPE="SUBMIT" VALUE="Submit">
						</div>
					</div>
				</FORM>
				</div>
			</BODY>
		</HTML>';
		exit;
	}
?>

<!DOCTYPE html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" href="./js/jQuery-UI/jquery-ui.css" />
	<link href="./css/videoAdmin.css" type="text/css" rel="stylesheet" />
	<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
	<script src="./js/jQuery-UI/jquery-ui.js"></script>
	<script src="./js/config.js"></script>
	<script src="./js/jLanguage.js"></script>
<!-- Unpacked version -->
	<script src="./js/jjfw.util.js"></script>
	<script src="./js/videoAdmin.js"></script>
<!-- // Packed version
	<script src="./js/brObj.js"></script>
-->	
	<script>
		var BBS;
		onOverObj = function (id,onOff) {
			var o = document.getElementById(id);
			if(!o) return; if(!o.style) return;
			o.style.backgroundPositionX = (o.clientWidth*-1*onOff).toString()+"px"; 
		};
		init= function(){
			videoAdmin.init();
		};
	</script>
</head>

<body onload="init()" bgproperties="fixed" _ondragstart="return false" _oncontextmenu="return false"  _onselectstart="return false">
	<div class="headerBG1">
		<div class="logoBox">
			<div class="logo"></div>
		</div>
	</div>
	<div class="headerBG2">
		<div class="tabMenuBox">
			<div class="header">
				<div class="menuTab first">
					<div class="left"></div>
					<div class="middle"></div>
					<div class="right"></div>
				</div>
			</div>
		</div>
	</div>
	<div class="BBSMain">
		<div class="content">
			<div class="bbsContent">
				<div class="contentHeader">
					<div id="search">
						<input type="text" maxlength="128" name="search_form" id="edit-search-theme-form-3" size="15" value="" title="Enter the terms you wish to search for." class="form-text">
						<input type="submit" name="op" id="edit-submit-1" value="Search" class="form-submit" onmouseover="onOverObj(this.id,1)" onmouseout="onOverObj(this.id,0)">
					</div>
					<select id="selBox" name="selBox" class="selectBox">
						<option value="">Row Number</option>
						<option value="10" selected="selected">10 Row</option>
						<option value="15">15 Row</option>
						<option value="20">20 Row</option>
						<option value="25">25 Row</option>
						<option value="30">30 Row</option>
					</select>
					<div class="btn newRegisterBtn" >
						<div class="btn left"></div>
						<div class="btn middle"></div>
						<div class="btn right"></div>
					</div>
				</div>
				<div class="contentMiddle">
				</div>
				<div class="contentBottom">
				</div>
			</div>
		</div>
	</div>
	<div class="bottomBG">
		<div class="bottomContnet"></div>
	</div>	
	<div id="newRegister"></div>
	
	<div id="detailInfo" title="Cue Point"></div>

	<div id="cuePointModify"></div>
	<div id="confirmUpdate" title="Update"></div>
	<div id="cuePointConfirm" title="Cue Point Confirmation"></div>
	<div id="cuePointDelete" title="Cue Point Delete"></div>
	<div id="publish" title="Pub.Code"></div>
	<div id="delete" title="Delete"></div>
	<div id="cuePointPreview" title="Preview"></div>
	<div id="strLength" title="Caution"></div>
	<div id="cuePointView"></div>
	<div id="cueSave" title="Save"></div>

</body>

</html>