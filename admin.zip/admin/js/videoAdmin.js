/*todays
	
*/
if(!window['videoAdmin']) { 
	videoAdmin = {}; 
	( function (_O) {

		var _U = jjfwA.Util;
		var _L = jLanguage;
		
		_O.Vars = {
			bbsClassName:["Video","VideoLength","VideoName","CuePointList", "Tag", "ModifyDate", "CuePoint", "Publishing","Delete"],
			bbsTitleName:[_L.getMsg("Video"),_L.getMsg("VideoLength"),_L.getMsg("VideoName"),_L.getMsg("ItemText"), _L.getMsg("Tag"), _L.getMsg("LastModified"), _L.getMsg("CuePoint"), _L.getMsg("Publishing"), _L.getMsg("Delete")],
			eventClassName: [".newRegisterBtn", ".editBtn", ".bbsList.image", ".bbsList.videoLength", ".bbsList.videoName", ".bbsList.cuepointList",".bbsList.tag",".bbsList.modifyDate", ".publishBtn", ".listDeleteBtn"],
			mainBBSName:"main",
			
			stripslashes: function(str) {
				return str.replace(/\\'/g,'\'').replace(/\"/g,'"').replace(/\\\\/g,'\\').replace(/\\0/g,'\0');
			},
						
			getAttribute: function(o, str){
				if(!o) return '';
				var getId= o.getAttribute(str);
				return getId;
			},
			getCuepointList: function(idx){
				var itemText;
				var s='';
				if(_O.List.items[idx]['cuePoints']) {
					_O.List.items[idx]['cuePoints'] = _O.List.items[idx]['cuePoints'].sort(function(a, b) {return a.time - b.time;});
					for(var i=0; i<_O.List.items[idx]['cuePoints'].length; i++){
						itemText = _O.List.items[idx]['cuePoints'][i]['metadata'];
						
						if(itemText) {
							itemText = itemText.split("|");
						}
						if(_O.List.items[idx]['cuePoints'][i]['type'] == 1){
							s+=
								(itemText[2] ? itemText[2] : '') +'<br>';
						}
					}
				}
				return s;
			},
			getModifyDate:function(idx){
				var modifyDate = '';
				modifyDate = _getDate(_O.List.items[idx]['lastModifiedDate']);
				function _getDate(ms) {
					var date = new Date(parseInt(ms));
					return parseInt(1900+date.getYear(),10)+"."+_U.getTwoDigit(parseInt(date.getMonth()+1,10))+'.'+_U.getTwoDigit(parseInt(date.getDate(),10)) + '<br>' +_U.getTwoDigit(parseInt(date.getHours(),10)) + ':' +_U.getTwoDigit(parseInt(date.getMinutes(),10)) + ':' +_U.getTwoDigit(parseInt(date.getSeconds(),10));
				}
				return modifyDate;
			}
		};

		var v = _O.Vars;

		_O.init=function () {
			$("#selBox").val(gBrightCoveAPI.PageSize);
			_U.crateLoadingDialog();
			this.Dialog.setAllDialog();
			this.start();
		};
		_O.setEvent= function() {
			var v = _O.Vars;
			for(var i=0; i<v.eventClassName.length; i++){
				$(v.eventClassName[i]).on("click",function () { videoAdmin.Dialog.dialogClick(this); });
			}
			for(i=0; i<_O.List.getTotalPageNum(); i++){
				$(_U.Qs(".pageBox .page")[i]).on("click",{page:i,value:(_O.List.curSearchValue)},function (e) { videoAdmin.List.pageMove(e.data.page, e.data.value); });
			}
			$(".VideoName").on("click",function (e) { videoAdmin.List.oderList($(".VideoName")); });
			$(".ModifyDate").on("click",function (e) { videoAdmin.List.oderList($(".ModifyDate")); });	
			
			$(".pageBox .leftArrow").on("click",{page:(_O.List.curPage-1),value:(_O.List.curSearchValue)},function (e) { videoAdmin.List.pageMove(e.data.page,e.data.value); });
			$(".pageBox .rightArrow").on("click",{page:(_O.List.curPage+1),value:(_O.List.curSearchValue)},function (e) { videoAdmin.List.pageMove(e.data.page,e.data.value); });

			$("#selBox").on("change",function() {videoAdmin.List.changeSelBox();});

			$("#edit-submit-1").on("click", function (e) { videoAdmin.List.search($("#edit-search-theme-form-3").val(), 0); });

			$(document).keypress(function (e) {  
				if(e.which == 13 && e.target && e.target.id =='edit-search-theme-form-3' ) {
					videoAdmin.List.search($("#edit-search-theme-form-3").val(), 0);
				}
			});
		};

		
//// List /////	
		_O.List = {
			orderByIdx: 0,
			items: [],
			tags: [],
			deleteTagIdx: 0,
			page_number: 0,
			page_size: gBrightCoveAPI.PageSize,
			total_count:0,
			curPage:0,
			curSearchValue:'',
			haveMetadata:[],
			oderList: function(obj){
				this.setOrderByOption(obj);
				this.loadList(0,$("#edit-search-theme-form-3").val());
			},
			btnIdx:0,
			getTotalPageNum: function() {
				return parseInt((this.total_count-1)/this.page_size,10)+1;
			},
			setOrderByOption: function (obj) {
				if(obj.hasClass("VideoName")) {
					if(this.orderByIdx == 2) this.orderByIdx =3;
					else this.orderByIdx = 2;
				}else if(obj.hasClass("ModifyDate")) {
					if(this.orderByIdx == 0) this.orderByIdx =1;
					else this.orderByIdx = 0;
				}else {
					this.orderByIdx = 0;
				}
			},
			getOrderByOption: function (obj) {
				var str='';
				switch(this.orderByIdx) {
					case 0: str ='MODIFIED_DATE:DESC'; break;
					case 1: str ='MODIFIED_DATE'; break;
					case 2: str ='DISPLAY_NAME'; break;
					case 3: str ='DISPLAY_NAME:DESC'; break;
				}
				return "&sort_by="+str;
			},
			getReadUrl: function(pageSize,page,value){
				var api = gBrightCoveAPI;
				this.curSearchValue= (typeof value != 'undefined' ? value : '');
				var url = api.ApiBaseUrl+"?"+
					"command=search_videos"+
					"&all=tag:"+api.CMTV_Tag+
					(this.curSearchValue ? "&any=tag:ct_"+this.curSearchValue : '')+
					(this.curSearchValue ? "&any=display_name:"+this.curSearchValue : '')+
					(this.curSearchValue ? "&any="+this.curSearchValue : '')+
					this.getOrderByOption()+
					"&page_size="+pageSize+
					"&page_number="+page+
					"&media_delivery="+api.MediaDelivery+
					"&video_fields="+api.SearchFields+
					"&get_item_count=true"+
					"&token="+api.Token+
					"&callback=videoAdmin.List.onloadList"+
					"&r="+Math.random();
				return url;
			},
			getRefreshReadUrl: function(id){
				var api = gBrightCoveAPI;
				var url = api.ApiBaseUrl+"?"+
					"command=find_video_by_id"+
					"&video_id="+id+
					"&media_delivery="+api.MediaDelivery+
					"&video_fields="+api.SearchFields+
					"&token="+api.Token+
					"&callback=videoAdmin.List.onRefreshItem"+
					"&r="+Math.random();
				return url;
			},
			getWriteUrl: function(){
				var rv='';
				rv={
					url:"./api/write.php",
					callback:"jCallbacks.func.write",
					fError:"jCallbacks.func.write"
				};
				return rv;
			},
			refreshItem:function(id){
				var urlInfo = _O.List.getRefreshReadUrl(id);
				 _U.jcejs({url:urlInfo,fonerror:videoAdmin.List.jsOnError});				
			},
			loadList:function(page,value) {
				_O.List.init();
				_O.List.curPage = page;
				var urlInfo = _O.List.getReadUrl(_O.List.page_size,page,value);
				 _U.jcejs({url:urlInfo,fonerror:videoAdmin.List.jsOnError});
			},
			loadList2:function(J) {
				$('#Loader').dialog('close');
				if(J && J["result"] == null) {
					var msg = "Error: Input Value(s)";
					_U.showAlert({"message": msg });
					return;
				}

				var getId = _O.Vars.getAttribute(_U.Qs(".detailID .infoBox_1")[0], 'title');
				_O.List.curPage = 0;
				var urlInfo = _O.List.getRefreshReadUrl(getId);
				_U.jcejs({url:urlInfo,fonerror:videoAdmin.List.jsOnError});
			},
			jsOnError:function() {
			},
			onRefreshItem:function(J){
				$('#Loader').dialog('close');
				if(!J) {
					_U.showAlert({"message":"Sorry, Network error. Please try it again later."});
					// To DO...
					return;
				}
				_O.List.items=[];
				_O.List.items[0]=J;
				videoAdmin.Dialog.setDetailInfoDialogHtml(0);
			},
			onloadList:function(J) {
				$('#Loader').dialog('close');
				if(!J) {
					_U.showAlert({"message":"Sorry, Network error. Please try it again later."});
					// To DO...
					return;
				}
				_O.List.items= J["items"];
				_O.List.page_number= parseInt(J["page_number"],10);
				_O.List.page_size= parseInt(J["page_size"],10);
				_O.List.total_count = parseInt(J["total_count"],10);
				_O.setMainHtml();
				_O.List.checkPage();
			},
			writeItemTag: function(type){
				var v = _O.Dialog.Vars;
				switch(type){
					case "cm_tag":
						var value = document.getElementsByName("videoId_form")[0].value;
						var urlInfo = _O.List.getWriteUrl();
						var data ={
									"method":"update_video",
									"params":{
										"video":{
											"id":value,
											"tags":["cm_tv"]
										},
										"token":"#WRITE_TOKEN"
									}
								};
						var strData = JSON.stringify(data);
						jCallbacks.setFunc("write",videoAdmin.List.loadList2);
						$('#Loader').dialog('open');
						_U.jFormSubmit({url:urlInfo.url, data:{"JSONView":strData, callback:urlInfo.callback, fError: urlInfo.fError }});
						break;
					case "ct_tag":
						var itemTags = v.itemTags;
						var curTags = [];
						
						for(var j=0; j<v.ctTags.length; j++){
							if(v.ctTags[j].indexOf("ct_") == 0) curTags.push(v.ctTags[j]);
						}
						for(j=0; j<v.itemTags.length; j++){
							if(v.itemTags[j].indexOf("cm_tv") == 0) curTags.unshift(v.itemTags[j]);
						}
						var cueType = $(".detailInfo .cueTypeSelection").val();
						if(cueType && gCuePointType[cueType]!= 'undefined') {
							curTags.push(("cm_cuetype_"+cueType.toLowerCase()));
						}
						var playerType = $(".detailInfo .playerSelect").val();
						if(playerType && gPlayerType[playerType]!= 'undefined') {
							curTags.push(("cm_player_"+playerType.toLowerCase()));
						}
						
						var getId = _O.Vars.getAttribute(_U.Qs(".detailID .infoBox_1")[0], 'title');
						var referenceId = document.getElementsByName("referenceId")[0].value;
						
						var urlInfo = _O.List.getWriteUrl();
						var data ={
									"method":"update_video",
									"params":{
										"video":{
											"id":getId,
											"tags":curTags,
											"referenceId":referenceId
										},
										"token":"#WRITE_TOKEN"
									}
								};
						var strData = JSON.stringify(data);
						jCallbacks.setFunc("write",videoAdmin.List.loadList2);
						$('#Loader').dialog('open');
						_U.jFormSubmit({url:urlInfo.url, data:{"JSONView":strData, callback:urlInfo.callback, fError: urlInfo.fError }});
						break;
					case "cueSave":
						var urlInfo = _O.List.getWriteUrl();
						var getId = _O.Vars.getAttribute(_U.Qs(".detailID .infoBox_1")[0], 'title');
						var data= {
							"method": "update_video",
							"params": {
								"token" :"#WRITE_TOKEN",
								"video" : {
									"id": getId,
									"cuePoints": _O.List.haveMetadata
								}
							}
						};						
						var strData = JSON.stringify(data);
						jCallbacks.setFunc("write",videoAdmin.List.loadList2);
						$('#Loader').dialog('open');
						_U.jFormSubmit({url:urlInfo.url, data:{"JSONView":strData, callback:urlInfo.callback, fError: urlInfo.fError }});
						$( "#cuePointModify" ).dialog( "close" );
						break;
					case "cuePointDelete":
						var getId = _O.Vars.getAttribute(_U.Qs(".detailID .infoBox_1")[0], 'title');
						var urlInfo = _O.List.getWriteUrl();
						_O.List.haveMetadata.splice(_O.List.btnIdx,1);
						var add_modify = 1;
						videoAdmin.Dialog.setCuePointViewHtml(videoAdmin.Dialog.Vars.itemIdx,add_modify);
						break;
					case "remove_cm_tag":
						var videoId = _O.List.items[_O.List.deleteTagIdx]['id'];
						var urlInfo = _O.List.getWriteUrl();
						var deleteTag = [];
						var aliveTag = [];
						var found = false;
						for(var i=0; i<_O.List.items[_O.List.deleteTagIdx]['tags'].length; i++){
							found = false;
							if(_O.List.items[_O.List.deleteTagIdx]['tags'][i] == 'cm_tv'){
								found = true;
							}
							if(found){
								deleteTag.push(_O.List.items[_O.List.deleteTagIdx]['tags'][i]);
							}else{
								aliveTag.push(_O.List.items[_O.List.deleteTagIdx]['tags'][i]);
							}
						}
						var urlInfo = _O.List.getWriteUrl();
						var data ={
									"method":"update_video",
									"params":{
										"video":{
											"id":videoId,
											"tags":aliveTag
										},
										"token":"#WRITE_TOKEN"
									}
								};
						var strData = JSON.stringify(data);
						jCallbacks.setFunc("write",videoAdmin.List.loadList2);
						$('#Loader').dialog('open');
						_U.jFormSubmit({url:urlInfo.url, data:{"JSONView":strData, callback:urlInfo.callback, fError: urlInfo.fError }});
						break;
				}
			},
			
			search: function(value, page) {
				_O.List.curPage = page;
				$("#edit-submit-1").unbind("click");
				if(!value){
					var urlInfo = _O.List.getReadUrl(_O.List.page_size,page,0);
				}else{
					var urlInfo = _O.List.getReadUrl(_O.List.page_size,page,value);
				}
				//jCallbacks.setFunc("search",videoAdmin.List.onloadList);
				//_U.jFormSubmit(urlInfo);
				_U.jcejs({url:urlInfo,fonerror:videoAdmin.List.jsOnError});
			},
			pageMove: function(page,value) {
				if(page < 0) return;
				else if(page > (_O.List.getTotalPageNum()-1)) return;
				else this.loadList(page,value);
			},
			checkPage: function() {
				_U.Qs(".pageBox .page")[_O.List.curPage].style.color='red';
			},
			changeSelBox: function() {
				this.page_size= _U.Q(".selectBox").value;
				this.loadList(0);
			},
			setAscDesc: function(orderByIdx) {
				var s='';
				switch(orderByIdx){
					case 0:
						s='<div class="descending lastModifyDate"></div>';
						break;
					case 1:
						s='<div class="ascending lastModifyDate"></div>';
						break;
					case 2:
						s='<div class="ascending videoName"></div>';
						break;
					case 3:
						s='<div class="descending videoName"></div>';
						break;
				}
				return s;
			},
			init: function () {
				this.items = [];
				this.page_number =0;
				this.total_count=0;
				this.tags= [];
				this.curPage=0;
				this.curSearchValue='';
				this.haveMetadata=[];
				this.btnIdx=0;
				//this.deleteTagIdx=0;
			}
		};

		_O.start=function () {
			$(".header .menuTab .middle").html(_L.getMsg("Commerce"));
			$(".contentHeader .newRegisterBtn .middle").html(_L.getMsg("NewRegister"));
			_O.List.loadList(0);
		};
		_O.setMainHtml= function () {
			var v = _O.Vars;
			var o = _U.Q(".contentMiddle");
			if(!o) { 
				return;
			}
			var s='';
			s = _O.setBBSHtml(v.bbsClassName,v.bbsTitleName, v.mainBBSName);
			o.innerHTML = s;
			this.setPageHtml();
			this.setEvent();
			return;
		};
		_O.setBBSHtml= function (clsName, name, bbsName, idx, mode) {
			var v= this.Vars;
			var s='';
			s+=	'<div class="bbsTitle '+bbsName+'">';
			for(var i=0; i<clsName.length; i++){
				s+= '<div class="title">'+
						'<div class="left"></div>'+
						'<div class="middle '+ clsName[i]+'">'+name[i]+'</div>'+
						'<div class="right"></div>'+
					'</div>';
			}	
			if(bbsName == 'main'){
				s+=
					_O.List.setAscDesc(_O.List.orderByIdx);
			}
			s+=	'</div>';
			if(_O.List.items.length<=0){
				s+= _L.getMsg("SearchAlert");
			}else{
				if(typeof idx=='undefined'){
					for(i=0; i<_O.List.items.length; i++){
						s+=	'<div class="bbsListWrapper '+bbsName+'">';
							s+=	_O.setBBSContentHtml(bbsName, i);
						s+=	'</div>';
					}
				}else{
					if(_O.List.items[idx]["cuePoints"].length != 0){
						if(!mode){
							for(var i=0; i<_O.List.items[idx]["cuePoints"].length; i++){
								if(_O.List.items[idx]["cuePoints"][i]["type"]==1){
									_O.List.haveMetadata.push(//Info Dialog Open....
										{
											"name": _O.List.items[idx]["cuePoints"][i]["name"],
											"time": _O.List.items[idx]["cuePoints"][i]["time"],
											"type": 1,
											"metadata": _O.List.items[idx]["cuePoints"][i]["metadata"]
										}
									);
								}
							}
						}
					}
					if(_O.List.haveMetadata.length<=0){
						s+= '<div style="float:left; margin-left:375px;">'+_L.getMsg("CuePointAlert_3")+'</div>';
					}else{
						_O.List.haveMetadata = _O.List.haveMetadata.sort(function(a, b) {return a.time - b.time;});//time sort
						for(i=0; i<_O.List.haveMetadata.length; i++){
							s+=	'<div class="bbsListWrapper '+bbsName+'">';
								s+=	_O.setBBSContentHtml(bbsName, idx, i);
							s+=	'</div>';
						}
					}
				}
			}
			return s;
		};
		_O.setBBSContentHtml= function (bbsName, idx, itemIdx){
			var v = this.Vars;
			var tagValue=_O.List.items[idx]["tags"];
			var tags="";
			var ctTags=[];
			for(var i=0; i<tagValue.length; i++){
				if(tagValue[i].indexOf('ct_') == 0){//cm_tv exception
					ctTags.push(tagValue[i]);
				}
			}
			var tags= ctTags.join().replace(/ct_/gi,"");
			var s='';
			if(bbsName == 'main'){
				var imgUrl= _O.List.items[idx]["thumbnailURL"] ? _O.List.items[idx]["thumbnailURL"] : '';
				s+= '<div id="listBox_'+idx+'" class="bbsListBox">'+
						'<div idx="'+idx+'" class="bbsList image">'+
							'<div class="img" style="background:url('+imgUrl+') no-repeat top left; background-size:91px 51px;"></div>'+
						'</div>'+
						'<div idx="'+idx+'" class="bbsList videoLength">'+_U.getMsTimeFormat(_O.List.items[idx]["length"])+'</div>'+
						'<div idx="'+idx+'" class="bbsList videoName EllipsisText" title="'+_O.List.items[idx]["name"]+'">'+_O.List.items[idx]["name"]+'</div>'+
						'<div idx="'+idx+'" class="bbsList cuepointList EllipsisText" >'+v.getCuepointList(idx)+'</div>'+
						'<div idx="'+idx+'" class="bbsList tag">'+tags+'</div>'+
						'<div idx="'+idx+'" class="bbsList modifyDate">'+v.getModifyDate(idx)+'</div>'+
						'<div idx="'+idx+'" class="bbsList cuePoint">'+
							'<div idx="'+idx+'" class="btn editBtn" >'+
								'<div class="btn left"></div>'+
								'<div class="btn middle">'+_L.getMsg("Edit")+'</div>'+
								'<div class="btn right"></div>'+
							'</div>'+
						'</div>'+
						'<div class="bbsList publishing">'+
							'<div idx="'+idx+'" class="btn publishBtn" >'+
								'<div class="btn left"></div>'+
								'<div class="btn middle">'+_L.getMsg("PubCode")+'</div>'+
								'<div class="btn right"></div>'+
							'</div>'+
						'</div>'+
						'<div class="bbsList delete">'+
							'<div idx="'+idx+'" class="btn listDeleteBtn" >'+
								'<div class="btn left"></div>'+
								'<div class="btn middle">'+_L.getMsg("Delete")+'</div>'+
								'<div class="btn right"></div>'+
							'</div>'+
						'</div>'+
					'</div>'+
					'<div class="bbsListBar"></div>';
			}else{
				
				var metadata = _U.trim(_O.List.haveMetadata[itemIdx].metadata);
				if(!metadata) {
					metadata = '|||||';
				}
				metadata=metadata.split('|');
				if(metadata.length < 6) {
					for(var i=metadata.length-1; i<6; i++) {
						metadata[metadata.length]='';
					}
				}
				metadata.length = 5;
				var strMetadata =  metadata.join('|');
				s+= '<div class="bbsListBox">'+
						'<div class="bbsList order">'+(itemIdx+1)+'</div>'+
						'<div class="bbsList cueThumbnail">'+
							'<img src="'+metadata[3]+'" height="35" >'+
						'</div>'+
						'<div class="bbsList time">'+_U.getMsTimeFormat(_O.List.haveMetadata[itemIdx]["time"])+'</div>'+
						'<div class="bbsList cueData EllipsisText" title="'+metadata[2]+'">'+(metadata[2] ? metadata[2] : '')+'</div>'+
						'<div class="bbsList cuePrice">';
						if(gLanguageCode != 'en'){
							s+=
							(metadata[1] ? _U.addComma(metadata[1]) + ' '+_L.getMsg("Won") : '');
						}else{
							s+=
							(metadata[1] ? _L.getMsg("Won") +' '+ _U.addComma(metadata[1]) : '');
						}
						s+=
						'</div>'+
						'<div class="bbsList Buttons">'+
							'<div id="modifyBtn_'+idx+'_'+itemIdx+'" class="btn modifyBtn" >'+
								'<div class="btn left"></div>'+
								'<div class="btn middle">'+_L.getMsg("Edit")+'</div>'+
								'<div class="btn right"></div>'+
							'</div>'+
							'<div id="deleteBtn_'+idx+'_'+itemIdx+'" class="btn cueDeleteBtn" >'+
								'<div class="btn left"></div>'+
								'<div class="btn middle">'+_L.getMsg("Delete")+'</div>'+
								'<div class="btn right"></div>'+
							'</div>'+
						'</div>'+
						'<div class="bbsList play">'+
							'<div idx="'+idx+'_'+itemIdx+'" class="btn previewBtn" >'+
								'<div class="btn left"></div>'+
								'<div class="btn middle">'+_L.getMsg("Preview")+'</div>'+
								'<div class="btn right"></div>'+
							'</div>'+
						'</div>'+
					'</div>'+
					'<div class="bbsListBar"></div>';
			}
			return s;
		};
		_O.setPageHtml= function(){
			var o= _U.Q(".contentBottom");
			var s= '';
			s+=
				'<div class="pageBox">'+
					'<div class="leftArrow"> < </div>';
				for(var i=0; i<_O.List.getTotalPageNum(); i++){
				s+=	'<div id="page_'+i+'" class="page">'+(i+1)+'</div>';
				}
				s+=	'<div class="rightArrow"> > </div>'+
				'</div>';
			o.innerHTML = s;
			
			return;
		};
//// Player /////
		_O.Player= {
			Vars:{
				player:0,
				modVP:0,
				modExp:0,
				modCon:0,
				saveMode:0,
				getTimeFixedMs:0 
			},
			init: function(){
				var v= this.Vars;
				v.player= '';
				v.modVP= '';
				v.modExp= '';
				v.modCon= '';
				v.getTimeFixedMs= '';
				for(var i=0; i<5; i++){
					document.getElementsByName("cuePointAdd")[i].value='';
				}
			},
			smallPlayerLoaded:function(experienceID){
				var v= videoAdmin.Player.Vars;
				v.player = brightcove.api.getExperience(experienceID);
				v.modVP = v.player.getModule(brightcove.api.modules.APIModules.VIDEO_PLAYER);
				v.modExp = v.player.getModule(brightcove.api.modules.APIModules.EXPERIENCE);
				v.modCon = v.player.getModule(brightcove.api.modules.APIModules.CONTENT);
				v.modExp.addEventListener(brightcove.api.events.ExperienceEvent.TEMPLATE_READY, videoAdmin.Player.smallPlayerReady);
			},
			smallPlayerReady:function(evt){
				var v= videoAdmin.Player.Vars;
				v.modVP.addEventListener(brightcove.api.events.MediaEvent.PROGRESS, videoAdmin.Player.smallPlayerProgress);
				v.modVP.addEventListener(brightcove.api.events.MediaEvent.STOP, videoAdmin.Player.smallPlayerEvent);
			},
			smallPlayerEvent:function(evt){
				var v= videoAdmin.Player.Vars;
				switch(evt.type){
					case 'mediaBegin' :
						break;
					case 'mediaComplete' :
						break;
					case 'mediaStop':
						v.getTimeFixedMs = evt.position;
						var time = _U.getFixedMsTimeFormat(evt.position);
						document.getElementsByName("cuePointAdd")[0].value = time;
						break;
				}
				//alert("MEDIA EVENT: " + evt.type + " fired at position: " + evt.position);
			},
			smallPlayerProgress:function(evt){
				var v= videoAdmin.Player.Vars;
				v.saveMode = 1;
				v.getTimeFixedMs = evt.position;
				var time = _U.getFixedMsTimeFormat(evt.position);
				document.getElementsByName("cuePointAdd")[0].value = time;
				
			},
			setSmallPlayer: function(){
				var v = _O.Dialog.Vars;
				var o = $("#player");
				var items = _O.List.items;
			
				if(typeof brightcove != 'undefined') {
					delete brightcove;
					brightcove = {};
				}
				var s='';
				s+= 
					'<object id="myExperience_1234" class="BrightcoveExperience" >'+ 
						'<param name="wmode" value="opaque"/>'+
						'<param name="bgcolor" value="#FFFFFF" />'+
						'<param name="width" value="400" />'+ 
						'<param name="height" value="225" />'+
						'<param name="playerID" value="'+gPlayer.PlayerID+'" />'+ //플레이어아이디
						'<param name="playerKey" value="'+gPlayer.PlayerKey+'" />'+ 
						'<param name="isVid" value="true" />'+ 
						'<param name="isUI" value="true" />'+
						'<param name="dynamicStreaming" value="true" />'+
						'<param name="includeAPI" value="true" />'+ 
						'<param name="templateLoadHandler" value="videoAdmin.Player.smallPlayerLoaded" />'+ 
						'<param name="@videoPlayer" value="'+items[v.curItemIdx].id+'" />'+ //비디오아이디
					'</object>';
				o.html(s);
				_U.jcejs({url:"http://admin.brightcove.com/js/BrightcoveExperiences.js",fonload:videoAdmin.Player.onLoadBrightCove, fonerror:videoAdmin.List.jsOnError});
			},
			onLoadBrightCove: function () {
				brightcove.createExperiences();
			}
		};

/// dd  ///
		_O.Dialog= {
			Vars:{
				detailInfoText:[_L.getMsg("VideoTitle"), _L.getMsg("VideoId"), _L.getMsg("RefId"), _L.getMsg("PlayerType"), _L.getMsg("CueType"), _L.getMsg("UsingTag"), _L.getMsg("AvailableTag")],
				detailInfoClsName:["detailName", "detailID", "referenceID", "playerType", "cuePointType", "detailTag", "useTag"],
				detailBBSTitleName:[_L.getMsg("Order"), _L.getMsg("CueThumbnail"), _L.getMsg("Time"), _L.getMsg("ItemText"), _L.getMsg("ItemPrice"), _L.getMsg("Change"), _L.getMsg("Play")],
				detailBBSTitleClsName:["order","cueThumbnail", "time","cueData", "cuePrice", "Buttons","play"],
				cueSettingText:[_L.getMsg("Time"), _L.getMsg("ItemId"), _L.getMsg("ItemText"), _L.getMsg("ThumbnailURL"), _L.getMsg("ClickURL"),  _L.getMsg("NewWindow"), _L.getMsg("ItemPrice"), _L.getMsg("PosBot"), _L.getMsg("BottomValue")],
				detailBBSName:"detail",
				curItemIdx: 0,
				itemTags : [],
				curTaggedTag: [],
				curAvTag: [],
				itemIdx: 0,
				ctTags : [],
				cueWrapperHeight : 794,
				modify_add_list: 3	// 0 = add, 1 = modify, 3 = List			
			},
			init: function(){
				var v= this.Vars;
				v.curTag=[];
				v.itemTags=[];
				v.ctTags=[];
				_O.List.haveMetadata=[];
			},
			setEvent: function(){
				var eventClassName=[".refreshBtn", ".updateBtn", ".cuePointBtn", ".videoViewBtn" ];
				for(var i=0; i<eventClassName.length; i++){
					$(eventClassName[i]).on("click",function (e) { videoAdmin.Dialog.dialogClick(this); });
				}
				$(".useTags").on("mouseover", function (e) { videoAdmin.Dialog.dialogOver(this); });
				$(".useTags").on("mouseout", function (e) { videoAdmin.Dialog.dialogOut(this); });
				$(".useTags").on("click", function(e) { videoAdmin.Dialog.dialogClick(this); });
				$(".taggedTags").on("mouseover", function (e) { videoAdmin.Dialog.dialogOver(this); });
				$(".taggedTags").on("mouseout", function (e) { videoAdmin.Dialog.dialogOut(this); });
				$(".taggedTags").on("click", function(e) { videoAdmin.Dialog.dialogClick(this); });
				
			},
			setAllDialog: function(){
				var newRegisterBtnName =  {};
				newRegisterBtnName[_L.getMsg("NewRegister")] = function(){
					var value = _U.trim(document.getElementsByName("videoId_form")[0].value);
					if(!value) {
						_U.showAlert({"message":_L.getMsg("VideoAlert_1")});
						return;
					}else if(value && !_U.isNumber(value)){
						_U.showAlert({"message":_L.getMsg("VideoAlert_2")});
						return;
					}
					videoAdmin.List.writeItemTag("cm_tag");
					$( this ).dialog( "close" );
				};
				newRegisterBtnName[_L.getMsg("Cancle")] = function(){
					$( this ).dialog( "close" );
				};
				$( "#newRegister" ).dialog({
					title: jLanguage.getMsg("NewRegister"),
					resizable: false,
					autoOpen: false,
					show: "fade",
					hide: "fade",
					modal: true,
					width:300,
					height:180,
					buttons:newRegisterBtnName
				});
				
				var YesNoBtnName =  {};
				YesNoBtnName[_L.getMsg("Yes")] = function(){
					videoAdmin.List.writeItemTag("remove_cm_tag");
					$( this ).dialog( "close" );
				};
				YesNoBtnName[_L.getMsg("No")] = function(){
					$( this ).dialog( "close" );
				};

				$("#delete").dialog({
					resizable: false,
					autoOpen: false,
					modal: true,
					show: "fade",
					hide: "fade",
					height:150,
					buttons:YesNoBtnName
				});
				$( "#detailInfo" ).dialog({
					resizable: false,
					autoOpen: false,
					modal: true,
					width:630,
					height:350,
					close:function(){
						_O.List.loadList(_O.List.curPage);
					}
				});
				$( "#cuePointView" ).dialog({
					title: jLanguage.getMsg("CuepointSetting"),
					resizable: false,
					autoOpen: false,
					modal: true,
					width:1040,
					height:530,
					close:function(){
						videoAdmin.Dialog.Vars.modify_add_list = 3; // 0 = add, 1 = modify, 3 = List
						$( this ).dialog( "close" );
					}
				});
				$("#strLength").dialog({
					resizable: false,
					autoOpen: false,
					modal: true,
					show: "fade",
					hide: "fade",
					width:"auto",
					height:"auto",
					buttons:{ 
						"Close":function() { 
							$( this ).dialog( "close" );
						}
					}
				});
				$("#cuePointModify").dialog({
					title: jLanguage.getMsg("CuePointAdministration"),
					resizable: false,
					autoOpen: false,
					modal: true,
					width:650,
					height:730,
					buttons:{ 
						"Save": function() {
							videoAdmin.Dialog.cuePointAddSaveBtnClick();
						},
						"Cancel":function() { 
							$( this ).dialog( "close" );
						}
					},
					close: function() {
						var o = $("#player")
							o.html('');
					}
				});
				$("#confirmUpdate").dialog({
					resizable: false,
					autoOpen: false,
					modal: true,
					show: "fade",
					hide: "fade",
					height:150,
					buttons:{ 
						"OK": function() {
							videoAdmin.List.writeItemTag("ct_tag");
							$( this ).dialog( "close" );
						},
						"Cancel":function() { 
							$( this ).dialog( "close" );
						}
					}
				});
				$("#cuePointConfirm").dialog({
					resizable: false,
					autoOpen: false,
					modal: true,
					show: "fade",
					hide: "fade",
					height:150,
					buttons:{ 
						"OK": function() {
							var cuePointAdd = document.getElementsByName("cuePointAdd");
							var itemTags = _O.Dialog.Vars.itemTags;
							var cueType ='';
							var getId = _O.Vars.getAttribute($(".detailID .infoBox_1")[0], 'title');
							for(var i=0; i<itemTags.length; i++){
								if(itemTags[i].indexOf("cm_cuetype_") == 0){
									cueType = itemTags[i].substring(itemTags[i].lastIndexOf("_")+1).toUpperCase();
								}
							}
							if(cueType == 'C'){
								var cuePointBottom =document.getElementsByName("cuePointBottom");
								cuePointBottom[0]["value"] == '' ? cuePointBottom[0]["value"]="0" : cuePointBottom[0]["value"];
							}
							for(var idx=1; idx<3; idx++){
								cuePointAdd[idx]["value"] == '' ? cuePointAdd[idx]["value"]="0" : cuePointAdd[idx]["value"];
							}
							
							for(var i=0; i<6; i++){
								if(i==0 || i==1) continue; // Movie Time&Product Id;
								var metaItemValue = _U.trim(cuePointAdd[i]["value"]);
								if(i==2) { // price
									if(gLanguageCode != 'en'){
										if(!_U.isNumber(metaItemValue)){
											$( this ).dialog( "close" );
											_U.showAlert({"message":_L.getMsg("ItemAlert_1") });
											return;
										}
									}else{
										if(!_U.isDollarNumber(metaItemValue)){
											$( this ).dialog( "close" );
											_U.showAlert({"message":_L.getMsg("ItemAlert_5") });
											return;
										}
									}
								}
								if( metaItemValue == ''){
									$( this ).dialog( "close" );
									_U.showAlert({"message": _L.getMsg("ItemAlert_2") });
									return;
								}
								if( metaItemValue.indexOf("|") >=0  ){
									$( this ).dialog( "close" );
									_U.showAlert({"message":_L.getMsg("ItemAlert_3") });
									return;
								}
							}
							if(cuePointAdd[0].value == ''){
								$( this ).dialog( "close" );
								_U.showAlert({"message":_L.getMsg("ItemAlert_4") });
								return;
							}
							var getTime = _O.Player.Vars.getTimeFixedMs * 1000;
							var metadata ='';
							var cueBottom = (cueType == 'C' ? document.getElementsByName("cuePointBottom")[0].value : 0);
							for(i=1; i<cuePointAdd.length; i++){
								metadata +=
									(cuePointAdd[i].value ? cuePointAdd[i].value : 0) + '|';
							}
							$('.windowCheck').is(':checked') ? (metadata += 'window') : (metadata += 'overlay');
							if(cueType == 'C'){
								metadata += '|' + ($(".cuePointPos").val() ? $(".cuePointPos").val() : 0) + '|' + (cueBottom ? cueBottom : 0);
							}else{
								metadata += '|' + 'L' + '|' + 0;
							}
							if(metadata.length >= 450){
								var text = _L.getMsg("CuePointAlert_1");
								$( "#strLength" ).dialog( "open" );
								$("#strLength").html(text);
								$('.ui-dialog :button').blur();
								return false;
							}else if(parseInt(cueBottom,10) > _O.Dialog.Vars.cueWrapperHeight || parseInt(cueBottom,10) < 0){
								var text = _L.getMsg("CuePointAlert_2");
								$( "#strLength" ).dialog( "open" );
								$("#strLength").html(text);
								$('.ui-dialog :button').blur();
								return false;
							}
							if( videoAdmin.Dialog.Vars.modify_add_list == 0 ){
								_O.List.haveMetadata.push(//Info Dialog Open....
									{
										"name": 'cp_'+getId+'_'+ Math.round(_O.Player.Vars.getTimeFixedMs),
										"time": getTime,
										"type": 1,
										"metadata": metadata
									}
								);
							}else{
								_O.List.haveMetadata[_O.List.btnIdx]= {
									"name": 'cp_'+getId+'_'+ Math.round(_O.Player.Vars.getTimeFixedMs),
									"time": (_O.Player.Vars.saveMode == 1 ? _O.Player.Vars.getTimeFixedMs * 1000 : _O.List.haveMetadata[_O.List.btnIdx]["time"]),
									"type": 1,
									"metadata": metadata
								}
							}
							_O.List.haveMetadata = _O.List.haveMetadata.sort(function(a, b) {return a.time - b.time;});//time sort
							var add_modify = 1;
							videoAdmin.Dialog.setCuePointViewHtml(videoAdmin.Dialog.Vars.itemIdx,add_modify);
							$("#cuePointModify").dialog("close");
							$( this ).dialog( "close" );
						},
						"Cancel":function() { 
							$( this ).dialog( "close" );
						}
					}
				});
				$("#cuePointDelete").dialog({
					resizable: false,
					autoOpen: false,
					modal: true,
					show: "fade",
					hide: "fade",
					height:150,
					buttons:{ 
						"OK": function() {
							videoAdmin.List.writeItemTag("cuePointDelete");
							$( this ).dialog( "close" );
						},
						"Cancel":function() { 
							$( this ).dialog( "close" );
						}
					}
				});
				$("#cueSave").dialog({
					resizable: false,
					autoOpen: false,
					modal: true,
					show: "fade",
					hide: "fade",
					height:150,
					buttons:{ 
						"OK": function() {
							videoAdmin.List.writeItemTag("cueSave");
							$( this ).dialog( "close" );
						},
						"Cancel":function() { 
							$( this ).dialog( "close" );
						}
					}
				});
				$("#publish").dialog({
					resizable: false,
					autoOpen: false,
					modal: true,
					show: "fade",
					hide: "fade",
					width:"auto",
					height:"auto",
					buttons:{ 
						"Cancel":function() { 
							$( this ).dialog( "close" );
						}
					}
				});
				$("#cuePointPreview").dialog({
					resizable: false,
					autoOpen: false,
					modal: true,
					show: "fade",
					hide: "fade",
					width:"auto",
					height:"auto",
					position:[100, 100]
				});
			},
			setNewRegisterDialogHtml: function(){
				var o= _U.E("newRegister");
				var s='';
				s+= '<div class="wrapper">'+
						'<div id="videoId">'+
							'<div class="videoIdText">Video ID</div>'+
							'<input type="text" maxlength="128" name="videoId_form" size="15" value="" class="form-text">'+
						'</div>'+
						'<div class="caution">'+_L.getMsg("ItemVideoId")+'</div>'+
					'</div>';
				o.innerHTML = s;
			},
			setDetailInfoDialogHtml: function(idx){
				var v= _O.Dialog.Vars;
				
				v.curItemIdx = idx;
				var o =_U.E("detailInfo");
				var s= '';
				var configTags = gTagsName.ct_tags;
				if(!_O.List.items) return;
				if(!_O.List.items[idx]) return;
				var itemTags = _O.List.items[idx]["tags"];
				if(typeof itemTags == 'undefined') {
					// _U.showAlert({"message":"Tag 정보가 없습니다."});
					return;
				}
				v.itemTags = itemTags;
				var ctTags = [];
				var taggedTag = [];
				var avTag = [];
				var found = false;
				var cueType="A";
				var playerType = 'S';
				
				for(var i=0; i<itemTags.length; i++){
					if(itemTags[i].indexOf('ct_') == 0){//cm_tv exception
						ctTags.push(itemTags[i]);
					}
					if(cueType=="A" && itemTags[i].indexOf('cm_cuetype_') == 0){
						cueType = itemTags[i].substring(itemTags[i].lastIndexOf("_")+1).toUpperCase();
					}
					if(playerType=="S" && itemTags[i].indexOf('cm_player_') == 0){
						playerType = itemTags[i].substring(itemTags[i].lastIndexOf("_")+1).toUpperCase();
					}
				}
				v.ctTags = ctTags;
				for(i=0; i<configTags.length; i++){
					found=false;
					for(var j=0; j<ctTags.length; j++){
						if(configTags[i].toLowerCase() == ctTags[j].toLowerCase()){
							found = true;
							break;
						}
					}
					if(found){
						taggedTag.push(configTags[i]);
					}else{
						avTag.push(configTags[i]);
					}
				}
				taggedTag = taggedTag.join(",").replace(/ct_/gi,"").toLowerCase().split(",");	
				avTag = avTag.join(",").replace(/ct_/gi,"").toLowerCase().split(",");
				v.curTaggedTag = taggedTag;
				v.curAvTag = avTag;
				s+= '<div class="detailInfo">';
				for(var i=0; i<v.detailInfoText.length; i++){
					s+= '<div class="'+v.detailInfoClsName[i]+'">'+
							'<div class="titleText">'+v.detailInfoText[i]+'</div>';
					if(v.detailInfoClsName[i]=="detailID"){
						s+=	'<div class="infoBox_1" title="'+_O.List.items[idx]["id"]+'">'+_O.List.items[idx]["id"]+'</div>';
					}else if( v.detailInfoClsName[i]=="referenceID"){
						s+=	'<input type="text" name="referenceId" value="'+(_O.List.items[idx]["referenceId"]==null ? '' : _O.List.items[idx]["referenceId"])+'" class="inputText">';
					}else if( v.detailInfoClsName[i]== "detailName"){
						s+=	'<div class="infoBox_1 EllipsisText" title="'+_O.List.items[idx]["name"]+'">'+_O.List.items[idx]["name"]+'</div>';
					}else if( v.detailInfoClsName[i]== "cuePointType"){
						s+=	'<select name="cueTypeSelection" class="cueTypeSelection">';
						for(var key in gCuePointType) {
							var selected = "";
							if(key == cueType) selected = "selected";
							else selected='';
							s+='<option value="'+key+'" '+selected+' >'+_L.getMsg("CueType_"+key)+'</option>';
						}
						s+="</select>";

					}else if(v.detailInfoClsName[i]=="playerType"){
						s+= '<select name="playerSelect" class="playerSelect">';
							for(var key in gPlayerType) {
								var selected = "";
								if(key == playerType) selected = "selected";
								else selected='';
								s+='<option value="'+key+'" '+selected+' >'+gPlayerType[key]+'</option>';
							}
						s+= '</select>';
					}else if(v.detailInfoClsName[i]=="detailTag"){
						s+=	'<div class="infoBox_2">';
							if(taggedTag){
								for(j=0; j<taggedTag.length; j++){
								s+= '<div title="'+taggedTag[j]+'" class="taggedTags">'+taggedTag[j]+'</div>';
								}
							}else{
								s+= '<div title="" class="taggedTags"></div>';
							}
						s+= '</div>';
					}else{
						s+=	'<div class="infoBox_3">';
							if(avTag){
								for(j=0; j<avTag.length; j++){
								s+= '<div id="useTag_'+j+'" title="'+avTag[j]+'" class="useTags">'+avTag[j]+'</div>';
								}
							}else{
								s+= '<div title="" class="useTags"></div>';
							}
						s+=	'</div>';
					}
					s+='</div>';
				}
					s+=
						'<div idx="'+idx+'" class="btn videoViewBtn" >'+
							'<div class="btn left"></div>'+
							'<div class="btn middle">'+_L.getMsg("VideoView")+'</div>'+
							'<div class="btn right"></div>'+
						'</div>'+
						'<div class="btn updateBtn" >'+
							'<div class="btn left"></div>'+
							'<div class="btn middle">'+_L.getMsg("Update")+'</div>'+
							'<div class="btn right"></div>'+
						'</div>'+
						'<div idx="'+idx+'" class="btn cuePointBtn" >'+
							'<div class="btn left"></div>'+
							'<div class="btn middle">'+_L.getMsg("CuePoint")+'</div>'+
							'<div class="btn right"></div>'+
						'</div>'+
						'<div class="btn refreshBtn" >'+
							'<div class="btn left"></div>'+
							'<div class="btn middle">'+_L.getMsg("Refresh")+'</div>'+
							'<div class="btn right"></div>'+
						'</div>'+
					'</div>'+
				'</div>';
				o.innerHTML = s;
				this.setEvent();
				return;
			},
			useTagClick: function(o) {
				var v= this.Vars;
				$(o).not("useTags").remove();
				var clickUseTag = o.getAttribute("title");
				v.curTaggedTag.push(clickUseTag);
				v.ctTags.push('ct_'+clickUseTag);
				for(var i=0; i<v.curAvTag.length; i++){
					if(v.curAvTag[i].indexOf(clickUseTag) == 0){
						v.curAvTag.splice(i,1);
						if(v.curAvTag.length==0) v.curAvTag=[];
					}
				}
				var tagObj= _U.Q(".infoBox_2");
				var s='';
				for(i=0; i<v.curTaggedTag.length; i++){
				s+= '<div title="'+v.curTaggedTag[i]+'" class="taggedTags">'+v.curTaggedTag[i]+'</div>';
				}
				
				
				tagObj.innerHTML = s;
				$('.taggedTags').on("mouseover", function (e) { videoAdmin.Dialog.dialogOver(this); });
				$('.taggedTags').on("mouseout", function (e) { videoAdmin.Dialog.dialogOut(this); });
				$('.taggedTags').on("click", function(e) { videoAdmin.Dialog.dialogClick(this); });
			},
			taggedTagClick: function(o){
				var v= this.Vars;
				$(o).not("taggedTags").remove();
				var clickTaggedTag = o.getAttribute("title");
				v.curAvTag.push(clickTaggedTag);
				for(var j=0; j<v.ctTags.length; j++){
					if(v.ctTags[j] == 'ct_'+clickTaggedTag){
						v.ctTags.splice(j,1);
					}
				}
				for(var i=0; i<v.curTaggedTag.length; i++){
					if(v.curTaggedTag[i].indexOf(clickTaggedTag) == 0){
						v.curTaggedTag.splice(i,1);
						if(v.curTaggedTag.length==0) v.curTaggedTag=[];
					}
				}
				var tagObj= _U.Q(".infoBox_3");
				var s='';
				for(var i=0; i<v.curAvTag.length; i++){
				s+= '<div title="'+v.curAvTag[i]+'" class="useTags">'+v.curAvTag[i]+'</div>';
				}
				tagObj.innerHTML = s;
				$('.useTags').on("mouseover", function (e) { videoAdmin.Dialog.dialogOver(this); });
				$('.useTags').on("mouseout", function (e) { videoAdmin.Dialog.dialogOut(this); });
				$('.useTags').on("click", function(e) { videoAdmin.Dialog.dialogClick(this); });
			},
			setDetailBBSHtml: function(idx, mode) {
				var v = _O.Dialog.Vars;
				var s = '';
				s += _O.setBBSHtml(v.detailBBSTitleClsName, v.detailBBSTitleName, v.detailBBSName, idx, mode);
				return s;
			},
			setCuePointSettingHtml: function(type, itemIdx, idx) {
				var caution = _L.getMsg("Caution");
				var v= this.Vars;
				var itemTags = v.itemTags;
				var o= _U.E("cuePointModify");
				var s='';
				if(_O.List.haveMetadata[idx]){
					var metadata = _U.trim(_O.List.haveMetadata[idx].metadata);
					if(!metadata) {
						metadata = '|||||||';
					}
					metadata=metadata.split('|');
					if(metadata.length < 8) {
						for(var i=metadata.length-1; i<8; i++) {
							metadata[metadata.length]='';
						}
					}
				}
				var cueType ='';
				for(var i=0; i<itemTags.length; i++){
					if(itemTags[i].indexOf("cm_cuetype_") == 0){
						cueType = itemTags[i].substring(itemTags[i].lastIndexOf("_")+1).toUpperCase();
					}
				}
				if(cueType == 'C' && type == 'edit') var cuePos= metadata[metadata.length-2];
			
				s+= '<div class="wrapper">';
					s+= '<div id="player"></div>';
				if(type == 'edit'){
					for(i=0; i<v.cueSettingText.length-3; i++){
						if(i == 2) {
							s+= '<div class="row cuePointText">'+
									'<div class="textBox cuePointText">'+v.cueSettingText[i]+'</div>';
						}else if(i==0){
							s+= 
							'<div class="row">'+
								'<div class="textBox">'+v.cueSettingText[i]+'</div>'+
								'<input type="text" name="cuePointAdd" size="15" value="'+_U.getMsTimeFormat(_O.List.haveMetadata[idx]["time"]) +'" class="form-text short" onfocus="this.blur()">';
								if(cueType == 'C'){
									s+=
									'<div class="textBox" style="margin-left:40px;">'+v.cueSettingText[v.cueSettingText.length-2]+'</div>'+
									'<select name="cuePointPos" class="cuePointPos">';
										for(var key in gCuePointPos) {
											var selected = "";
											if(key == cuePos) selected = "selected";
											else selected='';
											s+='<option value="'+key+'" '+selected+' >'+_L.getMsg("CuePos_"+key)+'</option>';
										}
									s+=
									"</select>"+
									'<input type="text" name="cuePointBottom" size="15" value="'+(metadata[7] ? metadata[7] : '0')+'" class="form-text short_2">px';
								}
						}else if(i == 1){
							if(cueType == 'C') {
								s+= '<div class="row"><div class="caution">'+caution+'</div></div>';
							}
							s+=
								'<div class="row">'+
									'<div class="textBox">'+v.cueSettingText[i]+'</div>'+
									'<input type="text" name="cuePointAdd" size="15" value="'+metadata[0]+'" class="form-text short">'+
									'<div class="textBox" style="margin-left:20px;">'+v.cueSettingText[v.cueSettingText.length-3]+'('+_L.getMsg('Won')+')</div>'+
									'<input type="text" name="cuePointAdd" size="15" value="'+metadata[1]+'" class="form-text short">';
						}else{
							s+= '<div class="row">'+
									'<div class="textBox">'+v.cueSettingText[i]+'</div>';
						}
						switch(i){
							case 2:
								s+= '<textarea rows="1" cols="20" name="cuePointAdd" class="textArea">'+metadata[2]+'</textarea>';
								break;
							case 3:
								s+= '<input type="text" name="cuePointAdd" size="15" value="'+metadata[3]+'" class="form-text long">';
								break;
							case 4:
								s+= '<input type="text" name="cuePointAdd" size="15" value="'+metadata[4]+'" class="form-text long">';
								break;
							case 5:
								if(metadata[5]=='overlay' || metadata[5]==''){
									s+= '<input type="checkbox" class="windowCheck">';
								}else{
									s+= '<input type="checkbox" checked="checked" class="windowCheck">';
								}
								break;
						}
						s+=	'</div>';
							
					}
				}else{
					for(i=0; i<v.cueSettingText.length-3; i++){
						if(i == 2) {
							s+= '<div class="row cuePointText">'+
									'<div class="textBox cuePointText">'+v.cueSettingText[i]+'</div>';
						}else if(i==0){
							s+= 
							'<div class="row">'+
								'<div class="textBox">'+v.cueSettingText[i]+'</div>'+
								'<input type="text" name="cuePointAdd" size="15" value="" class="form-text short" onfocus="this.blur()">';
								if(cueType == 'C'){
									s+=
									'<div class="textBox" style="margin-left:20px;">'+v.cueSettingText[v.cueSettingText.length-2]+'</div>'+
									'<select name="cuePointPos" class="cuePointPos">';
										for(var key in gCuePointPos) {
											s+='<option value="'+key+'">'+_L.getMsg("CuePos_"+key)+'</option>';
										}
									s+=
									"</select>"+
									'<input type="text" name="cuePointBottom" size="15" value="" class="form-text short_2">px';
								}
						}else if(i == 1){
							if(cueType == 'C'){
								s+= '<div class="row caution">'+caution+'</div>';
							}
							s+=
								'<div class="row">'+
									'<div class="textBox">'+v.cueSettingText[i]+'</div>'+
									'<input type="text" name="cuePointAdd" size="15" value="" class="form-text short">'+
									'<div class="textBox" style="margin-left:20px;">'+v.cueSettingText[v.cueSettingText.length-3]+'('+_L.getMsg('Won')+')</div>'+
									'<input type="text" name="cuePointAdd" size="15" value="" class="form-text short">';
						}else{
							s+= '<div class="row">'+
									'<div class="textBox">'+v.cueSettingText[i]+'</div>';
						}
						switch(i){
							case 2:
								s+= '<textarea rows="1" cols="20" name="cuePointAdd" class="textArea"></textarea>';
								break;
							case 3:
								s+= '<input type="text" name="cuePointAdd" size="15" value="" class="form-text long">';
								break;
							case 4:
								s+= '<input type="text" name="cuePointAdd" size="15" value="" class="form-text long">';
								break;
							case 5:
								s+= '<input type="checkbox" class="windowCheck">';
								break;
						}
						s+=	'</div>';
							
					}
				}
					s+= 
						'<div class="thumbnail">'+
							'<img id="thumbnail" src="" height="75">'+
						'</div>'+
						'<div class="btn imageViewBtn" >'+
							'<div class="btn left"></div>'+
							'<div class="btn middle">'+_L.getMsg("ThumbnailView")+'</div>'+
							'<div class="btn right"></div>'+
						'</div>'+
						'<div class="thumbnailSize"></div>'+
					'</div>';
				o.innerHTML = s;
				if(cueType != 'C') {
					$($(".row")[4]).css("margin-top","115px");
				}else{
					$(".imageViewBtn").css("top","442px");
					$(".thumbnail").css("top","468px");
					$($(".row")[5]).css("margin-top","115px");
					$(".thumbnailSize").css("top","445px");
				}
				$("#thumbnail").attr("src", $('#cuePointModify .row input.form-text.long').val());
				$(".imageViewBtn").on(
					"click",
					function(e){
						$("#thumbnail").attr("src", $('#cuePointModify .row input.form-text.long').val());
					}
				);
				$(".thumbnailSize").html(_L.getMsg("ThumbnailCaution"));

				function limitMe(e) {
					if (e.keyCode == 8) { return true; }
					return this.value.length < $(this).attr("maxLength");
				}
			},
			setPublishHtml: function(idx){
				var item = _O.List['items'][idx];
				var playerType ='';
				for(var i=0; i<item['tags'].length; i++){
					if(item['tags'][i].indexOf("cm_player_") == 0){
						playerType = item['tags'][i].substring(item['tags'][i].lastIndexOf("_")+1).toUpperCase();
					}
				}
				var s='';
				var pubCode = gPubCode.Player;// (playerType != 'C' ? gPubCode.singlePlayer : gPubCode.chromelessPlayer);
				pubCode = pubCode.replace("#VIDEO_ID",_O.List.items[idx]['id']);
				s+=
					'<textarea id="textArea1" rows="10" cols="20" name="publishCode" class="textArea"></textarea>'+
					'<div idx="'+idx+'" class="btn copyBtn" >'+
						'<div class="btn left"></div>'+
						'<div class="btn middle">Select</div>'+
						'<div class="btn right"></div><br><br>'+_L.getMsg("PubCaution")+
					'</div>';
				$("#publish").html(s);
				$("#publish .textArea").val(pubCode);
				$(".copyBtn").on(
					"click", 
					function(){
						$("#textArea1")[0].focus();
						$("#textArea1")[0].select();
					}
				);
			},
			setCuepointViewEvent:function(){
				var className= [".modifyBtn", ".cueDeleteBtn", ".cuePointAddBtn", ".previewBtn", ".cueSaveBtn"];
				for(var i=0; i<className.length; i++){
					$(className[i]).on("click",function (e) { videoAdmin.Dialog.dialogClick(this); });
				}
			},
			setCuePointViewHtml: function(idx,mode) {
				var s = '';
				s+=
				'<div class="detailBBSBox">'+
					'<div class="cuePointBox">'+
						'<div id="cuePointAddBtn_'+idx+'" class="btn cuePointAddBtn" >'+
							'<div class="btn left"></div>'+
							'<div class="btn middle">'+_L.getMsg("CuePointAdd")+'</div>'+
							'<div class="btn right"></div>'+
						'</div>'+
					'</div>';
				s+= this.setDetailBBSHtml(idx,mode);
				s+=
				'<div idx="'+idx+'" class="btn cueSaveBtn">'+
					'<div class="btn left"></div>'+
							'<div class="btn middle">'+_L.getMsg('Save')+'</div>'+
							'<div class="btn right"></div>'+
				'</div>';
				$("#cuePointView").html(s);
				this.setCuepointViewEvent();
			},
			setCuePointPreviewPlayerHtml: function(idx, itemIdx){//itemIdx있으면 큐포인트 시작점부터 미리보기, 없으면 그냥 영상 전체
				var item = _O.List['items'][idx];
				var playerType ='';
				for(var i=0; i<item['tags'].length; i++){
					if(item['tags'][i].indexOf("cm_player_") == 0){
						playerType = item['tags'][i].substring(item['tags'][i].lastIndexOf("_")+1).toUpperCase();
					}
				}
				////큐포인트 미리보기 플레이어 itemIdx 가있으면 cueIdx 넘기고없으면 넘기지마. //윈도우 위에서 열리게
				if(typeof itemIdx == 'undefined') itemIdx = '';
				var pubCode = gPubCode.Player;
				pubCode = pubCode.replace("#VIDEO_ID",_O.List.items[idx]['id']+'&cueData=videoAdmin.List.haveMetadata&cueIdx='+itemIdx);
				$("#cuePointPreview").html(pubCode);
			},
			dialogClick: function(o){
				var v= this.Vars;
				var oName = o.className.substr(4,(o.className.length-1));
				switch(oName){
					case 'newRegisterBtn' :
						this.setNewRegisterDialogHtml();
						$( "#newRegister" ).dialog( "open" );
						return false;
						break;
					case 'ist image':
					case 'ist videoLength' :
					case 'ist videoName EllipsisText' :
					case 'ist cuepointList EllipsisText' :
					case 'ist tag' :
					case 'ist modifyDate' :
					case 'editBtn' :
						var idx = $(o).attr('idx');
						this.init();		
						this.setDetailInfoDialogHtml(idx);
						$( "#detailInfo" ).dialog( "open" );
						return false;
						break;
					case 'publishBtn':
						var idx = $(o).attr('idx');
						this.setPublishHtml(idx);
						$( "#publish" ).dialog( "open" );
						return false;
						break;
					case 'refreshBtn':
						this.refreshBtn();
						break;
					case 'listDeleteBtn':
						var idx = $(o).attr('idx');
						_O.List.deleteTagIdx = idx;
						var text= _L.getMsg("DeleteConfirm");
						$("#delete").html(text);
						$("#delete").dialog( "open" );
						$('.ui-dialog :button').blur();
						return false;
						break;
					case 'videoViewBtn':
						var idx = $(o).attr('idx');
						if(_O.List.items[idx]["cuePoints"].length != 0){
							for(var i=0; i<_O.List.items[idx]["cuePoints"].length; i++){
								if(_O.List.items[idx]["cuePoints"][i]["type"]==1){
									_O.List.haveMetadata.push(//Info Dialog Open....
										{
											"name": _O.List.items[idx]["cuePoints"][i]["name"],
											"time": _O.List.items[idx]["cuePoints"][i]["time"],
											"type": 1,
											"metadata": _O.List.items[idx]["cuePoints"][i]["metadata"]
										}
									);
								}
							}
						}
						this.setCuePointPreviewPlayerHtml(idx);
						$( "#cuePointPreview" ).dialog( "open" );
						break;
					case 'cuePointBtn':
						_O.List.haveMetadata=[];
						var idx = $(o).attr('idx');
						this.Vars.itemIdx = idx;
						this.setCuePointViewHtml(idx);
						$( "#cuePointView" ).dialog( "open");
						break;
					case 'previewBtn':
						var idx = $(o).attr('idx').split("_")[0];
						var itemIdx = $(o).attr('idx').split("_")[1];
						this.setCuePointPreviewPlayerHtml(idx, itemIdx);
						$( "#cuePointPreview" ).dialog( "open" );
						break;
					case 'updateBtn' :
						var text= _L.getMsg("ModifyConfirm");
						$("#confirmUpdate").html(text);
						$("#confirmUpdate").dialog("open");
						$('.ui-dialog :button').blur();
						return false;
						break;
					case 'cuePointAddBtn' :
						var idx=o.id.substr(15);
						this.setCuePointSettingHtml('add');
						_O.Player.init();
						_O.Player.setSmallPlayer();
						_O.Dialog.Vars.modify_add_list = 0; // 0 = add, 1 = modify, 3 = List
						$( "#cuePointModify" ).dialog( "open" );
						break;
					case 'cueSaveBtn' :
						var text= _L.getMsg("SaveConfirm");
						$("#cueSave").html(text);
						$("#cueSave").dialog("open");
						$('.ui-dialog :button').blur();
						break;
					case 'modifyBtn' :
						var itemIdx = o.id.substr(10);
						var idx = o.id.substr(12);
						_O.Player.Vars.saveMode = 0;
						_O.List.btnIdx= idx;
						this.setCuePointSettingHtml('edit',itemIdx ,idx);
						_O.Player.setSmallPlayer();
						_O.Dialog.Vars.modify_add_list = 1; // 0 = add, 1 = modify, 3 = List
						$( "#cuePointModify" ).dialog( "open" );
						return false;
						break;
					case 'cueDeleteBtn':
						var idx = o.id.substr(12);
						_O.List.btnIdx= idx;
						var text= _L.getMsg("CueDeleteConfirm");
						$("#cuePointDelete").html(text);
						$("#cuePointDelete").dialog("open");
						$('.ui-dialog :button').blur();
						return false;
						break;
					case 'ags hover' :
						this.useTagClick(o);
						break;
					case 'edTags hover' :
						this.taggedTagClick(o);
						break;
				}
			},
			refreshBtn: function(mode){
				var getId = _O.Vars.getAttribute(_U.Qs(".detailID .infoBox_1")[0], 'title');
				_O.List.refreshItem(getId);
			},
			dialogOver: function(o){
				switch(o.className){
					case "useTags":
					case "taggedTags":
						_U.addCss(o, "hover");
						break;
				}
			},
			dialogOut: function(o){
				switch(o.className){
					case "useTags hover":
					case "taggedTags hover":
						_U.removeCss(o, "hover");
						break;
				}
			},
			cuePointAddSaveBtnClick: function(){
				var text = '';
				if(_O.Dialog.Vars.modify_add_list==0) text= _L.getMsg("AddConfirm");
				else text=_L.getMsg("ModifyConfirm");
				$("#cuePointConfirm").html(text);
				$("#cuePointConfirm").dialog("open");
				$('.ui-dialog :button').blur();
				return false;
			}
		};
	}) (videoAdmin); 
}


if(!window['jCallbacks']) { 
	jCallbacks = {
		func: [],
		setFunc: function(apiId,func) {
			jCallbacks.func[apiId]=func;
		}
	};
}