
var gTagsName = {
	ct_tags: ["ct_Women", "ct_Men", "ct_Kids", "ct_Family", "ct_Gift", "ct_Life"]
};

var gCuePointType = {
	//"*":" CueType * : 플레이어 Config 파일의 CueType 사용 ",
	"A":" CueType A : 우측 썸네일 ",
	"B":" CueType B : 하단 배너 ",
	"C":" CueType C : 하단 좌우 배너 ",
	"D":" CueType D : 하단 배너(Close) "
};

var gCuePointPos = {
	"L":"왼쪽",
	"R":"오른쪽"
};

var gLanguageCode = 'en'; // 한국어(ko), 영어(en)
	
var gPlayerType = {
	"S":"Single",
	"C":"Chromeless"
};
var gPlayer = {
	PlayerID:"1466766389001",
	PlayerKey:"AQ~~,AAAA_jYwAak~,f6iN_Qpszc0Ns4C7OOZAJ-wviT8oCJKo"
};
var gPreviewBaseUrl = "http://dev.brightcove.co.kr/dv/ec/player/";
//var gChromelessPreviewBaseUrl = "http://www.jnjt.co.kr/prj/Brightcove/player_c_working/";
var gPubCode = { 
	Player:'<div class="BrightCoveCT"></div>'+
					'<script>'+
						'(function(J) {	window["g_br_api_url"] = J.src; var s = J.doc.createElement("script"); s.type = "text/javascript"; s.async = true;s.src = J.src; var s0 = J.doc.getElementsByTagName("script")[0]; s0.parentNode.insertBefore(s, s0);}) ({src:"'+gPreviewBaseUrl+'js/api.js?id=#VIDEO_ID",doc:document});'+
					'</script>'
	/*chromelessPlayer:'<div class="BrightCoveCT"></div>'+
						'<script>'+
							'(function(J) {	window["g_br_api_url"] = J.src; var s = J.doc.createElement("script"); s.type = "text/javascript"; s.async = true;s.src = J.src; var s0 = J.doc.getElementsByTagName("script")[0]; s0.parentNode.insertBefore(s, s0);}) ({src:"'+gChromelessPreviewBaseUrl+'js/api.js?id=#VIDEO_ID",doc:document});'+
						'</script>'*/
};

var gBrightCoveAPI= {
	CMTV_Tag: "cm_tv",
	ApiBaseUrl: "http://api.brightcove.com/services/library",
	Token : "GjGg0W5wxXT5tRa0W1jtCsm1gDg411r9C4P5kbvUpN2OANQ6bdC4Cw..",
	PageSize: 10, // 10,15,20,25,30 중 택1.
	SearchFields: "id,name,shortDescription,creationDate,playsTotal,videoStillURL,length,thumbnailURL,renditions,tags,customFields,cuePoints,referenceId,lastModifiedDate",
	MediaDelivery:"http"
};
