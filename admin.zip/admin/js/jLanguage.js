
if(!window['jLanguage']) { 
	jLanguage = {}; 
	( function () {

	var _O = jLanguage;

	_O.getMsg = function (msgName) {
		
		// var lang = this.CountryLang[gLanguageCode];
		var lang = gLanguageCode.toLowerCase();

		if(_O.Message[msgName+'_'+lang])
			return _O.Message[msgName+'_'+lang];
		else if(_O.Message[msgName+'_en'])
			return _O.Message[msgName+'_en'];
		else if(_O.Message[msgName+'_ko'])
			return _O.Message[msgName+'_ko'];
		else return '';
	};
	_O.toString = {
		langOrder: ['ko','en','de','es','fr','pt','it','zh','ru','th','vi','id','ja'],
		rString: "",
		getName: function (s) {
			if(!s) return '';
			return s.substring(0,s.lastIndexOf('_'));
		},
		getLang: function (s) {
			if(!s) return '';
			return s.substring(s.lastIndexOf('_')+1,s.length);
		},
		out: function (s) {
			this.rString +=s;
		},
		start: function() {
			var msg = _O.Message;
			var name = ""
			var index=0;
			this.rString="";
			for(var i=0;i<this.langOrder.length;i++) {
				this.out("\t"+this.langOrder[i]);
			}
			this.out("\n");
			for(var key in msg) {
				if(typeof msg[key] === "string"){
					if(this.getName(key) != name) {
						name = this.getName(key);
						this.out("\n"+name);
						index=0;
					}
					if(this.getLang(key) != this.langOrder[index]) { 
						this.out("=========== Error Order =========: key="+ key); 
						break;
					}
					this.out("\t"+msg[key]);
					index++;
				}
			}
		}
	};

/// Message 정의
	_O.Message = {
		//BBS
		'Won_ko' : "원",
		'Won_en' : "$",

		'Video_ko' : "비디오",
		'Video_en' : "Video",

		'VideoLength_ko' : "비디오 길이",
		'VideoLength_en' : "Video Length",

		'VideoName_ko' : "비디오 제목",
		'VideoName_en' : "Video Name",
		
		'ItemText_ko' : "상품 텍스트",
		'ItemText_en' : "Description",
		
		'Tag_ko' : "태그",
		'Tag_en' : "Tags",

		'LastModified_ko' : "최종수정일",
		'LastModified_en' : "Last Modified",
		
		'CuePoint_ko' : "큐포인트",
		'CuePoint_en' : "Cue Point",

		'Publishing_ko' : "퍼블리싱 코드",
		'Publishing_en' : "Publishing code",
		
		'Delete_ko' : "삭제",
		'Delete_en' : "Delete",

		'CuePointAlert_1_ko' : "큐포인트의 설정 정보로 입력한 텍스트는 총 450자를 초과하셨습니다.",
		'CuePointAlert_1_en' : "Description cannot exceed 450 characters ",
		
		'CuePointAlert_2_ko' : "픽셀수치는 0~794px 입니다.",
		'CuePointAlert_2_en' : "pixel should be between 0~794px",
		
		'TimeAlert_1_ko' : "시간 정보가 없습니다.",
		'TimeAlert_1_en' : "Error: Please add timecode",

		'TimeAlert_2_ko' : "시간 정보 오류입니다.",
		'TimeAlert_2_en' : "Error: incorrect timecode",

		'SearchAlert_ko' : "검색한 데이터가 없습니다.",
		'SearchAlert_en' : "No search result",

		'CuePointAlert_3_ko' : "큐포인트가 없습니다.",
		'CuePointAlert_3_en' : "No cue point data",
		
		'CuePointAdd_ko' : "큐포인트 추가",
		'CuePointAdd_en' : "Add New Cue Point",
		
		'CuePointAdministration_ko' : "큐포인트 관리",
		'CuePointAdministration_en' : "Cue Point Settings",

		'Edit_ko' : "수정",
		'Edit_en' : "Edit",

		'PubCode_ko' : "Pub.Code",
		'PubCode_en' : "Pub.Code",

		'Preview_ko' : "미리보기",
		'Preview_en' : "Preview",
		
		'Commerce_ko' : "비디오 커머스 템플릿",
		'Commerce_en' : "Brightcove Video Commerce Template",
		
		//Dialog
		'Register_ko' : "신규등록",
		'Register_en' : "New Register",

		'Left_ko' : "왼쪽",
		'Left_en' : "Left",

		'Right_ko' : "오른쪽",
		'Right_en' : "Right",

		'VideoTitle_ko' : "비디오 제목",
		'VideoTitle_en' : "Video Title",

		'VideoId_ko' : "비디오 ID",
		'VideoId_en' : "Video ID",

		'RefId_ko' : "Ref ID(선택사항)",
		'RefId_en' : "Ref ID(optional)",
			
		'PlayerType_ko' : "플레이어 타입",
		'PlayerType_en' : "Player Type",

		'CueType_ko' : "큐포인트 타입",
		'CueType_en' : "Cue Point Type",
		
		'UsingTag_ko' : "사용중인 태그",
		'UsingTag_en' : "Tags in use",
		
		'AvailableTag_ko' : "사용가능한<br>태그",
		'AvailableTag_en' : "Tag Library",

		'Order_ko' : "순서",
		'Order_en' : "Order",
		
		'CueThumbnail_ko' : "큐포인트 썸네일",
		'CueThumbnail_en' : "Cue Point Thumbnail",
		
		'Time_ko' : "시간",
		'Time_en' : "Timecode(hh:mm:ss)",

		'ItemPrice_ko' : "상품 가격",
		'ItemPrice_en' : "Item Price",

		'Change_ko' : "변경",
		'Change_en' : "Change",

		'Play_ko' : "재생",
		'Play_en' : "Play",
		
		'ItemId_ko' : "상품 ID",
		'ItemId_en' : "Item ID",
		
		'ThumbnailURL_ko' : "썸네일 URL",
		'ThumbnailURL_en' : "Thumbnail URL",

		'ClickURL_ko' : "클릭 URL",
		'ClickURL_en' : "Link URL",

		'NewWindow_ko' : "새창에서 보기",
		'NewWindow_en' : "Opens in a new window",

		'PosBot_ko' : "위치, Bottom",
		'PosBot_en' : "Align, Bottom",

		'BottomValue_ko' : "Bottom 값",
		'BottomValue_en' : "Bottom Value",

		'OK_ko' : "확인",
		'OK_en' : "OK",
		
		'Yes_ko' : "예",
		'Yes_en' : "Yes",
		
		'No_ko' : "아니오",
		'No_en' : "No",

		'NewRegister_ko' : "신규등록",
		'NewRegister_en' : "Add new video",

		'Cancle_ko' : "취소",
		'Cancle_en' : "Cancel",

		'Save_ko' : "저장",
		'Save_en' : "Save",
		
		'SaveConfirm_ko' : "저장하시겠습니까?",
		'SaveConfirm_en' : "Are you sure you want to save?",
		
		'VideoAlert_1_ko' : "상품용 비디오 ID가 없습니다.",
		'VideoAlert_1_en' : "Form contains error: Video ID is empty",

		'VideoAlert_2_ko' : "비디오 ID는 숫자여야 합니다.",
		'VideoAlert_2_en' : "Form contains error: Video ID has to be a number",

		'ItemAlert_1_ko' : "상품가격은 숫자만 적어야합니다.",
		'ItemAlert_1_en' : "Form contains error: Price should be a number ",

		'ItemAlert_2_ko' : "상품텍스트, 이미지 URL, 클릭 URL 중 비어 있는 값이 있습니다.",
		'ItemAlert_2_en' : "Form contains error: There is an empty value in description, image URL, or Click URL",

		'ItemAlert_3_ko' : "상품텍스트, 이미지 URL, 클릭 URL에는 \"|\" 문자를 쓸 수 없습니다.",
		'ItemAlert_3_en' : "Form contains error: You cannot use characters \"|\" in Description, Image URL and Click URL ",

		'ItemAlert_4_ko' : "시간정보는 필수로 입력해야 합니다.",
		'ItemAlert_4_en' : "Form contains error: You should add timecode",

		'ItemAlert_5_ko' : "상품가격은 숫자와 소수점만 적어야합니다.",
		'ItemAlert_5_en' : "Form contains error: Price should be a number and point ",

		'ItemVideoId_ko' : "상품용 비디오의 ID를 입력해주시기 바랍니다.",
		'ItemVideoId_en' : "Please insert Video ID",

		'VideoView_ko' : "비디오 보기",
		'VideoView_en' : "Play video",
		
		'Update_ko' : "업데이트",
		'Update_en' : "Update",

		'Refresh_ko' : "새로고침",
		'Refresh_en' : "Refresh",
		
		'CuepointSetting_ko' : "큐포인트 설정",
		'CuepointSetting_en' : "Cue Point Settings",
		
		'Caution_ko' : "주의 : Bottom 값은 796 - (이미지의 높이 값)을 초과 할 수 없습니다.",
		'Caution_en' : "Alert: Bottom value cannot exceed 796 (Height length of image)",
		
		'ThumbnailView_ko' : "썸네일보기",
		'ThumbnailView_en' : "Overview Thumbnail",
		
		'ThumbnailCaution_ko' : "썸네일 일반 크기는 100x75이며,<br>배너형식의 큐타입은450x75입니다.",
		'ThumbnailCaution_en' : "The thumbnail size of Type A is 100x75,<br>Type B is 450x75",

		'PubCaution_ko' : "선택후  Ctrl-C를<br> 눌러 클립보드로<br>복사하세요.",
		'PubCaution_en' : "Press Ctrl-C<br>copy to clipboard",

		'Views_ko' : "조회",
		'Views_en' : "View",
		
		'Add_ko' : "추가",
		'Add_en' : "Add",

		'DeleteConfirm_ko' : "삭제 하시겠습니까?",
		'DeleteConfirm_en' : "Are you sure you want to delete<br>this video?",

		'CueDeleteConfirm_ko' : "삭제 하시겠습니까?",
		'CueDeleteConfirm_en' : "Are you sure you want to delete<br>this Cue Point?",

		'ModifyConfirm_ko' : "수정 하시겠습니까?",
		'ModifyConfirm_en' : "Are you sure you want to change?",

		'AddConfirm_ko' : "추가 하시겠습니까?",
		'AddConfirm_en' : "Are you sure you want to add this item?",

		'CueType_A_ko' : "CueType A : 우측 썸네일",
		'CueType_A_en' : "CueType A : Thumbnail in right side",
		
		'CueType_B_ko' : "CueType B : 하단 배너",
		'CueType_B_en' : "CueType B : Banner at the bottom",

		'CueType_C_ko' : "CueType C : 하단 좌우 배너",
		'CueType_C_en' : "CueType C : Banner Bottom right/left ",
		
		'CueType_D_ko' : "CueType D : 하단 배너(Close)",
		'CueType_D_en' : "CueType D : Banner at the bottom(Close) ",
		
		'CuePos_L_ko' : "왼쪽",
		'CuePos_L_en' : "Left",

		'CuePos_R_ko' : "오른쪽",
		'CuePos_R_en' : "Right",	
		init: function() {}
	};

/// End.

	}) (); 
}