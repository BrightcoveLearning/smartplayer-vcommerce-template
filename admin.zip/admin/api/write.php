<?PHP
include 'config.php';
// No Cache ////
header("Expires: Mon,26 Jul 1997 05:00:00 GMT");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-checck=0, pre-check=0",false);
header("Pragma: no-cache"); 
header('P3P: CP="NOI CURa ADMa DEVa TAIa OUR DELa BUS IND PHY ONL UNI COM NAV INT DEM PRE"');

/////////////////////////////////////////////////
function post_request($url, $json) {

	// Convert the data array into URL Parameters like a=b&foo=bar etc.
	$boundary = "---------------------".substr(md5(rand(0,32000)), 0, 10); 
	 
	// parse the given URL
	$url = parse_url($url);
	 
	if ($url['scheme'] != 'http') { 
		die('Error: Only HTTP request are supported !');
	}
	 
	// extract host and path:
	$host = $url['host'];
	$path = $url['path'];
	 
	// open a socket connection on port 80 - timeout: 30 sec
	$fp = fsockopen($host, 80, $errno, $errstr, 30);
	$data ='';
	if ($fp){
	 
		$data .= "--$boundary\r\n"; 
		$data .= "Content-Disposition: form-data; name=\"JSONView\"\r\n\r\n".$json."\r\n"; 
		$data .= "--$boundary\r\n"; 

		// send the request headers:
		fputs($fp, "POST $path HTTP/1.1\r\n");
		fputs($fp, "Host: $host\r\n");
		fputs($fp, "User-Agent:JNJT_Agent\r\n");
		fputs($fp, "Connection:keep-alive\r\n");
		fputs($fp, "Content-Type: multipart/form-data; boundary=$boundary\r\n");
		fputs($fp, "Content-Length: ". strlen($data) ."\r\n");
		fputs($fp, "Connection: close\r\n\r\n");
		fputs($fp, $data);
	 
		// Debug ///
		/*
			$fo = fopen("debug.txt","w");
			fputs($fo, "POST $path HTTP/1.1\r\n");
			fputs($fo, "Host: $host\r\n");
			fputs($fo, "User-Agent:JNJT_Agent\r\n");
			fputs($fo, "Connection:keep-alive\r\n");
			fputs($fo, "Content-Type: multipart/form-data; boundary=$boundary\r\n");
			fputs($fo, "Content-Length: ". strlen($data) ."\r\n");
			fputs($fo, "Connection: close\r\n\r\n");
			fputs($fo, $data);
			fclose($fo);
		*/
		/// Debug
		$result = ''; 
		while(!feof($fp)) {
			// receive the results of the request
			$result .= fgets($fp, 128);
		}
	}
	else { 
		return array(
			'status' => 'err', 
			'error' => "$errstr ($errno)"
		);
	}
	// close the socket connection:
	fclose($fp);
	// split the result header from the content
	$result = explode("\r\n\r\n", $result, 2);
	$header = isset($result[0]) ? $result[0] : '';
	$content = isset($result[1]) ? $result[1] : '';
	// return as structured array:
	return array(
		'status' => 'ok',
		'header' => $header,
		'content' => $content
	);
}
/////////////////////////////////////////////////

	$params = '';
	$rData = '';
	$callback = '';

	foreach ($_POST as $key => $value) {
		if($key=="_req_method") {
			$req_method = $value;
			continue;
		}
		if($key=="callback") {
			$callback = $value;
			continue;
		}
		if($key=="JSONView") {
			$JSONView = stripslashes($value);
			continue;
		}
		if($key=="fError") {
			$fError = $value;
			continue;
		}
	}

	$JSONView = str_replace("#WRITE_TOKEN",$writeToken,$JSONView);
	// $rData = do_post_request($writeApiUrl, $postdata); 
	$result = post_request($writeApiUrl, $JSONView);
	if($result['status']=='ok'){
		$rData = $result['content'];
	}else{
		$rData='';
	}

if(!$rData) {
	$callback = $fError;
	$rData='{"error":"noCntents"}';
}else{
	$rData = ltrim($rData);
}

///////////////////////////////////////////////////////////
if($req_method=="iframe"){
	echo "<html><head><script>\n   top.$callback(";
}

?><?=$rData?><?

if($req_method=="iframe"){
	echo ");</script></head><body></body></html>";
}
////////////////////////////////////////////////////////

?>