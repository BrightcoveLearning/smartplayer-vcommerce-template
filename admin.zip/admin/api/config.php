<?PHP
	$apiUrl = "http://api.brightcove.com/services/library";
	$writeApiUrl = "http://api.brightcove.com/services/post";
	$readToken = "GjGg0W5wxXT5tRa0W1jtCsm1gDg411r9C4P5kbvUpN2OANQ6bdC4Cw..";
	$writeToken= "bLispP_mNDOe1BOZ2nvmn6FugoeWkW7Q78b0mHa9Obk3SsiBuIqZ1w..";

?>