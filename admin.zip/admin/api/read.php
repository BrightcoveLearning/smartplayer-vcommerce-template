<?PHP
include 'config.php';
// No Cache ////
header("Expires: Mon,26 Jul 1997 05:00:00 GMT");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-checck=0, pre-check=0",false);
header("Pragma: no-cache"); 
header('P3P: CP="NOI CURa ADMa DEVa TAIa OUR DELa BUS IND PHY ONL UNI COM NAV INT DEM PRE"');

$params = '';

foreach ($_POST as $key => $value) {
	if($key=="_req_method") {
		$req_method = $value;
		continue;
	}
	if($key=="fError") {
		$fError = $value;
		continue;
	}
	$params .= "$key=$value&";
}

$url = $apiUrl."?".$params."token=".$readToken;
$rData = file_get_contents($url);

if(!$rData) {
	$rData = $fError;
}
$rData = ltrim($rData);

///////////////////////////////////////////////////////////
if($req_method=="iframe"){
	echo "<html><head><script>\n   top.";
}

?><?=$rData?>;

<?
if($req_method=="iframe"){
	echo "</script></head><body></body></html>";
}
////////////////////////////////////////////////////////
?>