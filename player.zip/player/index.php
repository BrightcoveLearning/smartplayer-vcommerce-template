﻿<!DOCTYPE html>
<head>
	<?php
		function getValue($str) {
			$tmp = '';
			$aStr = explode(":",$str);
			$tmp = $aStr[1];
			if(count($aStr)>2) {
				for($i=2;$i<count($aStr);$i++) {
					$tmp .= ":".$aStr[$i];
				}
			}
			$tmp = stripslashes($tmp);
			$tmp = str_replace('"','',$tmp);
			$tmp = trim($tmp);
			return $tmp;
		}
		function get_url_fsockopen( $url ) {
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
			$g = curl_exec($ch);
			curl_close($ch);
			return $g;
		}
		include("token.php");
		$videoId = $_GET["id"];
		if($videoId) {
			$hostUrl = $_SERVER["SERVER_NAME"].$_SERVER["SCRIPT_NAME"]."?id=".$videoId."&ctOff=1&".$_GET["r"];
			$myurl ="http://api.brightcove.com/services/library?command=find_video_by_id&token=".$token."&video_id=".$videoId."&media_delivery=http&video_fields=id,name,shortDescription,creationDate,videoStillURL,length,thumbnailURL,FLVURL&".$_GET["r"];
			// Secure service for FB
			//$myurl ="https://api.brightcove.com/services/library?command=find_video_by_id&token=".$token."&video_id=".$videoId."&media_delivery=http&video_fields=id,name,shortDescription,creationDate,videoStillURL,length,thumbnailURL,FLVURL&".$_GET["r"];
			if (function_exists('curl_init')) {
				$data=get_url_fsockopen($myurl);
			}else{
				$data = file_get_contents($myurl);
			}
			$array = explode(',',$data);
			$name = getValue($array[1]);
			$stillImg = getValue($array[4]);
			$thumnail = getValue($array[5]);
			$videoUrl = getValue($array[7]);
		}
		
	?>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta property="og:type" content="movie" />
	<meta property="og:video:type" content="application/x-shockwave-flash" />
	<meta property="og:title" content="<?=$name?>" />
	<meta property="og:video:width" content="800" />
	<meta property="og:video" content="http://c.brightcove.com/services/viewer/federated_f9/1091831043001?isVid=1&isUI=1&playerKey=AQ~~,AAAA_jYwAak~,f6iN_Qpszc0kPqYKc7iXTOIHqNi9LR4o&videoID=<?=$videoId?>" />
	<meta property="og:video:height" content="500" />
	<meta property="og:description" content="<?=$name?>" />
	<meta property="og:video:secure_url" content="https://secure.brightcove.com/services/viewer/federated_f9/1091831043001?isVid=1&isUI=1&playerKey=AQ~~,AAAA_jYwAak~,f6iN_Qpszc0kPqYKc7iXTOIHqNi9LR4o&videoID=<?=$videoId?>&secureConnections=true" />
	<meta property="og:url" content="<?=$hostUrl?>" />
	<meta property="og:image" content="<?=$thumnail?>" />

	<link href="./css/player.css" type="text/css" rel="stylesheet" />
	<link rel="stylesheet" href="./js/jQuery-UI/jquery-ui.css" />	
	
	<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<!-- // secured service for FB
	<script src="https://code.jquery.com/jquery-1.9.1.js"></script>
-->
	<script src="./js/jQuery-UI/jquery-ui.js"></script>
	<script src="./js/jquery.animate-shadow.js"></script>

	<script src="./js/config.js"></script>
	<script src="./js/ctStyle.js"></script>	
	<script src="./js/ctLanguage.js"></script>
<!-- Unpacked version -->
	<script src="./js/jjfw.util.js"></script>
	<script src="./js/ctList.js"></script>
	<script src="./js/ctCuePoint.js"></script>
	<script src="./js/ctPlayer.js"></script>
	<script src="./js/ctMain.js"></script>
	<script src="./js/ctAnalytics.js"></script>

<!-- // Packed version
	<script src="./js/brObj.js"></script>
-->
	
	<script>
		function init () {
			ctMain.start();
		};

	</script>
</head>

<body onload="init()" bgproperties="fixed" __oncontextmenu="return false" _ondragstart="return false" _onselectstart="return false">
<div class="BrightCoveCT"></div>
</body>
</html>
