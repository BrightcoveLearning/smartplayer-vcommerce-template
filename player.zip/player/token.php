<?php
	// 토큰값은 config.js 밑의 토큰값과 같아야 합니다.
	$token= "GjGg0W5wxXT5tRa0W1jtCsm1gDg411r9C4P5kbvUpN2OANQ6bdC4Cw..";
?>