﻿

var gCtStyle = {
	/* Player UI */
	cueType:"x",
	imgBaseUrl:"x",
	init: function (J) {
		this.cueType=J["cueType"];
		this.imgBaseUrl=J["imgBaseUrl"];
	},
	get: function (str) {
		var rv = '';
		if(!str) rv = this[this.cueType]["self"];
		else rv = this[this.cueType][str];
		if(rv.indexOf("#ImageBaseURL/")>-1)rv =  rv.replace("#ImageBaseURL/",this.imgBaseUrl);
		return rv;
	},
	//////////// CueType A //////////////
	"CueTypeA" : {
		"self": //CuetypeA 
			"position:relative;"+
			"width:auto; height:auto;"+
			"background:white;"
		,
		".PlayerBox":// 플레이어가 들어가는 박스 레이아웃.
			"position:relative;"+
			"border: 2px solid #E8E8E8;"+
			"width:"+(gConfig.Player.width+6)+"px; height:auto;"+
			"margin: 0 auto;"+
			"text-align:left; float:center;"
		,

		".PlayerBox #brPlayer": //플레이어
			"position:relative; margin-top:3px; margin-left:3px; width:"+gConfig.Player.width+"px; height:"+gConfig.Player.height+"px;"
		,
		".PlayerBox .infoBox": //플레이어의 SNS 와 플레이횟수 등록날짜를 감싸는 Wrapper 박스
			"position:relative; bottom:0px; right:0px; width:360px; height:40px; text-align:left; margin-left:auto; "
		,

		".infoBox .videoRegistrationDate":  //비디오 등록 날짜
			"float:left;"+
			"margin-top:10px; margin-right:11px;"+
			"width:auto; height:20px;"+
			"text-align:left; line-height:20px; font-weight:bold;"+
			"font-size:14px; color:#3B3B3B;"
		,
		".infoBox .plays": //플레이 된 횟수 
			"float:left;"+
			"margin-top:10px; margin-left:5px; margin-right:11px; "+
			"width:auto; height:20px;"+
			"text-align:left; line-height:20px; font-weight:bold;"+
			"font-size:14px; color:#3B3B3B;"
		,
		".infoBox .shareBtns": //SNS 공유 버튼
			"margin-top:5px; "+
			"float:left;"+
			"width:101px; height:30px;"+
			"font-size:14px; color:#3B3B3B"
		,
		".cuePointBox"://큐포인트를 감싸는 박스
			"position:absolute;"+
			"top:30px; right:6px; width:300px; height:400px;"+ 
			"overflow:hidden; display:none; z-index:100;"
		,
		".Overlay"://오버레이 되는 iframe을 감싸는 Wrapper 박스
			"position:absolute;"+
			"top:3px; left:3px; width:"+gConfig.Player.width+"px; height:"+(gConfig.Player.height-50)+"px;"+
			"overflow:hidden;"+
			"display:none;"+
			"background-color:rgb(0,0,0);"+
			'z-index:200;'
		,
		".Overlay iframe": //오버레이되는 창
			"position:absolute;"+
			"padding:10px;"+
			"background-color:white;"+
			"top:"+(gConfig.Player.height*40/500)+"px; left:"+(gConfig.Player.width*40/800)+"px; width:"+(gConfig.Player.width-(gConfig.Player.width/8))+"px; height:"+(gConfig.Player.height-(gConfig.Player.height / 3.33))+"px;"
		,
		".Overlay .CloseBtn": //오버레이되는 창의 닫기버튼
			"position:absolute;"+
			"width:30px; height:30px;"+
			"top:"+((gConfig.Player.height*40/500)-15)+"px; left:"+((gConfig.Player.width-(gConfig.Player.width/8))+(gConfig.Player.width*40/800))+"px;"+
			"z-index:210; cursor:pointer;"+
			"background:url(#ImageBaseURL/closeBtn_30.png) top left no-repeat;"
		,
		".spotPointer": //플레이어 컨트롤 박스에 생기는 큐포인트 디스플레이되는 시점을 알려주는 포인트
			"position:absolute; width:5px; height:5px; background-color:rgb(245,11,133);"+
			"top:"+(gConfig.Player.height-40)+"px; left:65px; display:none;"+
			"font-size:0px;"
		,
		".cuePointBox .Arrow.up": //큐포인트의 위 화살표
			"position:absolute; top:4px; right:-200px;"+ 
			"width:18px; height:11px; z-index:20;"+
			"background:url(#ImageBaseURL/arrow_down_up.png) -54px 0px no-repeat;"
		,
		".cuePointBox .Arrow.down": //큐포인트의 아래 화살표
			"position:absolute; top:4px; right:-200px;"+ 
			"width:18px; height:11px; z-index:20;"+
			"background:url(#ImageBaseURL/arrow_down_up.png) -18px 0px no-repeat;"
		,
		".cuePointItemsBox": //큐포인트의 Item들을 감싸는 박스
			"position:absolute;"+
			"top:20px; right:0px; width:300px; height:352px;"+
			"z-index:50;"+
			"overflow:hidden;"
		,
		".cuePointItem": //큐포인트 Item
			"position:absolute;"+
			"top:0px; right:0px; width:270px; height:83px;"+
			//"border:1px solid rgba(255,255,255,0.2);"
			"border:1px solid white;"
		,
		".cuePointItem .itemTable": //큐포인트의 이미지와 텍스트를 감싸는 박스
			"border:none; position:absolute;"+
			"width:270px; height:83px;"+
			//"background-color:rgba(47,47,47,0.7);"
			"background-color:rgb(47,47,47);"+
			'-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=70)";'+ /* IE 8 */
			'filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=70);'+ /* IE 7 and olders */
			'opacity: .7;'
		,
		".cuePointItem .Cover": //큐포인트 위에 덮히는 커버(클릭시 새창이 열리게 하기위한)
			"border:none; position:absolute; cursor:pointer;"+
			//"background-color:rgba(0,0,0,0.01);"+
			"background-color:rgb(0,0,0);"+
			
			'-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";'+ /* IE 8 */
			'filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);'+ /* IE 7 and olders */
			'opacity: .0;'+ 
			"width:270px; height:83px;"
		,

		".cuePointItem .itemTable .tdImg": //큐포인트의 이미지를 감싸는 Wrapper
			"border:0px; width:104px;"+
			"font-size:0px;"
		,
		".cuePointItem .itemTable .tdImg > img": //큐포인트의 이미지
			"margin:4px 4px 4px 4px;"+
			"width:100px; height:75px;"
		,
		".cuePointItem .itemTable .tdText": //큐포인트의 텍스트
			"vertical-align:top;"+
			"width:150px; padding:4px 4px 4px 4px;"+
			"font-size:"+gConfig.Player.CuePointFontSize+"px; text-align:left; line-height:18px; color:rgb(220,220,220);"
		
	},
	//////////// CueType B //////////////
	"CueTypeB" : {
		"self"://CueTypeB
			"position:relative;"+
			"width:auto; height:auto;"+
			"background:white;"
		,
		".PlayerBox"://큐타입A와 같음
			"position:relative;"+
			"border: 2px solid #E8E8E8;"+
			"width:"+(gConfig.Player.width+6)+"px; height:auto;"+
			"margin: 0 auto;"+
			"text-align:left; float:center;"
		,

		".PlayerBox #brPlayer": //큐타입A와 같음
			"position:relative; margin-top:3px; margin-left:3px; width:"+gConfig.Player.width+"px; height:"+gConfig.Player.height+"px;"
		,
		".PlayerBox .infoBox"://큐타입A와 같음
			"position:relative; bottom:0px; right:0px; width:360px; height:40px; text-align:left; margin-left:auto; "
		,

		".infoBox .videoRegistrationDate": //큐타입A와 같음
			"float:left;"+
			"margin-top:10px; margin-right:11px;"+
			"width:auto; height:20px;"+
			"text-align:left; line-height:20px; font-weight:bold;"+
			"font-size:14px; color:#3B3B3B;"
		,
		".infoBox .plays": //큐타입A와 같음
			"float:left;"+
			"margin-top:10px; margin-left:5px; margin-right:11px; "+
			"width:auto; height:20px;"+
			"text-align:left; line-height:20px; font-weight:bold;"+
			"font-size:14px; color:#3B3B3B;"
		,
		".infoBox .shareBtns"://큐타입A와 같음
			"margin-top:5px; "+
			"float:left;"+
			"width:101px; height:30px;"+
			"font-size:14px; color:#3B3B3B"
		,
		".cuePointBox": //큐타입A와 같음
			"position:absolute;"+
			"bottom:52px; left:"+(gConfig.Player.width/10)+"px; width:"+(gConfig.Player.width-(gConfig.Player.width/5))+"px; height:"+(gConfig.Player.height / 5)+"px;"+
			"overflow:hidden;"+
			"display:block;"+
			"z-index:100;"
		,
		".Overlay"://큐타입A와 같음
			"position:absolute;"+
			"top:3px; left:3px; width:"+gConfig.Player.width+"px; height:"+(gConfig.Player.height-50)+"px;"+
			"overflow:hidden;"+
			"display:none;"+
			//"background-color:rgba(0,0,0,0.3);"+
			"background-color:rgb(0,0,0);"+
			'-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=30)";'+ /* IE 8 */
			'filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=30);'+ /* IE 7 and olders */
			'opacity: .3; z-index:200;'
		,
		".Overlay iframe": //오버레이되는 창
			"position:absolute;"+
			"padding:10px;"+
			"background-color:white;"+
			"top:"+(gConfig.Player.height*40/500)+"px; left:"+(gConfig.Player.width*40/800)+"px; width:"+(gConfig.Player.width-(gConfig.Player.width/8))+"px; height:"+(gConfig.Player.height-(gConfig.Player.height / 3.33))+"px;"
		,
		".Overlay .CloseBtn": //오버레이되는 창의 닫기버튼
			"position:absolute;"+
			"width:30px; height:30px;"+
			"top:"+((gConfig.Player.height*40/500)-15)+"px; left:"+((gConfig.Player.width-(gConfig.Player.width/8))+(gConfig.Player.width*40/800))+"px;"+
			"z-index:210; cursor:pointer;"+
			"background:url(#ImageBaseURL/closeBtn_30.png) top left no-repeat;"
		,
		".spotPointer"://큐타입A와 같음
			"position:absolute; width:5px; height:5px; background-color:rgb(245,11,133);"+
			"top:"+(gConfig.Player.height-40)+"px; left:65px; display:none;"+
			"font-size:0px;"
		,
		".cuePointItemsBox"://큐타입A와 같음
			"position:absolute;"+
			"top:5px; left:2px; width:"+(gConfig.Player.width-(gConfig.Player.width/5+4))+"px; height:"+((gConfig.Player.height / 5)-7)+"px;"+
			"overflow:hidden;"
		,
		".cuePointItem"://큐타입A와 같음
			"position:absolute;"+
			"top:0px; left:0px; width:"+(gConfig.Player.width-(gConfig.Player.width/5+8))+"px; height:"+((gConfig.Player.height / 5)-10)+"px;"+
			"border:1px solid white;"
		,
		".cuePointItem .itemTable"://큐타입A와 같음
			"border:none; position:absolute;"+
			"width:"+(gConfig.Player.width-(gConfig.Player.width/5+8))+"px; height:"+((gConfig.Player.height / 5)-10)+"px;"+
			//"background-color:rgba(47,47,47,0.9);"
			"background-color:rgb(47,47,47);"+
			'-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=90)";'+ /* IE 8 */
			'filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=90);'+ /* IE 7 and olders */
			'opacity: .9;'
		,
		".cuePointItem .Cover"://큐타입A와 같음
			"border:none; position:absolute; cursor:pointer;"+
			//"background-color:rgba(0,0,0,0.01);"+
			"background-color:rgb(0,0,0);"+
			'-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";'+ /* IE 8 */
			'filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);'+ /* IE 7 and olders */
			'opacity: .0;'+
			"width:"+(gConfig.Player.width-(gConfig.Player.width/5+8))+"px; height:"+((gConfig.Player.height / 5)-10)+"px;"
		,

		".cuePointItem .itemTable .tdImg"://큐타입A와 같음
			"border:0px;"+
			"float:left;"+
			"font-size:0px;"
		,
		".cuePointItem .itemTable .tdImg > img"://큐타입A와 같음
			"margin:2px 2px 2px 2px;"+
			"width:"+((gConfig.Player.width/2)+50)+"px; height:"+((gConfig.Player.height / 5)-14)+"px;"
		,

		".cuePointItem .itemTable .tdText"://큐타입A와 같음
			"vertical-align:top;"+
			"width:"+((gConfig.Player.width-(gConfig.Player.width/5+8))-((gConfig.Player.width/2)+50+4))+"px; padding:4px 4px 4px 4px;"+
			"font-size:"+gConfig.Player.CuePointFontSize+"px; text-align:left; line-height:"+gConfig.Player.CuePointFontLineHeight+"px; color:rgb(220,220,220);"
		
	},
	
		//////////// CueType C //////////////
	"CueTypeC" : {
		"self"://CueTypeC
			"position:relative;"+
			"width:auto; height:auto;"+
			"background:white;"
		,
		".PlayerBox"://큐타입A와 같음
			"position:relative;"+
			"border: 2px solid #E8E8E8;"+
			"width:"+(gConfig.Player.width+6)+"px; height:auto;"+
			"margin: 0 auto;"+
			"text-align:left; float:center;"
		,

		".PlayerBox #brPlayer": //큐타입A와 같음
			"position:relative; margin-top:3px; margin-left:3px; width:"+gConfig.Player.width+"px; height:"+gConfig.Player.height+"px;"
		,
		".PlayerBox .infoBox"://큐타입A와 같음
			"position:relative; bottom:0px; right:0px; width:360px; height:40px; text-align:left; margin-left:auto; "
		,

		".infoBox .videoRegistrationDate": //큐타입A와 같음
			"float:left;"+
			"margin-top:10px; margin-right:11px;"+
			"width:auto; height:20px;"+
			"text-align:left; line-height:20px; font-weight:bold;"+
			"font-size:14px; color:#3B3B3B;"
		,
		".infoBox .plays": //큐타입A와 같음
			"float:left;"+
			"margin-top:10px; margin-left:5px; margin-right:11px; "+
			"width:auto; height:20px;"+
			"text-align:left; line-height:20px; font-weight:bold;"+
			"font-size:14px; color:#3B3B3B;"
		,
		".infoBox .shareBtns"://큐타입A와 같음
			"margin-top:5px; "+
			"float:left;"+
			"width:101px; height:30px;"+
			"font-size:14px; color:#3B3B3B"
		,
		".Overlay"://큐타입A와 같음
			"position:absolute;"+
			"top:3px; left:3px; width:"+gConfig.Player.width+"px; height:"+(gConfig.Player.height-50)+"px;"+
			"overflow:hidden;"+
			"display:none;"+
			//"background-color:rgba(0,0,0,0.3);"+
			"background-color:rgb(0,0,0);"+
			'-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=30)";'+ /* IE 8 */
			'filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=30);'+ /* IE 7 and olders */
			'opacity: .3; z-index:200;'
		,
		".Overlay iframe": //오버레이되는 창
			"position:absolute;"+
			"padding:10px;"+
			"background-color:white;"+
			"top:"+(gConfig.Player.height*40/500)+"px; left:"+(gConfig.Player.width*40/800)+"px; width:"+(gConfig.Player.width-(gConfig.Player.width/8))+"px; height:"+(gConfig.Player.height-(gConfig.Player.height / 3.33))+"px;"
		,
		".Overlay .CloseBtn": //오버레이되는 창의 닫기버튼
			"position:absolute;"+
			"width:30px; height:30px;"+
			"top:"+((gConfig.Player.height*40/500)-15)+"px; left:"+((gConfig.Player.width-(gConfig.Player.width/8))+(gConfig.Player.width*40/800))+"px;"+
			"z-index:210; cursor:pointer;"+
			"background:url(#ImageBaseURL/closeBtn_30.png) top left no-repeat;"
		,
		".spotPointer"://큐타입A와 같음
			"position:absolute; width:5px; height:5px; background-color:rgb(245,11,133);"+
			"top:"+(gConfig.Player.height-40)+"px; left:65px; display:none;"+
			"font-size:0px;"
		,
		".cuePointBox_L": //큐포인트가 디스플레이되는 왼쪽 방향 큐포인트를 감싸는 Wrapper
			"position:absolute;"+
			"left:2px; bottom:50px; width:"+gConfig.Player.width*328/800+"px; height:"+gConfig.Player.height*450/500+"px;"+
			"overflow:hidden;"+
			"display:block;"+
			"z-index:100;"
		,
		".cuePointItemsBox_L": //큐포인트의 왼쪽방향의 아이템들을 감싸는 Wrapper
			"position:absolute;"+
			"bottom:5px; left:2px; width:"+gConfig.Player.width*324/800+"px; height:"+gConfig.Player.height*445/500+"px;"+
			"overflow:hidden;"
		,
		".cuePointItem_L": //왼쪽에서 디스플레이되는 큐포인트 아이템
			"position:absolute;"+
			"left:-450px; width:auto; height:auto;"		
		,
		".cuePointBox_R": //큐포인트가 디스플레이되는 오른쪽 방향 큐포인트를 감싸는 Wrapper
			"position:absolute;"+
			"right:2px; bottom:50px; width:"+gConfig.Player.width*328/800+"px; height:"+gConfig.Player.height*450/500+"px;"+
			"overflow:hidden;"+
			"display:block;"+
			"z-index:100;"
		,
		".cuePointItemsBox_R": //큐포인트의 오른쪽 방향의 아이템들을 감싸는 Wrapper
			"position:absolute;"+
			"bottom:5px; left:2px; width:"+gConfig.Player.width*324/800+"px; height:"+gConfig.Player.height*445/500+"px;"+
			"overflow:hidden;"
		,
		".cuePointItem_R"://오른쪽에서 디스플레이되는 큐포인트 아이템
			"position:absolute;"+
			"left:850px; width:auto; height:auto;"			
		,
		
		".cuePointItem_L .itemTable": //왼쪽큐포인트의 이미지를 감싸는 Wrapper
			"border:none; position:absolute;"+
			"width:auto; bottom:0px;"
		,
		".cuePointItem_L .Cover": //왼쪽 큐포인트를 덮는 커버(클릭시 새창이 열리게하기 위한)
			"border:none; position:absolute; cursor:pointer;"+
			//"background-color:rgba(0,0,0,0.01);"+
			"background-color:rgb(0,0,0);"+
			'-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";'+ /* IE 8 */
			'filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);'+ /* IE 7 and olders */
			'opacity: .0;'+
			"width:"+gConfig.Player.width*400/800+"px; height:100%;"
		,

		".cuePointItem_L .itemTable .tdImg": //왼쪽 큐포인트이미지를 감싸는 Wrapper
			"border:0px;"
		,
		".cuePointItem_L .itemTable .tdImg > img": //왼쪽 큐포인트이미지
			"margin:4px 4px 4px 4px;"+
			"width:auto; height:auto;"
		,
		".cuePointItem_R .itemTable": //오른쪽 큐포인트의 이미지를 감싸는 Wrapper
			"border:none; position:absolute;"+
			"width:auto; bottom:0px;"
		,
		".cuePointItem_R .Cover"://오른쪽 큐포인트를 덮는 커버(클릭시 새창이 열리게하기 위한)
			"border:none; position:absolute; cursor:pointer;"+
			//"background-color:rgba(0,0,0,0.01);"+
			"background-color:rgb(0,0,0);"+
			'-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";'+ /* IE 8 */
			'filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);'+ /* IE 7 and olders */
			'opacity: .0;'+
			"width:"+gConfig.Player.width*400/800+"px; height:100%"
		,

		".cuePointItem_R .itemTable .tdImg"://오른쪽 큐포인트이미지를 감싸는 Wrapper
			"border:0px;"
		,
		".cuePointItem_R .itemTable .tdImg > img"://오른쪽 큐포인트이미지
			"margin:4px 4px 4px 4px;"+
			"width:auto; height:auto;"
		
	},

	//////////// CueType D //////////////
	"CueTypeD" : {
		"self"://CueTypeD
			"position:relative;"+
			"width:auto; height:auto;"+
			"background:white;"
		,
		".PlayerBox"://큐타입A와 동일
			"position:relative;"+
			"border: 2px solid #E8E8E8;"+
			"width:"+(gConfig.Player.width+6)+"px; height:auto;"+
			"margin: 0 auto;"+
			"text-align:left; float:center;"
		,

		".PlayerBox #brPlayer": //큐타입A와 동일
			"position:relative; margin-top:3px; margin-left:3px; width:"+gConfig.Player.width+"px; height:"+gConfig.Player.height+"px;"
		,
		".PlayerBox .infoBox"://큐타입A와 동일
			"position:relative; bottom:0px; right:0px; width:360px; height:40px; text-align:left; margin-left:auto; "
		,

		".infoBox .videoRegistrationDate": //큐타입A와 동일
			"float:left;"+
			"margin-top:10px; margin-right:11px;"+
			"width:auto; height:20px;"+
			"text-align:left; line-height:20px; font-weight:bold;"+
			"font-size:14px; color:#3B3B3B;"
		,
		".infoBox .plays": //큐타입A와 동일
			"float:left;"+
			"margin-top:10px; margin-left:5px; margin-right:11px; "+
			"width:auto; height:20px;"+
			"text-align:left; line-height:20px; font-weight:bold;"+
			"font-size:14px; color:#3B3B3B;"
		,
		".infoBox .shareBtns"://큐타입A와 동일
			"margin-top:5px;"+
			"float:left;"+
			"width:101px; height:30px;"+
			"font-size:14px; color:#3B3B3B"
		,
		".cuePointBox"://큐타입A와 동일
			"position:absolute;"+
			"bottom:52px; left:"+(gConfig.Player.width/10)+"px; width:"+(gConfig.Player.width-(gConfig.Player.width/5)+10+15)+"px; height:"+(gConfig.Player.height / 5 + 10+15)+"px;"+
			"overflow:hidden;"+
			"display:block;"+
			"z-index:100;"
		,
		".Overlay"://큐타입A와 동일
			"position:absolute;"+
			"top:3px; left:3px; width:"+gConfig.Player.width+"px; height:"+(gConfig.Player.height-50)+"px;"+
			"overflow:hidden;"+
			"display:none;"+
			//"background-color:rgba(0,0,0,0.3);"+
			"background-color:rgba(0,0,0);"+
			'-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=30)";'+ /* IE 8 */
			'filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=30);'+ /* IE 7 and olders */
			'opacity: .3; z-index:200;'
		,
		".Overlay iframe": //오버레이되는 창
			"position:absolute;"+
			"padding:10px;"+
			"background-color:white;"+
			"top:"+(gConfig.Player.height*40/500)+"px; left:"+(gConfig.Player.width*40/800)+"px; width:"+(gConfig.Player.width-(gConfig.Player.width/8))+"px; height:"+(gConfig.Player.height-(gConfig.Player.height / 3.33))+"px;"
		,
		".Overlay .CloseBtn": //오버레이되는 창의 닫기버튼
			"position:absolute;"+
			"width:30px; height:30px;"+
			"top:"+((gConfig.Player.height*40/500)-15)+"px; left:"+((gConfig.Player.width-(gConfig.Player.width/8))+(gConfig.Player.width*40/800))+"px;"+
			"z-index:210; cursor:pointer;"+
			"background:url(#ImageBaseURL/closeBtn_30.png) top left no-repeat;"
		,	
		".cuePointItem .cuePointCloseBtn": //큐포인트의 닫기버튼
			"position:absolute;"+
			"width:20px; height:20px;"+
			"top:-10px; right:-10px;"+
			"z-index:210; cursor:pointer;"+
			"background:url(#ImageBaseURL/closeBtn_20.png) top left no-repeat;"
		,	
		".spotPointer"://큐타입A와 동일
			"position:absolute; width:5px; height:5px; background-color:rgb(245,11,133);"+
			"top:"+(gConfig.Player.height-40)+"px; left:65px; display:none;"+
			"font-size:0px;"
		,
		".cuePointItemsBox"://큐타입A와 동일
			"position:absolute;"+
			" left:2px; width:"+(gConfig.Player.width-(gConfig.Player.width/5+4)+10)+"px; height:"+(gConfig.Player.height / 5 + 10+15)+"px;"+
			"overflow:hidden;"
		,
		".cuePointItem"://큐타입A와 동일
			"position:absolute;"+
			"top:0px; left:0px; width:"+(gConfig.Player.width-(gConfig.Player.width/5+8))+"px; height:"+((gConfig.Player.height / 5)-10)+"px;"+
			"border:1px solid white;"
		,
		".cuePointItem .itemTable"://큐타입A와 동일
			"border:none; position:absolute;"+
			"width:"+(gConfig.Player.width-(gConfig.Player.width/5+8))+"px; height:"+((gConfig.Player.height / 5)-10)+"px;"+
			//"background-color:rgba(47,47,47,0.9);"
			"background-color:rgb(47,47,47);"+
			'-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=90)";'+ /* IE 8 */
			'filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=90);'+ /* IE 7 and olders */
			'opacity: .9;'
		,
		".cuePointItem .Cover"://큐타입A와 동일
			"border:none; position:absolute; cursor:pointer;"+
			//"background-color:rgba(0,0,0,0.01);"+
			"background-color:rgb(0,0,0);"+
			'-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";'+ /* IE 8 */
			'filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);'+ /* IE 7 and olders */
			'opacity: .0;'+
			"width:"+(gConfig.Player.width-(gConfig.Player.width/5+8))+"px; height:"+((gConfig.Player.height / 5)-6)+"px;"
		,

		".cuePointItem .itemTable .tdImg"://큐타입A와 동일
			"border:0px;"+
			"float:left;"+
			"font-size:0px;"
		,
		".cuePointItem .itemTable .tdImg > img"://큐타입A와 동일
			"margin:2px 2px 2px 2px;"+
			"width:"+(gConfig.Player.width-(gConfig.Player.width/5+8))+"px; height:"+((gConfig.Player.height / 5)-10)+"px;"
		
	}
}
