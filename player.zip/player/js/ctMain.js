
if(!window['ctMain']) { 
	ctMain = {}; 
	( function (_O) {

	_U = jjfw.Util;

	_O.Vars = {
		param:{},
		apiBaseUrl: 'x'
	};

	_O.reload= function (J) {
		var params = '';
		for(var key in J) {
			if(J[key]) params+= key+'='+J[key]+'&';
		}
		document.location.href="?"+params+"r="+Math.random();
	};
	
	_O.start=function (J) {
		var v= this.Vars, showCategory=false;
		var url = document.location.href.split("?")[0];
		_O.Vars.apiBaseUrl = url.substring(0,(url.lastIndexOf("/")+1));
		if(J) {
			v.param = J;
			if(J["apiBaseUrl"]) {
				_O.Vars.apiBaseUrl = J["apiBaseUrl"];
			}
			//if(J["cueType"]) {
			//	gConfig.Player.CuePointType="CueType"+J["cueType"];
			//}
			if(J["cueData"]) {
				gConfig.Player.showInfoSNS=false;
			}
			if(J["playerWrapper"]){
				gConfig.Player.showPlayerWrapper=false;
			}
			
		}else{
			v.param = _U.getUrlParam_Json();
		}
		if(typeof v.param.id == 'undefined' || typeof v.param.ctOff == 'undefined') {
			showCategory=true;
		}
		ctAnalytics.TrackPage.view(v.param);
		_O.Html.set(showCategory);
		_O.Search.setEvent();
		_O.Search.setQuery(v.param.query);

		v.param.vId = v.param.id;
		if(!v.param.page) v.param.page= 0;
		if(v.param.id) {
			ctPlayer.start({vId:v.param.id});
		}
		if(showCategory) {
			ctList.start(v.param,ctPlayer);
		}
	};

	_O.URL = {
		getSearchUrl: function (J) {
			var api = gConfig.BrightCoveAPI;
			var url = api.ApiBaseUrl+"?"+
				"command=search_videos"+
				"&token="+api.Token+
				"&all=tag:"+api.CMTV_Tag+
				"&sort_by=MODIFIED_DATE:DESC"+
				(J.query 
					? ( "&any=tag:ct_"+J.query+"&any=display_name:"+J.query + "&any="+J.query )
					: (J.ct ? (J.ct=="all" ? '': "&any=tag:ct_"+J.ct) : '')
				)+
				"&page_size="+api.PageSize+
				"&page_number="+J.page+
				"&media_delivery="+api.MediaDelivery+
				"&video_fields="+api.SearchFields+
				"&get_item_count=true"+
				"&callback="+J.callback+
				"&r="+Math.random();
			return url;
		},
		getFindUrl: function(J){
			var api = gConfig.BrightCoveAPI;
			var url = api.ApiBaseUrl+"?"+
				"command=find_video_by_id"+
				"&token="+api.Token+
				"&video_id="+J.vId+
				"&media_delivery="+api.MediaDelivery+
				"&video_fields="+api.SearchFields+
				"&callback="+J.callback+
				"&r="+Math.random();
			return url;
		}
	};

	_O.Html = {
		set: function (showCT) {
			if(showCT) {
				var str=
					this.getHeader()+
					this.getSearchBox()+
					this.getPlayerBox()+
					this.getCtListBox()+
					this.getFooter();
			}else {
				var str=
					this.getPlayerBox();
			}
			$('.BrightCoveCT').html(str);
			if(showCT) this.setConfigCss(gConfig.SetCss);
		},
		setConfigCss: function(J){
			$(".SearchBox").css("width",gConfig.Player.width);
			$(".SearchBox .Title").css("width",gConfig.Player.width-200);
			$(".Header").css({
				"background":J.logoBGColorImg,
				"background-size":"100% 100%"
			});
			$(".Header .logoBox").css("width",gConfig.Player.width);
			$(".Header .logo").css({
				"background":J.logoImgUrl,
				"background-size":"100% 100%"
			});
			$(".Footer").css({
				"background":J.footerBGColorImg,
				"background-size":"100% 100%"
			});
			$(".ctListBox").css("width",gConfig.Player.width+10);
			$(".ctListBox .listBox").css("width",gConfig.Player.width*560/800);
			$(".ctListBox .listBox").css("margin-left",gConfig.Player.width*50/800);
		},
		getHeader: function () {
			var str =
				'<div class="Header">'+
					'<div class="logoBox">'+
						'<div class="logo"></div>'+
					'</div>'+
				'</div>';
			return str;
		},
		getSearchBox: function () {
			var str =
				'<div class="SearchBox">'+
					'<div class="Title EllipsisText"></div>'+
					'<div id="search">'+
						'<input type="text" maxlength="128" id="edit-search-theme-form-3" name="search_form" size="15" value="" title="Enter the terms you wish to search for." class="form-text">'+
						'<input type="submit" name="op" id="edit-submit-1" value="Search" class="form-submit" >'+
					'</div>'+
				'</div>';
			return str;
		},
		getPlayerBox: function () {
			var str =
				'<div jClass="PlayerBox">'+
					'<div jClass="Overlay">'+						
						'<div jClass="CloseBtn" jBtn="on"></div>'+
						'<iframe src="" noresize="yes" frameborder="0" marginheight="0" marginwidth="0" scrolling="auto" name="ifOverlay"></iframe>'+
					'</div>'+
					'<div id="brPlayer"></div>'+
					((gConfig.Player.showInfoSNS && (gConfig.Player.showPlayerWrapper || gConfig.Player.showPubCodeInfoSNS)) ? '<div jClass="infoBox"></div>' : '')+
				'</div>';
			return str;
		},
		getCtListBox: function () {
			var str =
				'<div class="ctListBox">'+
					'<div class="left_tabs">'+
						'<div class="menu"></div>'+
					'</div>'+
					'<div class="listBox">'+
						'<div class="pageBox">'+
						'</div>'+
						'<div class="list">'+
						'</div>'+
						'<div class="pageBox">'+
						'</div>'+
					'</div>'+
				'</div>';
			return str;
		},
		getFooter: function () {
			var str =
				'<div class="Footer"></div>';
			return str;
		}
	};

	_O.Search= {
		setQuery: function (query) {
			if(typeof query != 'undefined') {
				$("#edit-search-theme-form-3").val(query);
			}else{
				$("#edit-search-theme-form-3").val('');
			}
		},
		getQuery: function () {
			return $("#edit-search-theme-form-3").val();
		},
		go: function (query) {
			var query = this.getQuery();
			_U.setCookie('BrightcoveBackUrl',document.location.href);
			ctMain.reload({page:0,ctName:'all',query:query});
		},
		setEvent: function () {
			$("#edit-submit-1").on("mouseover",function () {
					$(this).css({backgroundPositionX:$(this).width()*-1});
			});
			$("#edit-submit-1").on("mouseout",function () { 
					$(this).css({backgroundPositionX:0});
			});
			$("#edit-submit-1").on("click",function (e) {
				ctMain.Search.go(); 
			});
			$(document).keypress(function (e) {  
				if(e.which == 13 && e.target && e.target.id =='edit-search-theme-form-3' ) {
					ctMain.Search.go();
				}
			});
		}
	};

	}) (ctMain); 
}
	