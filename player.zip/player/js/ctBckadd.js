function setSnsDialog() {			//Sean added at 3.June for Naver Blog	
	
	$("#sns_dialog").dialog({
		resizable: false,
		autoOpen: false,
		modal: true,
		show: "fade",
		hide: "fade",
		width:"auto",
		height:"auto",
		buttons:{ 
			"Cancel":function() { 
				$( this ).dialog( "close" );
			}
		}
	});

	var snscode = '<a href="'+_getHostUrl()+'?id='+ctPlayer.Data.item['id']+'"><img src="'+ctPlayer.Data.item["videoStillURL"]+'" alt="'+ctPlayer.Data.item["name"]+'" title="'+ctPlayer.Data.item["name"]+'"></a>';

	var s='';
	s+=
		'<textarea id="sns_textArea1" rows="10" cols="20" name="publishCode" class="textArea"></textarea>'+
		'<div class="btn copyBtn" >'+
			'<div class="btn left"></div>'+
			'<div class="btn middle">Select</div>'+
			'<div class="btn right"></div><br><br>'+ctLanguage.getMsg({msg:'SnsCaution'}) +
		'</div>';
	
	$("#sns_dialog").html(s);								
	$("#sns_dialog .textArea").val(snscode);
	$(".copyBtn").on(
		"click", 
		function(){
			$("#sns_textArea1")[0].focus();
			$("#sns_textArea1")[0].select();
			
		}
	);
	
	$("#sns_dialog").dialog("open");				
	
	function _getHostUrl() {
		return document.location.href.split("?")[0];
	}				
}