
var gConfig = {

	Security: {
		protocol: "http"
	},

	Categories: {
		tags: [ "all", "women", "men", "kids", "family", "gift", "life"]
	},
	SetCss: {
		playerBorderColor:"#E8E8E8", // Player Wrapper Box Border Color
		selectItemFocusColor:"#FAAC58", // List Select Item Focus Color
		listItemImgWidth:128, // List's Items Image Width
		listItemImgHeight:72, // List's Items Image Height
		listItemNameHeight:28,// List's Items Title Box Height
		listItemNameFontSize:14,  //List's Items Title Font Size
		listItemNameFontLineHeight:14,  //List's Items Title Font Line-Height
		listItemNameFontColor:"#3B3B3B", //List's Items Title Font-Color
		listPageBoxOffBGColor:"#F1F1F1", // List Page Normal Background-color 
		listPageBoxOffFontColor:"#5B5B5B", //List Page Normal Font-color
		listPageBoxOnBGColor:"#5B5B5B",  //List Page Focus Background-color 
		listPageBoxOnFontColor:"#F1F1F1", //List Page Focus Font-color
		logoBGColorImg:"url(./images/header-top.gif) repeat-x top left", //Logo Background Image Url
		logoImgUrl:"url(./images/logo-corporate-new.png) no-repeat top left", //Logo Image Url
		footerBGColorImg:"url(./images/footer.png) repeat top left", //Footer Image Url
		//end//
		end:0
	},
//https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fbcove.me%2F9xrxh4c3&t=IPKN+%E1%84%8C%E1%85%B5%E1%86%AB%E1%84%83%E1%85%A9%E1%86%BC+%E1%84%91%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%83%E1%85%A6%E1%84%8B%E1%85%B5%E1%84%89%E1%85%A7%E1%86%AB+kit
	Player: {
		
		showInfoSNS: true, // show Player Info (Created date and Number of Play, and twitter and facebook 
		showPubCodeInfoSNS: false, //PubCode Player InfoSNS off   ******** P.S ---- Don't Modify ********
		showCuePoint: true,
		showPlayerWrapper: true, // PubCode Player Wrapper Border on/off
		CuePointType: "CueTypeA",

		/// SinglePlayer ID & SinglePlayer KEY ///
		SinglePlayerID:"2057499176001",
		SinglePlayerKEY:"AQ~~,AAAA_jYwAak~,f6iN_Qpszc3ypDaxWlg_4aUlMKWfwWeY",
		/// ChromelessPlayer ID & ChromelessPlayer KEY ///
		ChromelessPlayerID:"2079935948001",
		ChromelessPlayerKey:"AQ~~,AAAA_jYwAak~,f6iN_Qpszc24AqdImhbFbquNHNB5PFRO",

		////  Player CSS Style  /////
		width:800,//Player's Width
		height:600,//Player's Height
		
		/// Cue Point Text ///
		CuePointFontSize:14,  //CueTypeA & CueTypeB Cue Point Font-Size
		CuePointFontLineHeight:18,  //CueTypeA & CueTypeB Cue Point Font Line-Height

		///CueType A///
		aTypeCuePointBoxTop:30, //CueTypeA's CuePoint Display Box Wrapper Top Position

		///CueType B///
		
		///CueType C///

		///CueType D///


		//end//
		end:0
	},
	LanguageCode: 'en',// 한국어(ko), 영어(en)
	CuePoint: {
		CueTypeA: {
			animationSpeed: 400,	// animation moving time (ms): 
			showTime: 2000			// Show time
		},
		CueTypeB: {
			animationSpeed: 1200,	// animation moving time (ms): 
			showTime: 10000			// Show time
		},
		CueTypeC: {
			animationSpeed: 1200,	// animation moving time (ms): 
			showTime: 10000			// Show time
		},
		CueTypeD: {
			animationSpeed: 1200,	// animation moving time (ms): 
			showTime: 10000			// Show time
		}
	},
	ADPopup: {
		width: 900, // New Windows Open Width
		height: 600	//New Windows Open Height
	},

	BrightCoveAPI: {
		CMTV_Tag: "cm_tv",
		ApiBaseUrl: "http://api.brightcove.com/services/library",
//		ApiBaseUrl: "https://api.brightcove.com/services/library",
		Token : "GjGg0W5wxXT5tRa0W1jtCsm1gDg411r9C4P5kbvUpN2OANQ6bdC4Cw..",//// 토큰값은 token.php 의 토큰값과 같아야 합니다.
		PageSize: 9, // List Display Item Number
		SearchFields: "id,name,shortDescription,creationDate,playsTotal,videoStillURL,length,thumbnailURL,renditions,tags,customFields,cuePoints,referenceId",
		MediaDelivery:"http"
	},
	Analytics: {
		gaId: "UA-35744930-1" 
	}
};


///// GA log /////////////////////////////////////////////////////////
	var _gaq = _gaq || [];
	_gaq.push(['_setAccount', gConfig.Analytics.gaId]);
	// _gaq.push(['_trackPageview']);
	(function() {
		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	})();
//////////////////////////////////////////////////////////////////////


gConfig.Categories.func = {
	Parent: gConfig.Categories,

	getTag: function (idx) {
		return (this.Parent.tags[idx]?this.Parent.tags[idx]:'');
	},
	getIdx: function (name) {
		if(typeof name == 'undefined') return -1;
		var tags = this.Parent.tags;
		rv = 0; // default is first
		for(var i=0; i<tags.length; i++) {
			if(name.toLowerCase() == tags[i].toLowerCase()) {
				rv = i;
				break;
			}
		}
		return rv;
	}
};