
if(!window['ctPlayer']) { 
	ctPlayer = {}; 
	( function (_O) {

		_U = jjfw.Util;

		_O.start = function (J) {// {id:id}) {
			_O.Data.load(J);
			
		};
		jsOnError=function() {
		};

		_O.Data = {
			id:0,
			item:{},
			load:function(J) {//{ vid:vid }
				this.id=J.vId;
				var url='';
				if(this.id) {
					url= ctMain.URL.getFindUrl({vId:this.id, callback:"ctPlayer.Data.onLoad"}); // --> loadCategory --> loadList
				}else{
					this.onLoad();
					return;
				}
				_U.jcejs({url:url,fonerror:ctPlayer.jsOnError});
			},
			onLoad: function (J) {
				if(!J) {
					alert("No Data");
					return;
				}
				var cueType = _getCueType(J); 
				//console.log('playerCueType='+cueType);
				ctPlayer.Data.item = J;
				ctPlayer.CuePoint= CCtCuePoint[cueType];
				ctPlayer.Player.setPlayer(ctPlayer.Data.id);//ctPlayer.Player.CommercePlayer.setCommercePlayer(ctPlayer.Data.id);
				$(".SearchBox .Title").html(J.name);
				_O.InfoSNS.setHtml();
				_O.Event.set();
				_setCtStyle(cueType);
				_O.CuePoint.setPoints();
				_O.CuePoint.setHtml();
				_O.CuePoint.Event.set();
				ctAnalytics.TrackVideo.init(J);
				ctAnalytics.TrackAD.init(J);

				function _getCueType(J) {
					var cueType = gConfig.Player.CuePointType;
					var tags = J["tags"];
					if(tags) {
						for(var i=0; i<tags.length; i++) {
							if(tags[i].indexOf("cm_cuetype")==0) {
								cueType = "CueType"+(tags[i].substring(tags[i].lastIndexOf("_")+1).toUpperCase());
								break;
							}
						}
					}
					if(!CCtCuePoint[cueType]) cueType = gConfig.Player.CuePointType;
					return cueType;
				}
				function _setCtStyle(cueType) {
					gCtStyle.init({"cueType":cueType,"imgBaseUrl":ctMain.Vars.apiBaseUrl+"images/"});
					$(".BrightCoveCT").attr("style",gCtStyle.get());
					$(".BrightCoveCT [jClass='PlayerBox']").attr("style",gCtStyle.get(".PlayerBox"));
					$(".BrightCoveCT [jClass='PlayerBox'] #brPlayer").attr("style",gCtStyle.get(".PlayerBox #brPlayer"));
					$(".BrightCoveCT [jClass='PlayerBox'] [jClass='infoBox']").attr("style",gCtStyle.get(".PlayerBox .infoBox"));
					$(".BrightCoveCT [jClass='infoBox'] [jClass='plays']").attr("style",gCtStyle.get(".infoBox .plays"));
					$(".BrightCoveCT [jClass='infoBox'] [jClass='videoRegistrationDate']").attr("style",gCtStyle.get(".infoBox .videoRegistrationDate"));
					$(".BrightCoveCT [jClass='infoBox'] [jClass='shareBtns']").attr("style",gCtStyle.get(".infoBox .shareBtns"));
					$(".BrightCoveCT [jClass='Overlay']").attr("style",gCtStyle.get(".Overlay"));
					$(".BrightCoveCT [jClass='Overlay'] iframe").attr("style",gCtStyle.get(".Overlay iframe"));
					$(".BrightCoveCT [jClass='Overlay'] iframe")['animate']({'boxShadow': 'rgb(0,0,0) 10px 10px 15px 0px'});
					$(".BrightCoveCT [jClass='Overlay'] [jClass='CloseBtn']").attr("style",gCtStyle.get(".Overlay .CloseBtn"));
				}
				if(gConfig.Player.showPlayerWrapper==false){
					$(".BrightCoveCT [jClass='PlayerBox']").css("border","0px");
				}	
				this.setConfigCss(gConfig.SetCss);
			},
			setConfigCss: function(J) {
				$(".BrightCoveCT [jClass='PlayerBox']").css("border-color",J.playerBorderColor);
				if(gConfig.LanguageCode == 'ko') $(".BrightCoveCT [jClass='infoBox']").css("width","380px");
			}
		};

		_O.InfoSNS = {
			setHtml : function () {
				var ogData = {};
				ogData.ogTitle = encodeURIComponent(_O.Data.item["name"]);
				ogData.ogSummary = encodeURIComponent(_O.Data.item["shortDescription"]);
				//ogData.ogImage = encodeURIComponent(_O.Data.item["thumbnailURL"]);
				ogData.ogImage = encodeURIComponent(_O.Data.item["videoStillURL"]);
				ogData.ogURL = encodeURIComponent(_getHostUrl()+'?id='+_O.Data.item['id']);	
				if(!gConfig.Player.showInfoSNS) return;
				var str =
					'<div jClass="videoRegistrationDate">'+_getDate(_O.Data.item["creationDate"])+'</div>'+
					'<div jClass="plays">'+_getPlayNum(_O.Data.item["playsTotal"])+'</div>'+
					'<div id="sns_dialog" title="'+ctLanguage.getMsg({msg:'naver_blog'})+'"></div>'+				
					'<div jClass="shareBtns">'+
						this.getTwitterHtml(ogData)+
						this.getFacebookHtml(ogData)+
						this.getNaverHtml(ogData)+
					'</div>';
				
				$(".BrightCoveCT [jClass='PlayerBox'] [jClass='infoBox']").html(str);
				
				function _getHostUrl() {
					return document.location.href.split("?")[0];
				}

				function _getDate(ms) {
					var date = new Date(parseInt(ms));
					return ctLanguage.getMsg({msg:'created'})+': '+parseInt(1900+date.getYear())+"."+_U.getTwoDigit(parseInt(date.getMonth()+1))+'.'+_U.getTwoDigit(parseInt(date.getDate()));
				}
				function _getPlayNum(value) {
					var numValue = value;
					if(numValue == null) numValue = 0;
					return ctLanguage.getMsg({msg:"num_play"})+": "+numValue;
				}
			},
			setSnsDialog: function () {			//Sean added at 3.June for Naver Blog	
				
				$("#sns_dialog").dialog({
					resizable: false,
					autoOpen: false,
					modal: true,
					show: "fade",
					hide: "fade",
					width:"auto",
					height:"auto",
					buttons:{ 
						"Cancel":function() { 
							$( this ).dialog( "close" );
						}
					}
				});

				var snscode = '<a href="'+_getHostUrl()+'?id='+_O.Data.item['id']+'"><img src="'+_O.Data.item["videoStillURL"]+'" alt="'+_O.Data.item["name"]+'" title="'+_O.Data.item["name"]+'"></a>';

				var s='';
				s+=
					'<textarea id="sns_textArea1" rows="10" cols="20" name="publishCode" class="textArea"></textarea>'+
					'<div class="btn copyBtn" >'+
						'<div class="btn left"></div>'+
						'<div class="btn middle">Select</div>'+
						'<div class="btn right"></div><br><br>'+ctLanguage.getMsg({msg:'SnsCaution'}) +
					'</div>';
				
				$("#sns_dialog").html(s);								
				$("#sns_dialog .textArea").val(snscode);
				$(".copyBtn").on(
					"click", 
					function(){
						$("#sns_textArea1")[0].focus();
						$("#sns_textArea1")[0].select();
						
					}
				);
				
				$("#sns_dialog").dialog("open");				
				
				function _getHostUrl() {
					return document.location.href.split("?")[0];
				}				
			},
								
			getNaverHtml: function (ogData) { //Sean added at 3.June for Naver Blog
				var str = 
					'<a href="javascript:ctPlayer.InfoSNS.setSnsDialog();" class="twitter-share-button" data-size="medium" data-count="none"><img src="./images/nhn_blog.png" width="32px" height="32px" border="0px" alt="Share on Naver Blog" /></a>';
				return str;
			},			
			getTwitterHtml: function (ogData) {
				var str = 
					/*'<a href="https://twitter.com/share" class="twitter-share-button" data-size="medium" data-count="none">Tweet</a>'+
					'<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>';*/
					'<a href="http://twitter.com/share?text='+ogData.ogTitle+'&url='+ogData.ogURL+'" title="Share this article on Twitter" class="twitter-share-button" data-size="medium" data-count="none" target="_blank"><img src="./images/1365495372_twitter_32.png" width="32px" height="32px" border="0px" alt="Share on Twitter" /></a>';
					/*'<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>';*/
				return str;
			},
			getFacebookHtml: function (ogData) {
				var str = 
					//'<a name="fb_share" type="button" href="http://www.facebook.com/sharer.php" style="margin-left:5px; top:-5px;">'+
					/*'<a name="fb_share" type="button" href="http://www.facebook.com/sharer.php"></a>'+
					'<script src="http://static.ak.fbcdn.net/connect.php/js/FB.Share" type="text/javascript"></script>';*/
					//'</a>'+
					//'<a name="fb_share" type="button" href="http://www.facebook.com/sharer.php?u='+ogData.ogURL+'&t='+ogData.ogSummary+'" target="_blank"><img src="http://w.sharethis.com/images/facebook_counter.png" height="19px" border="0px" alt="Share on Facebook" /></a>';
					'<a name="fb_share" type="button" title="Share this article on Facebook" style="margin-left:5px;" href="http://www.facebook.com/sharer.php?s=100'+
					'&p[url]='+ogData.ogURL+
					'&p[title]='+ogData.ogTitle+
					'&p[images][0]='+ogData.ogImage+
					'&p[summary]='+ogData.ogSummary+
					'" target="_blank"><img src="./images/1365495582_facebook.png" width="32px" height="32px" border="0px" alt="Share on Facebook" />'+
					'</a>';
					//'<script src="http://static.ak.fbcdn.net/connect.php/js/FB.Share" type="text/javascript"></script>';
					/*'<fb:share-button class="meta">'+
						'<meta name="title" content="'+ogData.ogTitle+'"/>'+
						'<meta name="description" content="'+ogData.ogSummary+'"/>'+
						'<link rel="image_src" href="'+ogData.ogImage+'" />'+
						'<link rel="target_url" href="'+ogData.ogURL+'"/>'+
						'<a name="fb_share" type="button" href="http://www.facebook.com/sharer.php" style="margin-left:5px; top:-5px;" target="_blank"></a>'+
					'</fb:share-button>';*/
					//'<script src="http://static.ak.fbcdn.net/connect.php/js/FB.Share" type="text/javascript"></script>';
				return str;
			}
		};
		_O.Player= {
			Vars:{
				player:0,
				videoPlayer:0,
				experience:0,
				contentEvent:0,
				duration:0
			},
			init: function(){
				var v= this.Vars;
				v.player= 0;
				v.videoPlayer= 0;
				v.experience= 0;
				v.contentEvent= 0;
				v.duration=0;
			},
			play: function () {
				this.Vars.videoPlayer.play();
			},
			pause: function () {
				this.Vars.videoPlayer.pause();
			},
			seek: function (ms) {
				var sec = Math.round(ms / 1000);
				this.Vars.videoPlayer.seek(sec);
			},				
			playerLoaded:function(experienceID){
				//_O.Player.init();
				var v= ctPlayer.Player.Vars;
				v.player = brightcove.api.getExperience(experienceID);
				v.videoPlayer = v.player.getModule(brightcove.api.modules.APIModules.VIDEO_PLAYER);
				v.experience = v.player.getModule(brightcove.api.modules.APIModules.EXPERIENCE);
				v.contentEvent = v.player.getModule(brightcove.api.modules.APIModules.CONTENT);
			},
			playerReady:function(evt){
				var v= ctPlayer.Player.Vars;
				v.videoPlayer.addEventListener(brightcove.api.events.MediaEvent.BEGIN, ctPlayer.Player.playerEvent);
				v.videoPlayer.addEventListener(brightcove.api.events.MediaEvent.CHANGE, ctPlayer.Player.playerEvent);
				v.videoPlayer.addEventListener(brightcove.api.events.MediaEvent.COMPLETE, ctPlayer.Player.playerEvent);
				v.videoPlayer.addEventListener(brightcove.api.events.MediaEvent.ERROR, ctPlayer.Player.playerEvent);
				v.videoPlayer.addEventListener(brightcove.api.events.MediaEvent.PLAY, ctPlayer.Player.playerEvent);
				v.videoPlayer.addEventListener(brightcove.api.events.MediaEvent.PROGRESS, ctPlayer.Player.playerProgress);
				v.videoPlayer.addEventListener(brightcove.api.events.MediaEvent.STOP, ctPlayer.Player.playerEvent);
				v.videoPlayer.addEventListener(brightcove.api.events.MediaEvent.SEEK_NOTIFY, ctPlayer.Player.playerEvent);
			},
			playerProgress:function(evt){
				var ctime = parseFloat(evt.position*1000);
				ctPlayer.CuePoint.progressShow(ctime);
				ctAnalytics.TrackVideo.handleProgress(evt);
			},
			setPlayer: function(id){
				if(typeof brightcove != 'undefined') {
					delete brightcove;
					brightcove = {};
				}
				var item = _O.Data.item;
				var cueType ='';
				for(var i=0; i<item['tags'].length; i++){
					if(item['tags'][i].indexOf("cm_cuetype_") == 0){
						cueType = item['tags'][i].substring(item['tags'][i].lastIndexOf("_")+1).toUpperCase();
					}
				}
				if(cueType != 'C'){
					var s =  ctPlayer.CuePoint.getPlayerObject(id)+(gConfig.Player.showCuePoint ? '<div jClass="cuePointBox"></div>' : '');
				}else{
					var s = ctPlayer.CuePoint.getPlayerObject(id);
					if(gConfig.Player.showCuePoint){
						s+= '<div jClass="cuePointBox_L"></div>'+
							'<div jClass="cuePointBox_R"></div>';
					}else{
						s+= '';
					}
				}
				$(".BrightCoveCT #brPlayer").html(s);
				
				//https code for Facebook app - Sean - 14.Oct.2013
				if(gConfig.Security.protocol=="http")
					_U.jcejs({url:"http://admin.brightcove.com/js/BrightcoveExperiences.js",fonload:ctPlayer.onLoadBrightCove, fonerror:ctPlayer.jsOnError});
				else	
					_U.jcejs({url:"https://sadmin.brightcove.com/js/BrightcoveExperiences.js",fonload:ctPlayer.onLoadBrightCove, fonerror:ctPlayer.jsOnError});

			},
			playerEvent:function(evt){
				var cue = ctPlayer.CuePoint;
				var v= ctPlayer.Player.Vars;
				ctAnalytics.TrackVideo.handleEvent(evt);
				var item = _O.Data.item;
				var cueType ='';
				for(var i=0; i<item['tags'].length; i++){
					if(item['tags'][i].indexOf("cm_cuetype_") == 0){
						cueType = item['tags'][i].substring(item['tags'][i].lastIndexOf("_")+1).toUpperCase();
					}
				}
				switch(evt.type){
					case 'mediaBegin':
						if(cueType != 'C'){
							$("[jClass='cuePointBox']").css("display","block");
							v.duration = evt.duration * 1000;
							setTimeout(function () {
								ctPlayer.CuePoint.Animation.open();
							},500);
						}else{
							$("[jClass='cuePointBox_L']").css("display","block");
							$("[jClass='cuePointBox_R']").css("display","block");
							v.duration = evt.duration * 1000;
							setTimeout(function () {
								ctPlayer.CuePoint.Animation.open();
							},500);
						}
						break;
					case 'mediaStop':
						if(evt.duration-1 <= evt.position){
							ctPlayer.CuePoint.refreshMediaComplete(parseFloat(evt.position*1000));
						}else{
							ctPlayer.CuePoint.refreshMediaStop(parseFloat(evt.position*1000));
						}
						break;
					case 'mediaPlay':
						if(cueType != 'C'){
							$("[jClass='cuePointBox']").css("display","block");
						}else{
							$("[jClass='cuePointBox_L']").css("display","block");
							$("[jClass='cuePointBox_R']").css("display","block");
						}
							ctPlayer.CuePoint.refreshMediaPlay(parseFloat(evt.position*1000));
						break;
					case 'mediaSeekNotify':
						ctPlayer.CuePoint.refreshMediaSeek(parseFloat(evt.position*1000));
						break;
					case 'mediaComplete':
						ctPlayer.CuePoint.refreshMediaComplete(parseFloat(evt.position*1000));
						if(cueType != 'C'){
							$("[jClass='cuePointBox']").css('display','none');
						}else{
							$("[jClass='cuePointBox_L']").css('display','none');
							$("[jClass='cuePointBox_R']").css('display','none');
						}
						break;
					case 'mediaChange':
						break;
				}
			}
		};
		_O.onLoadBrightCove= function () {
			brightcove.createExperiences();
		};

		_O.jsOnError= function () {
		};
		_O.Event= {
			set: function(){
				// onclick="fbs_click()"
				$(".fb_share_button").on("click",function(e) {
					_O.InfoSNS.fbs_click();
				});
			}
		};


	}) (ctPlayer); 
}
