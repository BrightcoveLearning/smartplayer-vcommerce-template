﻿
if(!window['CCtCuePoint']) { 
	CCtCuePoint = {}; 
	( function (_O) {

	_U = jjfw.Util;

	_O.Metadata= {
		length: 6,
		index: {
			prdtId:0,
			prdtPrice:1,
			prdtText:2,
			thumbnailUrl:3,
			targetUrl:4,
			targetMode:5
		}
	};
	_O.Vars= {
		playerType:'x'
	};
	_O["CueTypeA"] ={
		
		// CuePoint data
			//forceStop: false
			//id: 2006156127001
			//metadata: null
			//name: "Pre-roll"
			//time: 0
			//type: 0
			//typeEnum: "AD"
			//videoId: 1706971832001
		////
		points:[],
		idx:0,

		openWindow: function (J) {
			if(!J) return; if(!J.url) return; 
			if(J.target == 'overlay'){
				$(".BrightCoveCT [jClass='Overlay'] iframe").attr("src",J.url);
				$(".BrightCoveCT [jClass='Overlay']").css("display","block");
			}else{
				window.open(J.url, "_blank", "width="+screen.availWidth+",height="+screen.availHeight);
//				window.open(J.url, "_blank", "width="+gConfig.ADPopup.width+",height="+gConfig.ADPopup.height);
				//9월24일 팝업 사이즈 변경작업
				//window.open(J.url, "_blank", "width=auto,height=auto");
			}
			var item = ctPlayer.Data.item;
			var cuePoints = ctPlayer.CuePoint.points;
			var metadata = cuePoints[J.cueIdx]["metadata"].split('|'); 
			var cIdx = CCtCuePoint.Metadata.index;
			ctAnalytics.TrackAD.trackEvent({
				id:item['id'], 
				name:cuePoints[J.cueIdx].name,
				prdtId:metadata[cIdx.prdtId], 
				price:metadata[cIdx.prdtPrice], 
				text:metadata[cIdx.prdtText], 
				targetMode:metadata[cIdx.targetMode], 
				url:J.url
			});
		},
		closeWindow: function () {
			$(".BrightCoveCT [jClass='Overlay']").css("display","none");
			$(".BrightCoveCT [jClass='Overlay'] iframe").attr("src","");
		},

		//////////////////////////////////////////////

		getPoints: function () {
			if(typeof ctPlayer.CuePoint.points=='undefined') return null;
			if(ctPlayer.CuePoint.points.length>0) return ctPlayer.CuePoint.points;
			else return null;
		},
		setPoints:function(){
			if(ctPlayer.CuePoint.points) delete ctPlayer.CuePoint.points;
			ctPlayer.CuePoint.points = [];
			var points =[];
			if(ctMain.Vars.param["cueData"]) { 
				ctPlayer.CuePoint.points = eval(ctMain.Vars.param["cueData"]);
				return;
			}
			var cuePoints = ctPlayer.Data.item["cuePoints"];
			for(var j=0; j<cuePoints.length; j++){
				var strMetadata = cuePoints[j]["metadata"];
				if(!strMetadata) continue;
				var metadata = strMetadata.split('|');
				if(metadata.length < CCtCuePoint.Metadata.length) continue;
				if(cuePoints[j]["type"] != 1) continue;
				points[points.length] = cuePoints[j];
			}
			ctPlayer.CuePoint.points = points.sort(function(a, b) {return a.time - b.time;});
		},

		////////////////////////////////

		Animation: {
			// configuration
			timeOut: 400,
			timeOutDelay: 2000,

			timeOutFinal: 1000,
			xPos: { off:-300, ready: -164, on: 0 },
			topMargin: 20,
			itemMargin:6,
			ctrlBarHeight:50,
			
			ctrlStatusBasePos:68,
			ctrlStatusWidth:gConfig.Player.width-197,

			seekPrevTime: 3000, // msec

			// init setting value
			numDisplayItems:0,
			itemsBoxHeight:0,
			imgHeight: 0,
			imgWidth:0,

			init: function () {
				
				this.timeOut = gConfig.CuePoint.CueTypeA.animationSpeed;
				this.timeOutDelay = gConfig.CuePoint.CueTypeA.showTime;

				this.imgHeight =  $(".BrightCoveCT [jClass='cuePointBox'] [jClass='cuePointItem']").height();
				this.imgWidth =  $(".BrightCoveCT [jClass='cuePointBox'] [jClass='cuePointItem'] [jClass='tdImg'] img").width();
				$(".BrightCoveCT [jClass='cuePointBox'] [jClass='cuePointItem']").each(function (idx, o) {
					var obj = $(o);
					var ani = ctPlayer.CuePoint.Animation;
					obj.css("top", (obj.height()+ani.itemMargin)*idx);
					obj.css("right", ani.xPos.off);
				});
				var playerHeight = $(".BrightCoveCT #brPlayer").height();
				this.numDisplayItems = Math.floor(( playerHeight - this.ctrlBarHeight - (this.topMargin * 2) + this.itemMargin ) / ( this.imgHeight + this.itemMargin));
				this.itemsBoxHeight = this.numDisplayItems * ( this.imgHeight + this.itemMargin) - this.itemMargin + 2;

				$(".BrightCoveCT [jClass='cuePointBox']").css("height",this.itemsBoxHeight+(this.topMargin * 2));
				$(".BrightCoveCT [jClass='cuePointBox']").css("top",gConfig.Player.aTypeCuePointBoxTop);
				$(".BrightCoveCT [jClass='cuePointBox'] [jClass='cuePointItemsBox']").css("top",this.topMargin);
				$(".BrightCoveCT [jClass='cuePointBox'] [jClass='cuePointItemsBox']").css("height",this.itemsBoxHeight);
				ctPlayer.CuePoint.Arrow.init();
			},

			activeItem: function (obj,auto) {
				if(!obj) return; 
				if(obj.attr("aniActive")=="on") return; 
				var itemIdx = obj.attr("jItemIdx");
				obj.attr("aniActive","on");
				obj.parent().animate({ right: this.xPos.on },this.timeOut, function () { obj.attr("aniActive","off"); } );
			},
			inActiveItem: function (obj) {
				if(!obj) return; 
				if(obj.attr("aniInactive")=="on") {
					setTimeout(function () {ctPlayer.CuePoint.Animation.inActiveItem(obj); }, this.timeOutFinal);
					return; 
				}
				obj.attr("aniInactive","on");
				obj.parent().animate({right: this.xPos.ready },this.timeOut, function () { obj.attr("aniInactive","off"); } );
			},
			refresh: function (ms) {
				var cue = ctPlayer.CuePoint;
				var ani = cue.Animation;
				var passCount = 0;
				for(var i=0; i< cue.points.length; i++) {
					obj = $(".BrightCoveCT [jClass='cuePointItem'] [jClass='Cover'][jItemIdx='"+i+"']");
					if(cue.points[i].time < ms  ){
						passCount++;
						obj.attr("cueOn","pass");
					}else {
						obj.attr("cueOn","ready");
					}
				}

				var hiddenNumber = passCount - ani.numDisplayItems;
				if(hiddenNumber < 0) cue.Scroll.topIdx = 0;
				else cue.Scroll.topIdx = hiddenNumber; 

				$(".BrightCoveCT [jClass='cuePointBox'] [jClass='cuePointItem']").each(function (idx, o) {
					var parent = $(o);
					var obj = parent.find("[jClass='Cover']");
					obj.attr("aniInactive","off");
					var xPos = ani.xPos.off;
					if(obj.attr("cueOn")=='pass') xPos = ani.xPos.ready;
					parent.css("right",xPos); // },ani.timeOut, function () { obj.attr("aniInactive","off"); } );
					parent.css("top",(idx - cue.Scroll.topIdx) * (ani.imgHeight+ani.itemMargin));
				});
				cue.Arrow.onOut($(".BrightCoveCT [jClass='cuePointBox'] [jClass='Arrow'][jSubClass='down']"));
				cue.Arrow.onOut($(".BrightCoveCT [jClass='cuePointBox'] [jClass='Arrow'][jSubClass='up']"));
			},
			open: function () { // called by ctPlayer
				if(_O.Vars.playerType != 'C'){
					$(".BrightCoveCT [jClass='PlayerBox'] [jClass='spotPointer']").each(function (idx, o) {
						var cue = ctPlayer.CuePoint;
						var ani = cue.Animation;
						var dur = ctPlayer.Player.Vars.duration;
						if(dur <= 0) return;
						var t = cue.points[idx].time;
						var pos = Math.round(ani.ctrlStatusBasePos + ani.ctrlStatusWidth * (t / dur)) ;
						if(pos < ani.ctrlStatusBasePos || pos > ani.ctrlStatusBasePos + ani.ctrlStatusWidth ) return;
						var obj = $(o);
						obj.css("display","block");
						obj.css("left", pos);
						obj.css("height", 5);  
					});
				}

				if(ctMain.Vars.param["cueIdx"]) { 
					var point = ctPlayer.CuePoint.points[parseInt(ctMain.Vars.param["cueIdx"],10)];
					if(!point) return;
					var ms = point["time"] - this.seekPrevTime;
					if(ms<0) ms = 0;
					ctPlayer.Player.seek(ms);
				}
			}
		},

		/////////////////////////////////////////////
		progressShow: function (ms) {
			var cue = ctPlayer.CuePoint;
			var ani = cue.Animation;
			for(var i=0; i< cue.points.length; i++) {
				if(cue.points[i].time -500 < ms && ms < cue.points[i].time +500 ){
					obj = $(".BrightCoveCT [jClass='cuePointItem'] [jClass='Cover'][jItemIdx='"+i+"']");
					if(obj.attr("cueOn")!='on' ) { 
						obj.attr("cueOn","on");
						if( i - cue.Scroll.topIdx < 0) {
							cue.Scroll.move( i - cue.Scroll.topIdx );
						}else if( i - cue.Scroll.topIdx >= cue.Animation.numDisplayItems ) {
							cue.Scroll.move( i - cue.Scroll.topIdx - cue.Animation.numDisplayItems + 1);
						}
						ani.activeItem(obj,"auto");
					}
				}else if(cue.points[i].time + ani.timeOutDelay -500 < ms && ms < cue.points[i].time + ani.timeOutDelay +500) {
					obj = $(".BrightCoveCT [jClass='cuePointItem'] [jClass='Cover'][jItemIdx='"+i+"']");
					if(obj.attr("cueOn")=='on') { 
						obj.attr("cueOn","pass");
						ani.inActiveItem(obj);
					}
				}
			}
		},
		refreshMediaStop: function (ms) {
			// ctPlayer.CuePoint.Animation.refresh(ms);
		},
		refreshMediaPlay: function (ms) {
			ctPlayer.CuePoint.closeWindow();
			ctPlayer.CuePoint.Animation.refresh(ms);
		},
		refreshMediaSeek: function (ms) {
			ctPlayer.CuePoint.Animation.refresh(ms);
		},
		refreshMediaComplete: function (ms) {
			var cue = ctPlayer.CuePoint;
			cue.Scroll.topIdx = 0;
			ctPlayer.CuePoint.Animation.refresh(0);
		},
		/////////////////////////////////////////////

		Event: {
			onOver: function(obj) {
				if(obj.attr("jClass")== "Cover") {
					ctPlayer.CuePoint.Animation.activeItem(obj);
				}else if(obj.attr("jClass")=="Arrow") {
					ctPlayer.CuePoint.Arrow.onOver(obj);
				}
			},
			onOut: function (obj) {
				if(obj.attr("jClass")== "Cover") {
					ctPlayer.CuePoint.Animation.inActiveItem(obj);
				}else if(obj.attr("jClass")=="Arrow") {
					ctPlayer.CuePoint.Arrow.onOut(obj);
				}
			},
			onClick: function(obj) {
				if(obj.attr("jClass")== "Cover") {
					ctPlayer.Player.pause();
					ctPlayer.CuePoint.openWindow({url:obj.attr("jLink"),target:obj.attr("jTarget"), cueIdx:obj.attr("jItemIdx")});
				}else if(obj.attr("jClass")=="Arrow") {
					ctPlayer.CuePoint.Arrow.onClick(obj);
				}else if(obj.attr("jClass") == "CloseBtn") {
					ctPlayer.CuePoint.closeWindow();
				}
			},
			set: function(){
				var cuePoints = ctPlayer.CuePoint.getPoints();
				if(!cuePoints) return;
				$(".BrightCoveCT [jBtn='on']").each(function (idx, obj) {
					$(obj).on("mouseover",function(e) {
						ctPlayer.CuePoint.Event.onOver($(this));
					});
					$(obj).on("mouseout",function(e) {
						ctPlayer.CuePoint.Event.onOut($(this));
					});
					$(obj).on("click",function(e) {
						ctPlayer.CuePoint.Event.onClick($(this));
					});
				});
			}
		},
		Arrow: {
			init: function () {
				var ani = ctPlayer.CuePoint.Animation;
				var imgRightPos = (ani.imgWidth - $(".BrightCoveCT [jClass='cuePointBox'] [jClass='Arrow']").width())/2 ;
				$(".BrightCoveCT [jClass='cuePointBox'] [jClass='Arrow']").css("right", imgRightPos);
				$(".BrightCoveCT [jClass='cuePointBox'] [jClass='Arrow'][jSubClass='down']").css("top", ani.itemsBoxHeight+ani.topMargin + 6);
				this.onOut($(".BrightCoveCT [jClass='cuePointBox'] [jClass='Arrow'][jSubClass='down']"));
				this.onOut($(".BrightCoveCT [jClass='cuePointBox'] [jClass='Arrow'][jSubClass='up']"));
			},
			onOver: function (obj) {
				var cue = ctPlayer.CuePoint;
				var ani = cue.Animation;
				if(obj.attr("jSubClass")=="up") {
					if(cue.Scroll.topIdx > 0) {
						obj.css('background-position-x',obj.width()*-3);
					}else{
						obj.css('background-position-x',obj.width()*-4);
					}
				}else if(obj.attr("jSubClass")=="down") {
					var passLeng = $(".BrightCoveCT [jClass='cuePointItem'] [jClass='Cover'][cueOn='pass']").length+$(".BrightCoveCT [jClass='cuePointItem'] [jClass='Cover'][cueOn='on']").length;
					if(cue.Scroll.topIdx + ani.numDisplayItems < cue.points.length && 
						 passLeng - cue.Scroll.topIdx >  ani.numDisplayItems 
					) {
						obj.css('background-position-x',obj.width()*-1);
					}else{
						obj.css('background-position-x',obj.width()*-4);
					}
				}
			},
			onOut: function (obj) {
				var cue = ctPlayer.CuePoint;
				var ani = cue.Animation;
				if(obj.attr("jSubClass")=="up") {
					if(cue.Scroll.topIdx > 0) {
						obj.css('background-position-x',obj.width()*-2);
					}else{
						obj.css('background-position-x',obj.width()*-4);
					}
				}else if(obj.attr("jSubClass")=="down") {
					var passLeng = $(".BrightCoveCT [jClass='cuePointItem'] [jClass='Cover'][cueOn='pass']").length+$(".BrightCoveCT [jClass='cuePointItem'] [jClass='Cover'][cueOn='on']").length;
					if(cue.Scroll.topIdx + ani.numDisplayItems < cue.points.length &&
					   passLeng - cue.Scroll.topIdx >  ani.numDisplayItems 
					) {
						obj.css('background-position-x',obj.width()*0);
					}else{
						obj.css('background-position-x',obj.width()*-4);
					}
				}
			},
			onClick: function (obj) {
				var cue = ctPlayer.CuePoint;
				if(obj.css('background-position-x') == (obj.width()*-4)+'px') return;  // hidden
				if(obj.attr("jSubClass")=="up") {
					cue.Scroll.move(-1);
				}else if(obj.attr("jSubClass")=="down") {
					cue.Scroll.move(1);
				}
			},
			checkOnOver: function (d) {
				if(d<0) {
					o = $(".BrightCoveCT [jClass='cuePointBox'] [jClass='Arrow'][jSubClass='up']");
					this.onOver(o);
					o = $(".BrightCoveCT [jClass='cuePointBox'] [jClass='Arrow'][jSubClass='down']");
					this.onOut(o);
				}else{
					o = $(".BrightCoveCT [jClass='cuePointBox'] [jClass='Arrow'][jSubClass='down']");
					this.onOver(o);
					o = $(".BrightCoveCT [jClass='cuePointBox'] [jClass='Arrow'][jSubClass='up']");
					this.onOut(o);
				}
			}
		},
		Scroll: {
			topIdx:0,
			timeOut: 300, // ms
			scrolling: false,

			move: function (d) {
				var cue = ctPlayer.CuePoint;
				var ani = cue.Animation;
				if(d < 0 && this.topIdx <=0 ) return;
				if(d > 0 && cue.Scroll.topIdx + d + ani.numDisplayItems > cue.points.length ) return;
				this.topIdx += d;
				this.markStart();
				$(".BrightCoveCT [jClass='cuePointBox'] [jClass='cuePointItem']").each(function (idx, o) {
					var obj = $(o);
					var cue = ctPlayer.CuePoint;
					var ani = cue.Animation;
					obj.animate(
						{ top : (idx - cue.Scroll.topIdx) * (ani.imgHeight+ani.itemMargin)},
						cue.Scroll.timeOut, 
						function () { cue.Scroll.markEnd(); } 
					);
				});
				cue.Arrow.checkOnOver(d);
			},
			isScrolling: function () {
				return this.scrolling;
			},
			markStart: function () {
				this.scrolling = true;
			},
			markEnd: function () {
				this.scrolling = false;
			}
		},
		setHtml : function(){
			if(!gConfig.Player.showCuePoint) return;
			var cuePoints = ctPlayer.CuePoint.points;
			var cIdx = CCtCuePoint.Metadata.index;
			var sp = "";
			var s='<div jClass="cuePointItemsBox">';
			for(var i=0; i<cuePoints.length; i++){
				sp += '<div jClass="spotPointer"></div>';
				var metadata = cuePoints[i]["metadata"].split('|'); // metadata[5]: overlay or window (new window)
				var tdText = metadata[cIdx.prdtText];
				if(metadata[cIdx.prdtPrice]) {
					if(gConfig.LanguageCode != 'en'){
						tdText += "<br>"+(metadata[cIdx.prdtPrice] != 0 ? (_U.addComma(metadata[cIdx.prdtPrice]) + ' ' +ctLanguage.getMsg({msg:'PriceUnit'})) : '');
					}else{
						tdText += "<br>"+(metadata[cIdx.prdtPrice] != 0 ? ctLanguage.getMsg({msg:'PriceUnit'}) + ' ' +(_U.addComma(metadata[cIdx.prdtPrice])) : '');
					}
				}
				s+= 
				'<div jClass="cuePointItem">'+
					'<table border="0px" cellpadding="0" cellspacing="0" jClass="itemTable">'+
						'<tr><td jClass="tdImg" ><img src="'+metadata[cIdx.thumbnailUrl]+'" /></td><td width="150" jClass="tdText">'+tdText+'</td></tr>'+
					'</table>'+
					'<div jClass="Cover" jLink="'+metadata[cIdx.targetUrl]+'" jTarget="'+metadata[cIdx.targetMode]+'" jBtn="on" jItemIdx="'+i+'"></div>'+
				'</div>';
			}
			s+='</div>';
			if(cuePoints.length > 0){
				s+=
					'<div jClass="Arrow" jSubClass="up" jBtn="on"></div>'+
					'<div jClass="Arrow" jSubClass="down" jBtn="on"></div>';
			}
			$(".BrightCoveCT [jClass='cuePointBox']").html(s);
			$(".BrightCoveCT #brPlayer").append(sp);
			ctPlayer.CuePoint.setCtStyle();
			ctPlayer.CuePoint.Animation.init();
		},
		setCtStyle: function () {
			$(".BrightCoveCT [jClass='cuePointBox']").attr("style",gCtStyle.get(".cuePointBox"));
			$(".BrightCoveCT [jClass='spotPointer']").attr("style",gCtStyle.get(".spotPointer"));

			$(".BrightCoveCT [jClass='cuePointBox'] [jClass='Arrow'][jSubClass='up']").attr("style",gCtStyle.get(".cuePointBox .Arrow.up"));
			$(".BrightCoveCT [jClass='cuePointBox'] [jClass='Arrow'][jSubClass='down']").attr("style",gCtStyle.get(".cuePointBox .Arrow.down"));
			$(".BrightCoveCT [jClass='cuePointBox'] [jClass='Arrow']").css("right","-100px");

			$(".BrightCoveCT [jClass='cuePointItemsBox']").attr("style",gCtStyle.get(".cuePointItemsBox"));
			$(".BrightCoveCT [jClass='cuePointItem']").attr("style",gCtStyle.get(".cuePointItem"));
			$(".BrightCoveCT [jClass='cuePointItem'] [jClass='itemTable']").attr("style",gCtStyle.get(".cuePointItem .itemTable"));
			$(".BrightCoveCT [jClass='cuePointItem'] [jClass='Cover']").attr("style",gCtStyle.get(".cuePointItem .Cover"));
			$(".BrightCoveCT [jClass='cuePointItem'] [jClass='itemTable'] [jClass='tdImg']").attr("style",gCtStyle.get(".cuePointItem .itemTable .tdImg"));
			$(".BrightCoveCT [jClass='cuePointItem'] [jClass='itemTable'] [jClass='tdImg'] > img").attr("style",gCtStyle.get(".cuePointItem .itemTable .tdImg > img"));
			$(".BrightCoveCT [jClass='cuePointItem'] [jClass='itemTable'] [jClass='tdText']").attr("style",gCtStyle.get(".cuePointItem .itemTable .tdText"));
			if(_O.Vars.playerType == 'C'){
				$(".BrightCoveCT [jClass='cuePointBox']").css("top","55px");
			}
			
		},
		getPlayerObject: function (id) {
			var item = ctPlayer.Data['item'];
			var playerType ='';
			for(var i=0; i<item['tags'].length; i++){
				if(item['tags'][i].indexOf("cm_player_") == 0){
					playerType = item['tags'][i].substring(item['tags'][i].lastIndexOf("_")+1).toUpperCase();
				}
			}
			_O.Vars.playerType= playerType;
			var item = ctPlayer.Data['item'];
			var playerType ='';
			for(var i=0; i<item['tags'].length; i++){
				if(item['tags'][i].indexOf("cm_player_") == 0){
					playerType = item['tags'][i].substring(item['tags'][i].lastIndexOf("_")+1).toUpperCase();
				}
			}
			_O.Vars.playerType= playerType;
			var str=
				'<object id="myExperience" class="BrightcoveExperience">'+
					'<param name="wmode" value="opaque"/>'+
					'<param name="bgcolor" value="#FFFFFF" />'+
					'<param name="width" value="'+gConfig.Player.width+'" />'+
					'<param name="height" value="'+gConfig.Player.height+'" />';
					if(playerType == 'C'){
						str+=
						'<param name="playerID" value="'+gConfig.Player.ChromelessPlayerID+'" />'+
						'<param name="playerKey" value="'+gConfig.Player.ChromelessPlayerKey+'" />';
					}else{
						str+=
						'<param name="playerID" value="'+gConfig.Player.SinglePlayerID+'" />'+
						'<param name="playerKey" value="'+gConfig.Player.SinglePlayerKEY+'" />';
					}
					//https code for Facebook app - Sean - 14.Oct.2013
					if(gConfig.Security.protocol=="https"){
						str+=
						'<param name="secureConnections" value="true" />'+
						'<param name="secureHTMLConnections" value="true" />'						
					}	
					
					str+=
					'<param name="isVid" value="true" />'+
					'<param name="isUI" value="true" />'+
					'<param name="dynamicStreaming" value="true" />'+
					'<param name="@videoPlayer" value="'+id+'" />'+ 
					'<param name="includeAPI" value="true" />'+ 
					'<param name="templateLoadHandler" value="ctPlayer.Player.playerLoaded" />'+ 
					'<param name="templateReadyHandler" value="ctPlayer.Player.playerReady" />'+ 
				'</object>';
			return str;
		}
	};


	_O["CueTypeB"] ={
		
		// CuePoint data
			//forceStop: false
			//id: 2006156127001
			//metadata: null
			//name: "Pre-roll"
			//time: 0
			//type: 0
			//typeEnum: "AD"
			//videoId: 1706971832001
		////
		points:[],
		idx:0,

		openWindow: function (J) {
			if(!J) return; if(!J.url) return; 
			if(J.target == 'overlay'){
				$(".BrightCoveCT [jClass='Overlay'] iframe").attr("src",J.url);
				$(".BrightCoveCT [jClass='Overlay']").css("display","block");
			}else{
				window.open(J.url, "_blank", "width="+screen.availWidth+",height="+screen.availHeight);			
//				window.open(J.url, "_blank", "width="+gConfig.ADPopup.width+",height="+gConfig.ADPopup.height);
			}
			var item = ctPlayer.Data.item;
			var cuePoints = ctPlayer.CuePoint.points;
			var metadata = cuePoints[J.cueIdx]["metadata"].split('|'); 
			var cIdx = CCtCuePoint.Metadata.index;
			ctAnalytics.TrackAD.trackEvent({
				id:item['id'], 
				name:cuePoints[J.cueIdx].name,
				prdtId:metadata[cIdx.prdtId], 
				price:metadata[cIdx.prdtPrice], 
				text:metadata[cIdx.prdtText], 
				targetMode:metadata[cIdx.targetMode],
				url:J.url
			});
		},
		closeWindow: function () {
			$(".BrightCoveCT [jClass='Overlay']").css("display","none");
			$(".BrightCoveCT [jClass='Overlay'] iframe").attr("src","");
		},

		//////////////////////////////////////////////

		getPoints: function () {
			if(typeof ctPlayer.CuePoint.points=='undefined') return null;
			if(ctPlayer.CuePoint.points.length>0) return ctPlayer.CuePoint.points;
			else return null;
		},
		setPoints:function(){
			if(ctPlayer.CuePoint.points) delete ctPlayer.CuePoint.points;
			ctPlayer.CuePoint.points = [];
			var points =[];
			if(ctMain.Vars.param["cueData"]) { 
				ctPlayer.CuePoint.points = eval(ctMain.Vars.param["cueData"]);
				return;
			}
			var cuePoints = ctPlayer.Data.item["cuePoints"];
			for(var j=0; j<cuePoints.length; j++){
				var strMetadata = cuePoints[j]["metadata"];
				if(!strMetadata) continue;
				var metadata = strMetadata.split('|');
				if(metadata.length < CCtCuePoint.Metadata.length) continue;
				if(cuePoints[j]["type"] != 1) continue;
				points[points.length] = cuePoints[j];
			}
			ctPlayer.CuePoint.points = points.sort(function(a, b) {return a.time - b.time;});
		},
		getAndroidVersion:function(){
			var start = navigator.userAgent.indexOf("Android ");
			var majorversion = navigator.userAgent.substr(start+8,5);
			return majorversion;
		},
		////////////////////////////////

		Animation: {
			// configuration
			timeOut: 1200,
			timeOutDelay: 10000,

			timeOutFinal: 1000,
			seekAheadPos: 3000, // msec

			yPos: { off:118, on: 0 },
			
			ctrlBarHeight:50,
			ctrlStatusBasePos:68,
			ctrlStatusWidth:gConfig.Player.width-197,

			imgHeight: 0,
			imgWidth:0,

			init: function () {

				this.timeOut = gConfig.CuePoint.CueTypeB.animationSpeed;
				this.timeOutDelay = gConfig.CuePoint.CueTypeB.showTime;

				this.imgHeight =  $(".BrightCoveCT [jClass='cuePointBox'] [jClass='cuePointItem']").height();
				this.imgWidth =  $(".BrightCoveCT [jClass='cuePointBox'] [jClass='cuePointItem'] [jClass='tdImg'] img").width();
				
				$(".BrightCoveCT [jClass='cuePointBox'] [jClass='cuePointItem']").each(function (idx, o) {
					var obj = $(o);
					var ani = ctPlayer.CuePoint.Animation;
					obj.css("top", ani.yPos.off);
					obj.css("left", 0);
					obj.css("opacity", 0);
				});
			},

			activeItem: function (obj) {
				if(!obj) return; 
				if(obj.attr("aniActive")=="on") return; 
				var itemIdx = obj.attr("jItemIdx");
				obj.attr("aniActive","on");
				obj.parent().animate({ top: this.yPos.on, opacity:1 },this.timeOut, function () { obj.attr("aniActive","off"); } );
			},
			inActiveItem: function (obj) {
				if(!obj) return; 
				if(obj.attr("aniInactive")=="on") {
					setTimeout(function () {ctPlayer.CuePoint.Animation.inActiveItem(obj); }, this.timeOutFinal);
					return; 
				}
				obj.attr("aniInactive","on");
				obj.parent().animate({top: this.yPos.off, opacity:0 },this.timeOut, function () { obj.attr("aniInactive","off"); } );
			},
			refresh: function (ms) {
				var cue = ctPlayer.CuePoint;
				var ani = cue.Animation;
				var obj;
				for(var i=0; i< cue.points.length; i++) {
					if(cue.points[i].time -500 > ms || ms > cue.points[i].time + ani.timeOutDelay +500) {
						obj = $(".BrightCoveCT [jClass='cuePointItem'] [jClass='Cover'][jItemIdx='"+i+"']");
						obj.parent().css("top", ani.yPos.off);
						obj.attr("cueOn","off");
					}
				}
			},
			open: function () { // called by ctPlayer
				if(_O.Vars.playerType != 'C'){
					$(".BrightCoveCT [jClass='PlayerBox'] [jClass='spotPointer']").each(function (idx, o) {
						var cue = ctPlayer.CuePoint;
						var ani = cue.Animation;
						var dur = ctPlayer.Player.Vars.duration;
						if(dur <= 0) return;
						var t = cue.points[idx].time;
						var pos = Math.round(ani.ctrlStatusBasePos + ani.ctrlStatusWidth * (t / dur)) ;
						if(pos < ani.ctrlStatusBasePos || pos > ani.ctrlStatusBasePos + ani.ctrlStatusWidth ) return;
						var obj = $(o);
						obj.css("display","block");
						obj.css("left", pos);
						
					});
				}

				if(ctMain.Vars.param["cueIdx"]) { 
					var point = ctPlayer.CuePoint.points[parseInt(ctMain.Vars.param["cueIdx"],10)];
					if(!point) return;
					var ms = point["time"] - this.seekAheadPos;
					if(ms<0) ms = 0;
					ctPlayer.Player.seek(ms);
				}
			}
		},

		/////////////////////////////////////////////
		progressShow: function (ms) {
			var cue = ctPlayer.CuePoint;
			var ani = cue.Animation;
			var obj;
			for(var i=0; i< cue.points.length; i++) {
				if(cue.points[i].time -500 < ms && ms < cue.points[i].time +500 ){
					if(i>0) {
						obj = $(".BrightCoveCT [jClass='cuePointItem'] [jClass='Cover'][jItemIdx='"+(i-1)+"']");
						if(obj.attr("cueOn")=='on') {
							obj.attr("cueOn","off");
							ani.inActiveItem(obj);
						}
					}
					obj = $(".BrightCoveCT [jClass='cuePointItem'] [jClass='Cover'][jItemIdx='"+i+"']");
					if(obj.attr("cueOn")!='on' ) { 
						obj.attr("cueOn","on");
						ani.activeItem(obj);
					}
				}else if(cue.points[i].time + ani.timeOutDelay -500 < ms && ms < cue.points[i].time + ani.timeOutDelay +500) {
					obj = $(".BrightCoveCT [jClass='cuePointItem'] [jClass='Cover'][jItemIdx='"+i+"']");
					if(obj.attr("cueOn")=='on') { 
						obj.attr("cueOn","off");
						ani.inActiveItem(obj);
					}
				}
			}
		},
		refreshMediaStop: function (ms) {
			// ctPlayer.CuePoint.Animation.refresh(ms);
		},
		refreshMediaPlay: function (ms) {
			ctPlayer.CuePoint.closeWindow();
			ctPlayer.CuePoint.Animation.refresh(ms);
		},
		refreshMediaSeek: function (ms) {
			ctPlayer.CuePoint.Animation.refresh(ms);
		},
		refreshMediaComplete: function (ms) {
			ctPlayer.CuePoint.Animation.refresh(0);
		},
		/////////////////////////////////////////////

		Event: {
			onOver: function(obj) {
				var cue = ctPlayer.CuePoint;
				var ani = cue.Animation;
				if(obj.attr("jClass") == "spotPointer") {
					/*
					var idx = parseInt(obj.attr("jItemIdx"),10);
					var o = $(".BrightCoveCT .cuePointItem .Cover[jItemIdx='"+idx+"']");
					if(o.attr("cueOn")=='off') {
						var oo = $(".BrightCoveCT .cuePointItem .Cover[cueOn='on']");
						if(oo) {
							oo.attr("cueOn","off");
							ani.inActiveItem(oo);
						}
						ani.activeItem(o);
					}
					*/
				}
			},
			onOut: function (obj) {
				var cue = ctPlayer.CuePoint;
				var ani = cue.Animation;
				if(obj.attr("jClass") == "spotPointer") {
					/*
					var idx = parseInt(obj.attr("jItemIdx"),10);
					var o = $(".BrightCoveCT .cuePointItem .Cover[jItemIdx='"+idx+"']");
					if(o.attr("cueOn")=='off') {
						//var oo = $(".BrightCoveCT .cuePointItem .Cover[cueOn='on']");
						//ani.activeItem(oo);
						setTimeout(function () {
							ctPlayer.CuePoint.Animation.inActiveItem(o);
						},5000);
					}
					*/
				}
			},
			onClick: function(obj) {
				if(obj.attr("jClass") == "Cover") {
					ctPlayer.Player.pause();
					ctPlayer.CuePoint.openWindow({url:obj.attr("jLink"),target:obj.attr("jTarget"), cueIdx:obj.attr("jItemIdx")});
				}else if(obj.attr("jClass") == "CloseBtn") {
					ctPlayer.CuePoint.closeWindow();
				}

			},
			set: function(){
				var cuePoints = ctPlayer.CuePoint.getPoints();
				if(!cuePoints) return;
				$(".BrightCoveCT [jBtn='on']").each(function (idx, obj) {
					$(obj).on("mouseover",function(e) {
						ctPlayer.CuePoint.Event.onOver($(this));
					});
					$(obj).on("mouseout",function(e) {
						ctPlayer.CuePoint.Event.onOut($(this));
					});
					$(obj).on("click",function(e) {
						ctPlayer.CuePoint.Event.onClick($(this));
					});
				});
			}
		},

		setHtml : function(){
			if(!gConfig.Player.showCuePoint) return;
			var cuePoints = ctPlayer.CuePoint.points;
			var cIdx = CCtCuePoint.Metadata.index;
			var sp = "";
			var s='<div jClass="cuePointItemsBox">';
			for(var i=0; i<cuePoints.length; i++){
				sp += '<div jClass="spotPointer" jBtn="on" jItemIdx="'+i+'"></div>';
				var metadata = cuePoints[i]["metadata"].split('|'); // metadata[4]: overlay or window (new window)
				var tdText = metadata[cIdx.prdtText];
				if(metadata[cIdx.prdtPrice]) {
					if(gConfig.LanguageCode != 'en'){
						tdText += "<br>"+(metadata[cIdx.prdtPrice] != 0 ? (_U.addComma(metadata[cIdx.prdtPrice]) + ' ' +ctLanguage.getMsg({msg:'PriceUnit'})) : '');
					}else{
						tdText += "<br>"+(metadata[cIdx.prdtPrice] != 0 ? ctLanguage.getMsg({msg:'PriceUnit'}) + ' ' +(_U.addComma(metadata[cIdx.prdtPrice])) : '');
					}
				}
				s+= 
				'<div jClass="cuePointItem">'+
					'<table border="0px" cellpadding="0" cellspacing="0" jClass="itemTable">'+
						'<tr><td jClass="tdImg" ><img src="'+metadata[cIdx.thumbnailUrl]+'" /></td><td jClass="tdText">'+tdText+'</td></tr>'+
					'</table>'+
					'<div jClass="Cover" jLink="'+metadata[cIdx.targetUrl]+'" jTarget="'+metadata[cIdx.targetMode]+'" jBtn="on" jItemIdx="'+i+'"></div>'+
				'</div>';
			}
			s+='</div>';
			$(".BrightCoveCT [jClass='cuePointBox']").html(s);
			$(".BrightCoveCT #brPlayer").append(sp);
			ctPlayer.CuePoint.setCtStyle();
			ctPlayer.CuePoint.Animation.init();
		},
		setCtStyle: function () {
			var item = ctPlayer.Data['item'];
			var playerType ='';
			for(var i=0; i<item['tags'].length; i++){
				if(item['tags'][i].indexOf("cm_player_") == 0){
					playerType = item['tags'][i].substring(item['tags'][i].lastIndexOf("_")+1).toUpperCase();
				}
			}
			_O.Vars.playerType= playerType;
			$(".BrightCoveCT [jClass='cuePointBox']").attr("style",gCtStyle.get(".cuePointBox"));
			if(playerType == 'S'){
				$(".BrightCoveCT [jClass='spotPointer']").attr("style",gCtStyle.get(".spotPointer"));
			}
			$(".BrightCoveCT [jClass='cuePointItemsBox']").attr("style",gCtStyle.get(".cuePointItemsBox"));
			$(".BrightCoveCT [jClass='cuePointItem']").attr("style",gCtStyle.get(".cuePointItem"));
			$(".BrightCoveCT [jClass='cuePointItem'] [jClass='itemTable']").attr("style",gCtStyle.get(".cuePointItem .itemTable"));
			$(".BrightCoveCT [jClass='cuePointItem'] [jClass='Cover']").attr("style",gCtStyle.get(".cuePointItem .Cover"));
			$(".BrightCoveCT [jClass='cuePointItem'] [jClass='itemTable'] [jClass='tdImg']").attr("style",gCtStyle.get(".cuePointItem .itemTable .tdImg"));
			$(".BrightCoveCT [jClass='cuePointItem'] [jClass='itemTable'] [jClass='tdImg'] > img").attr("style",gCtStyle.get(".cuePointItem .itemTable .tdImg > img"));
			$(".BrightCoveCT [jClass='cuePointItem'] [jClass='itemTable'] [jClass='tdText']").attr("style",gCtStyle.get(".cuePointItem .itemTable .tdText"));
		},
		getPlayerObject: function (id) {
			var item = ctPlayer.Data['item'];
			var playerType ='';
			for(var i=0; i<item['tags'].length; i++){
				if(item['tags'][i].indexOf("cm_player_") == 0){
					playerType = item['tags'][i].substring(item['tags'][i].lastIndexOf("_")+1).toUpperCase();
				}
			}
			_O.Vars.playerType= playerType;
			var str=
				'<object id="myExperience" class="BrightcoveExperience">'+
					'<param name="wmode" value="opaque"/>'+
					'<param name="bgcolor" value="#FFFFFF" />'+
					'<param name="width" value="'+gConfig.Player.width+'" />'+
					'<param name="height" value="'+gConfig.Player.height+'" />';
					if(playerType == 'C'){
						str+=
						'<param name="playerID" value="'+gConfig.Player.ChromelessPlayerID+'" />'+
						'<param name="playerKey" value="'+gConfig.Player.ChromelessPlayerKey+'" />';
					}else{
						str+=
						'<param name="playerID" value="'+gConfig.Player.SinglePlayerID+'" />'+
						'<param name="playerKey" value="'+gConfig.Player.SinglePlayerKEY+'" />';
					}
					
					//https code for Facebook app - Sean - 14.Oct.2013
					if(gConfig.Security.protocol=="https"){
						str+=
						'<param name="secureConnections" value="true" />'+
						'<param name="secureHTMLConnections" value="true" />'						
					}
										
					str+=
					'<param name="isVid" value="true" />'+
					'<param name="isUI" value="true" />'+
					'<param name="dynamicStreaming" value="true" />'+
					'<param name="@videoPlayer" value="'+id+'" />'+ 
					'<param name="includeAPI" value="true" />'+ 
					'<param name="templateLoadHandler" value="ctPlayer.Player.playerLoaded" />'+ 
					'<param name="templateReadyHandler" value="ctPlayer.Player.playerReady" />'+ 
				'</object>';
			return str;
		}
	};

	_O["CueTypeC"] ={
		
		// CuePoint data
			//forceStop: false
			//id: 2006156127001
			//metadata: null
			//name: "Pre-roll"
			//time: 0
			//type: 0
			//typeEnum: "AD"
			//videoId: 1706971832001
		////
		points:[],
		idx:0,

		openWindow: function (J) {

			if(!J) return; if(!J.url) return; 
			if(J.target == 'overlay'){
				$(".BrightCoveCT [jClass='Overlay'] iframe").attr("src",J.url);
				$(".BrightCoveCT [jClass='Overlay']").css("display","block");
			}else{
				window.open(J.url, "_blank", "width="+screen.availWidth+",height="+screen.availHeight);
			
//				window.open(J.url,"_blank","width="+gConfig.ADPopup.width+",height="+gConfig.ADPopup.height);
			}
			var item = ctPlayer.Data.item;
			var cuePoints = ctPlayer.CuePoint.points;
			var metadata = cuePoints[J.cueIdx]["metadata"].split('|'); 
			var cIdx = CCtCuePoint.Metadata.index;
			ctAnalytics.TrackAD.trackEvent({
				id:item['id'], 
				name:cuePoints[J.cueIdx].name,
				prdtId:metadata[cIdx.prdtId], 
				price:metadata[cIdx.prdtPrice], 
				text:metadata[cIdx.prdtText], 
				targetMode:metadata[cIdx.targetMode], 
				url:J.url
			});
		},
		closeWindow: function () {
			$(".BrightCoveCT [jClass='Overlay']").css("display","none");
			$(".BrightCoveCT [jClass='Overlay'] iframe").attr("src","");
		},

		//////////////////////////////////////////////

		getPoints: function () {
			if(typeof ctPlayer.CuePoint.points=='undefined') return null;
			if(ctPlayer.CuePoint.points.length>0) return ctPlayer.CuePoint.points;
			else return null;
		},
		setPoints:function(){
			if(ctPlayer.CuePoint.points) delete ctPlayer.CuePoint.points;
			ctPlayer.CuePoint.points = [];
			var points =[];
			if(ctMain.Vars.param["cueData"]) { 
				ctPlayer.CuePoint.points = eval(ctMain.Vars.param["cueData"]);
				return;
			}
			var cuePoints = ctPlayer.Data.item["cuePoints"];
			for(var j=0; j<cuePoints.length; j++){
				var strMetadata = cuePoints[j]["metadata"];
				if(!strMetadata) continue;
				var metadata = strMetadata.split('|');
				if(metadata.length < CCtCuePoint.Metadata.length) continue;
				if(cuePoints[j]["type"] != 1) continue;
				points[points.length] = cuePoints[j];
			}
			ctPlayer.CuePoint.points = points.sort(function(a, b) {return a.time - b.time;});
		},
		getAndroidVersion:function(){
			var start = navigator.userAgent.indexOf("Android ");
			var majorversion = navigator.userAgent.substr(start+8,5);
			return majorversion;
		},

		////////////////////////////////

		Animation: {
			// configuration
			timeOut: 1200,
			timeOutDelay: 10000,

			timeOutFinal: 1000,
			seekAheadPos: 3000, // msec

			xPos: [],
			
			ctrlBarHeight:50,
			ctrlStatusBasePos:68,
			ctrlStatusWidth:gConfig.Player.width-197,

			init: function (imgWidth, cuePos, obj, idx, cueBottom) { // imgWidth,cuePos,parentObj, itemIdx, cueBottom
				if(cuePos != 'R'){
					this.xPos[idx.toString()]={ off:-(imgWidth+12), on:0 };
				}else{
					this.xPos[idx.toString()]={ off:(gConfig.Player.width*328/800), on:((gConfig.Player.width*328/800)-(imgWidth+16)) };
				}
				var ani = ctPlayer.CuePoint.Animation;
				this.timeOut = gConfig.CuePoint.CueTypeC.animationSpeed;
				this.timeOutDelay = gConfig.CuePoint.CueTypeC.showTime;
				$(obj).css({
					"bottom":cueBottom+"px",
					"left":ani.xPos[idx.toString()].off+"px",
					"-ms-filter":'"progid:DXImageTransform.Microsoft.Alpha(Opacity=0)"', /* IE 8 */
					"filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)", /* IE 7 and olders */
					"opacity":"0"
				});
				
				/*$(".BrightCoveCT [jClass='cuePointBox'] [jClass='cuePointItem_L']").each(function (idx, o) {
					var obj = $(o);
					var ani = ctPlayer.CuePoint.Animation;
					obj.css("bottom", 0);
					obj.css("left", ani.L_xPos[idx].off);
					obj.css("opacity", 0);
				});
				$(".BrightCoveCT [jClass='cuePointBox'] [jClass='cuePointItem_R']").each(function (idx, o) {
					var obj = $(o);
					var ani = ctPlayer.CuePoint.Animation;
					obj.css("bottom", 0);
					obj.css("left", ani.R_xPos[idx].off);
					obj.css("opacity", 0);
				});*/
			},

			activeItem: function (obj,idx) {
				if(!obj) return; 
				var attr = obj.parent().attr('jClass');
				var cuePos = attr.substring((attr.indexOf("_")+1));
				if(obj.attr("aniActive")=="on") return; 
				var itemIdx = obj.attr("jItemIdx");
				obj.attr("aniActive","on");
				
				//if(cuePos == 'L'){
				obj.parent().animate({ 
						'left': this.xPos[idx.toString()].on,
						"-ms-filter":'"progid:DXImageTransform.Microsoft.Alpha(Opacity=100)"',
						"filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)", /* IE 7 and olders */
						'opacity': 1
						
					},
					this.timeOut, 
					function () { 
						obj.attr("aniActive","off"); 
					}
				);
				
				//}else{
				//	obj.parent().animate({ left: this.xPos[idx].on, opacity:1 },this.timeOut, function () { obj.attr("aniActive","off"); } );
				//}
			},
			inActiveItem: function (obj,idx) {
				if(!obj) return; 
				var attr = obj.parent().attr('jClass');
				var cuePos = attr.substring((attr.indexOf("_")+1));
				if(obj.attr("aniInactive")=="on") {
					setTimeout(function () {ctPlayer.CuePoint.Animation.inActiveItem(obj); }, this.timeOutFinal);
					return; 
				}
				obj.attr("aniInactive","on");
				//if(cuePos == 'L') 
				obj.parent().animate({ 'left': this.xPos[idx.toString()].off, 'opacity':0 },this.timeOut, function () { obj.attr("aniInactive","off"); } );
				//else obj.parent().animate({left: this.R_xPos.off, opacity:0 },this.timeOut, function () { obj.attr("aniInactive","off"); } );
			},
			refresh: function (ms) {
				var cue = ctPlayer.CuePoint;
				var ani = cue.Animation;
				var obj, parentObj, attr, cuePos;
				var pObjs = $(".BrightCoveCT [jClass='Cover']").parent();
				for(var i=0; i< cue.points.length; i++) {
					parentObj= pObjs[i];
					attr = $(parentObj).attr('jClass');
					cuePos = attr.substring((attr.indexOf("_")+1));
					var itemIdx = $(parentObj).find("[jClass='Cover']").attr("jItemIdx");
					if(cue.points[itemIdx].time -500 > ms || ms > cue.points[itemIdx].time + ani.timeOutDelay +500) {
						$(parentObj).css("left", ani.xPos[itemIdx.toString()].off);
						$(parentObj).find("[jClass='Cover']").attr("cueOn","off");
					}
				}
			},
			open: function () { // called by ctPlayer
				if(_O.Vars.playerType != 'C'){
					$(".BrightCoveCT [jClass='PlayerBox'] [jClass='spotPointer']").each(function (idx, o) {
						var cue = ctPlayer.CuePoint;
						var ani = cue.Animation;
						var dur = ctPlayer.Player.Vars.duration;
						if(dur <= 0) return;
						var t = cue.points[idx].time;
						var pos = Math.round(ani.ctrlStatusBasePos + ani.ctrlStatusWidth * (t / dur)) ;
						if(pos < ani.ctrlStatusBasePos || pos > ani.ctrlStatusBasePos + ani.ctrlStatusWidth ) return;
						var obj = $(o);
						obj.css("display","block");
						obj.css("left", pos);
						
					});
				}
				if(ctMain.Vars.param["cueIdx"]) { 
					
					var point = ctPlayer.CuePoint.points[parseInt(ctMain.Vars.param["cueIdx"],10)];
					if(!point) return;
					var ms = point["time"] - this.seekAheadPos;
					if(ms<0) ms = 0;
					ctPlayer.Player.seek(ms);
				}
			}
		},

		/////////////////////////////////////////////
		progressShow: function (ms) {
			var cue = ctPlayer.CuePoint;
			var ani = cue.Animation;
			var obj, cuePos, parentObj, attr, metadata;
			for(var i=0; i< cue.points.length; i++) {
				var imgObj = $(".BrightCoveCT [jClass='itemTable'] [jClass='tdImg'] > img")[i];
				parentObj= $(".BrightCoveCT [jClass='Cover']").parent()[i];
				attr = $(parentObj).attr('jClass');
				
				cuePos = cue.points[i]['metadata'].split('|')[6];
				if(cue.points[i].time -500 < ms && ms < cue.points[i].time +500 ){
					if(i>0) {
						obj = $(".BrightCoveCT [jClass='cuePointItem_"+cuePos+"'] [jClass='Cover'][jItemIdx='"+(i-1)+"']");
						if(obj.attr("cueOn")=='on') {
							obj.attr("cueOn","off");
							ani.inActiveItem(obj,(i-1));
						}
					}
					obj = $(".BrightCoveCT [jClass='cuePointItem_"+cuePos+"'] [jClass='Cover'][jItemIdx='"+i+"']");
					if(obj.attr("cueOn")!='on' ) { 
						obj.attr("cueOn","on");
						ani.activeItem(obj,i);
					}
				}else if(cue.points[i].time + ani.timeOutDelay -500 < ms && ms < cue.points[i].time + ani.timeOutDelay +500) {
					obj = $(".BrightCoveCT [jClass='cuePointItem_"+cuePos+"'] [jClass='Cover'][jItemIdx='"+i+"']");
					if(obj.attr("cueOn")=='on') { 
						obj.attr("cueOn","off");
						ani.inActiveItem(obj,i);
					}
				}
			}
		},
		refreshMediaStop: function (ms) {
			// ctPlayer.CuePoint.Animation.refresh(ms);
		},
		refreshMediaPlay: function (ms) {
			ctPlayer.CuePoint.closeWindow();
			ctPlayer.CuePoint.Animation.refresh(ms);
		},
		refreshMediaSeek: function (ms) {
			ctPlayer.CuePoint.Animation.refresh(ms);
		},
		refreshMediaComplete: function (ms) {
			ctPlayer.CuePoint.Animation.refresh(0);
		},
		/////////////////////////////////////////////

		Event: {
			onOver: function(obj) {
				var cue = ctPlayer.CuePoint;
				var ani = cue.Animation;
				if(obj.attr("jClass") == "spotPointer") {
					/*
					var idx = parseInt(obj.attr("jItemIdx"),10);
					var o = $(".BrightCoveCT .cuePointItem .Cover[jItemIdx='"+idx+"']");
					if(o.attr("cueOn")=='off') {
						var oo = $(".BrightCoveCT .cuePointItem .Cover[cueOn='on']");
						if(oo) {
							oo.attr("cueOn","off");
							ani.inActiveItem(oo);
						}
						ani.activeItem(o);
					}
					*/
				}
			},
			onOut: function (obj) {
				var cue = ctPlayer.CuePoint;
				var ani = cue.Animation;
				if(obj.attr("jClass") == "spotPointer") {
					/*
					var idx = parseInt(obj.attr("jItemIdx"),10);
					var o = $(".BrightCoveCT .cuePointItem .Cover[jItemIdx='"+idx+"']");
					if(o.attr("cueOn")=='off') {
						//var oo = $(".BrightCoveCT .cuePointItem .Cover[cueOn='on']");
						//ani.activeItem(oo);
						setTimeout(function () {
							ctPlayer.CuePoint.Animation.inActiveItem(o);
						},5000);
					}
					*/
				}
			},
			onClick: function(obj) {
				if(obj.attr("jClass") == "Cover") {
					ctPlayer.Player.pause();
					ctPlayer.CuePoint.openWindow({url:obj.attr("jLink"),target:obj.attr("jTarget"), cueIdx:obj.attr("jItemIdx")});
				}else if(obj.attr("jClass") == "CloseBtn") {
					ctPlayer.CuePoint.closeWindow();
				}

			},
			set: function(){
				var cuePoints = ctPlayer.CuePoint.getPoints();
				if(!cuePoints) return;
				$(".BrightCoveCT [jBtn='on']").each(function (idx, obj) {
					$(obj).on("mouseover",function(e) {
						ctPlayer.CuePoint.Event.onOver($(this));
					});
					$(obj).on("mouseout",function(e) {
						ctPlayer.CuePoint.Event.onOut($(this));
					});
					$(obj).on("click",function(e) {
						ctPlayer.CuePoint.Event.onClick($(this));
					});
				});
			}
		},

		setHtml : function(){
			if(!gConfig.Player.showCuePoint) return;
			var cuePoints = ctPlayer.CuePoint.points;
			var cIdx = CCtCuePoint.Metadata.index;
			var cuePos = '';
			var sp = "";
			var s='<div jClass="cuePointItemsBox_L">';
			for(var i=0; i<cuePoints.length; i++){
				sp += '<div jClass="spotPointer" jBtn="on" jItemIdx="'+i+'"></div>';
				var metadata = cuePoints[i]["metadata"].split('|'); // metadata[5]: overlay or window (new window)
				cuePos = metadata[metadata.length-2];
				cuePos != 'R' ? cuePos = 'L' : cuePos = 'R';
				if(cuePos != 'R'){
					s+= 
					'<div jClass="cuePointItem_'+cuePos+'">'+
						'<table border="0px" cellpadding="0" cellspacing="0" jClass="itemTable">'+
							'<tr><td jClass="tdImg" ><img src="'+metadata[cIdx.thumbnailUrl]+'" /></tr>'+
						'</table>'+
						'<div jClass="Cover" jLink="'+metadata[cIdx.targetUrl]+'" jTarget="'+metadata[cIdx.targetMode]+'" jBtn="on" jItemIdx="'+i+'"></div>'+
					'</div>';
				}
			}
			s+='</div>';
			var ss='<div jClass="cuePointItemsBox_R">';
			for(var i=0; i<cuePoints.length; i++){
				var metadata = cuePoints[i]["metadata"].split('|'); // metadata[5]: overlay or window (new window)
				cuePos = metadata[metadata.length-2];
				cuePos != 'R' ? cuePos = 'L' : cuePos = 'R';
				if(cuePos == 'R'){
					ss+= 
					'<div jClass="cuePointItem_'+cuePos+'">'+
						'<table border="0px" cellpadding="0" cellspacing="0" jClass="itemTable">'+
							'<tr><td jClass="tdImg" ><img src="'+metadata[cIdx.thumbnailUrl]+'" /></tr>'+
						'</table>'+
						'<div jClass="Cover" jLink="'+metadata[cIdx.targetUrl]+'" jTarget="'+metadata[cIdx.targetMode]+'" jBtn="on" jItemIdx="'+i+'"></div>'+
					'</div>';
				}
			}
			ss+='</div>';
			$(".BrightCoveCT [jClass='cuePointBox_L']").html(s);
			$(".BrightCoveCT [jClass='cuePointBox_R']").html(ss);
			$(".BrightCoveCT #brPlayer").append(sp);
			ctPlayer.CuePoint.setCtStyle();
			ctPlayer.CuePoint.setCuePointItemStyle();
		},
		setCtStyle: function () {
			var cuePoints = ctPlayer.CuePoint.points;
			var cuePos, parentObj, attr;
			$(".BrightCoveCT [jClass='cuePointBox_L']").attr("style",gCtStyle.get(".cuePointBox_L"));
			$(".BrightCoveCT [jClass='cuePointBox_R']").attr("style",gCtStyle.get(".cuePointBox_R"));
			$(".BrightCoveCT [jClass='cuePointItemsBox_L']").attr("style",gCtStyle.get(".cuePointItemsBox_L"));
			$(".BrightCoveCT [jClass='cuePointItemsBox_R']").attr("style",gCtStyle.get(".cuePointItemsBox_R"));
			$(".BrightCoveCT [jClass='spotPointer']").attr("style",gCtStyle.get(".spotPointer"));
			for(var i=0; i<cuePoints.length; i++){
				parentObj= $(".BrightCoveCT [jClass='Cover']").parent()[i];
				attr = $(parentObj).attr('jClass');
				cuePos = attr.substring((attr.indexOf("_")+1));
				$(".BrightCoveCT [jClass='cuePointItem_"+cuePos+"']").attr("style",gCtStyle.get(".cuePointItem_"+cuePos));
				$(".BrightCoveCT [jClass='cuePointItem_"+cuePos+"'] [jClass='itemTable']").attr("style",gCtStyle.get(".cuePointItem_"+cuePos+" .itemTable"));
				$(".BrightCoveCT [jClass='cuePointItem_"+cuePos+"'] [jClass='Cover']").attr("style",gCtStyle.get(".cuePointItem_"+cuePos+" .Cover"));
				$(".BrightCoveCT [jClass='cuePointItem_"+cuePos+"'] [jClass='itemTable'] [jClass='tdImg']").attr("style",gCtStyle.get(".cuePointItem_"+cuePos+" .itemTable .tdImg"));
				$(".BrightCoveCT [jClass='cuePointItem_"+cuePos+"'] [jClass='itemTable'] [jClass='tdImg'] > img").attr("style",gCtStyle.get(".cuePointItem_"+cuePos+" .itemTable .tdImg > img"));
			}
		},
		setCuePointItemStyle: function(){
			var objLength = $(".BrightCoveCT [jClass='Cover']");
			for(i = 0; i<objLength.length; i++){

				var pObj = $(objLength[i]).parent();
				var jItemIdx = $(objLength[i]).attr("jItemidx");
				imgObj =$(objLength[i]).parent().find("img");

				$(imgObj).attr("jItemIdx",jItemIdx);
				var imgurl = $(imgObj).attr("src");
				$(imgObj).attr("src", '');
				$(imgObj) // Make in memory copy of image to avoid css issues
					.attr("src", imgurl)
					.load(function() {
						var imgWidth = this.width;   // Note: $(this).width() will not
						var imgHeight = this.height; // work for in memory images.
						
						var itemIdx = $(this).attr("jItemIdx");
						var parentObj = $(this).closest("div");
						var coverObj =  parentObj.children().last();

						var cuePoints = ctPlayer.CuePoint.points[itemIdx];
						var metadata = cuePoints['metadata'].split('|');
						var cuePos = metadata[6];
						

						var cueBottom = ( metadata[7] ? metadata[7] : "0" );
						$(parentObj).css({
							"width":(imgWidth+8)+"px",
							"height":(imgHeight+12)+"px",
							"bottom":cueBottom+"px"
						});
						$(coverObj).css({
							"width":(imgWidth+8)+"px",
							"height":(imgHeight+12)+"px"
						});
						ctPlayer.CuePoint.Animation.init(imgWidth,cuePos,parentObj, itemIdx, cueBottom);	

					});
			}
		},
		getPlayerObject: function (id) {
			var item = ctPlayer.Data['item'];
			var playerType ='';
			for(var i=0; i<item['tags'].length; i++){
				if(item['tags'][i].indexOf("cm_player_") == 0){
					playerType = item['tags'][i].substring(item['tags'][i].lastIndexOf("_")+1).toUpperCase();
				}
			}
			_O.Vars.playerType= playerType;
			var str=
				'<object id="myExperience" class="BrightcoveExperience">'+
					'<param name="wmode" value="opaque"/>'+
					'<param name="bgcolor" value="#FFFFFF" />'+
					'<param name="width" value="'+gConfig.Player.width+'" />'+
					'<param name="height" value="'+gConfig.Player.height+'" />';
					if(playerType == 'C'){
						str+=
						'<param name="playerID" value="'+gConfig.Player.ChromelessPlayerID+'" />'+
						'<param name="playerKey" value="'+gConfig.Player.ChromelessPlayerKey+'" />';
					}else{
						str+=
						'<param name="playerID" value="'+gConfig.Player.SinglePlayerID+'" />'+
						'<param name="playerKey" value="'+gConfig.Player.SinglePlayerKEY+'" />';
					}

					//https code for Facebook app - Sean - 14.Oct.2013
					if(gConfig.Security.protocol=="https"){
						str+=
						'<param name="secureConnections" value="true" />'+
						'<param name="secureHTMLConnections" value="true" />'						
					}	
										
					str+=
					'<param name="isVid" value="true" />'+
					'<param name="isUI" value="true" />'+
					'<param name="dynamicStreaming" value="true" />'+
					'<param name="@videoPlayer" value="'+id+'" />'+ 
					'<param name="includeAPI" value="true" />'+ 
					'<param name="templateLoadHandler" value="ctPlayer.Player.playerLoaded" />'+ 
					'<param name="templateReadyHandler" value="ctPlayer.Player.playerReady" />'+ 
				'</object>';
			return str;
		}
	};
	
	_O["CueTypeD"] ={
		
		// CuePoint data
			//forceStop: false
			//id: 2006156127001
			//metadata: null
			//name: "Pre-roll"
			//time: 0
			//type: 0
			//typeEnum: "AD"
			//videoId: 1706971832001
		////
		points:[],
		idx:0,

		openWindow: function (J) {
			if(!J) return; if(!J.url) return; 
			if(J.target == 'overlay'){
				$(".BrightCoveCT [jClass='Overlay'] iframe").attr("src",J.url);
				$(".BrightCoveCT [jClass='Overlay']").css("display","block");
			}else{
				window.open(J.url, "_blank", "width="+screen.availWidth+",height="+screen.availHeight);
			
//				window.open(J.url, "_blank", "width="+gConfig.ADPopup.width+",height="+gConfig.ADPopup.height);
			}
			var item = ctPlayer.Data.item;
			var cuePoints = ctPlayer.CuePoint.points;
			var metadata = cuePoints[J.cueIdx]["metadata"].split('|'); 
			var cIdx = CCtCuePoint.Metadata.index;
			ctAnalytics.TrackAD.trackEvent({
				id:item['id'], 
				name:cuePoints[J.cueIdx].name,
				prdtId:metadata[cIdx.prdtId], 
				price:metadata[cIdx.prdtPrice], 
				text:metadata[cIdx.prdtText], 
				targetMode:metadata[cIdx.targetMode], 
				url:J.url
			});
		},
		closeWindow: function () {
			$(".BrightCoveCT [jClass='Overlay']").css("display","none");
			$(".BrightCoveCT [jClass='Overlay'] iframe").attr("src","");
		},

		//////////////////////////////////////////////

		getPoints: function () {
			if(typeof ctPlayer.CuePoint.points=='undefined') return null;
			if(ctPlayer.CuePoint.points.length>0) return ctPlayer.CuePoint.points;
			else return null;
		},
		setPoints:function(){
			if(ctPlayer.CuePoint.points) delete ctPlayer.CuePoint.points;
			ctPlayer.CuePoint.points = [];
			var points =[];
			if(ctMain.Vars.param["cueData"]) { 
				ctPlayer.CuePoint.points = eval(ctMain.Vars.param["cueData"]);
				return;
			}
			var cuePoints = ctPlayer.Data.item["cuePoints"];
			for(var j=0; j<cuePoints.length; j++){
				var strMetadata = cuePoints[j]["metadata"];
				if(!strMetadata) continue;
				var metadata = strMetadata.split('|');
				if(metadata.length < CCtCuePoint.Metadata.length) continue;
				if(cuePoints[j]["type"] != 1) continue;
				points[points.length] = cuePoints[j];
			}
			ctPlayer.CuePoint.points = points.sort(function(a, b) {return a.time - b.time;});
		},
		getAndroidVersion:function(){
			var start = navigator.userAgent.indexOf("Android ");
			var majorversion = navigator.userAgent.substr(start+8,5);
			return majorversion;
		},

		////////////////////////////////

		Animation: {
			// configuration
			timeOut: 1200,
			timeOutDelay: 10000,

			timeOutFinal: 1000,
			seekAheadPos: 3000, // msec

			yPos: { off:155, on: 26 },
			
			ctrlBarHeight:50,
			ctrlStatusBasePos:68,
			ctrlStatusWidth:gConfig.Player.width-197,
			
			imgHeight: 0,
			imgWidth:0,

			init: function () {

				this.timeOut = gConfig.CuePoint.CueTypeB.animationSpeed;
				this.timeOutDelay = gConfig.CuePoint.CueTypeB.showTime;

				this.imgHeight =  $(".BrightCoveCT [jClass='cuePointBox'] [jClass='cuePointItem']").height();
				this.imgWidth =  $(".BrightCoveCT [jClass='cuePointBox'] [jClass='cuePointItem'] [jClass='tdImg'] img").width();
				$(".BrightCoveCT [jClass='cuePointBox'] [jClass='cuePointItem']").each(function (idx, o) {
					var obj = $(o);
					var ani = ctPlayer.CuePoint.Animation;
					obj.css("top", ani.yPos.off);
					obj.css("left", 0);
					obj.css("opacity", 0);
				});
			},

			activeItem: function (obj) {
				if(!obj) return; 
				if(obj.attr("aniActive")=="on") return; 
				var itemIdx = obj.attr("jItemIdx");
				obj.attr("aniActive","on");
				obj.parent().animate({ top: this.yPos.on, opacity:1 },this.timeOut, function () { obj.attr("aniActive","off"); } );
			},
			inActiveItem: function (obj) {
				if(!obj) return; 
				if(obj.attr("aniInactive")=="on") {
					setTimeout(function () {ctPlayer.CuePoint.Animation.inActiveItem(obj); }, this.timeOutFinal);
					return; 
				}
				obj.attr("aniInactive","on");
				obj.parent().animate({top: this.yPos.off, opacity:0 },this.timeOut, function () { obj.attr("aniInactive","off"); } );
			},
			refresh: function (ms) {
				var cue = ctPlayer.CuePoint;
				var ani = cue.Animation;
				var obj;
				for(var i=0; i< cue.points.length; i++) {
					if(cue.points[i].time -500 > ms || ms > cue.points[i].time + ani.timeOutDelay +500) {
						obj = $(".BrightCoveCT [jClass='cuePointItem'] [jClass='Cover'][jItemIdx='"+i+"']");
						obj.parent().css("top", ani.yPos.off);
						obj.attr("cueOn","off");
					}
				}
			},
			open: function () { // called by ctPlayer
				if(_O.Vars.playerType != 'C'){
					$(".BrightCoveCT [jClass='PlayerBox'] [jClass='spotPointer']").each(function (idx, o) {
						var cue = ctPlayer.CuePoint;
						var ani = cue.Animation;
						var dur = ctPlayer.Player.Vars.duration;
						if(dur <= 0) return;
						var t = cue.points[idx].time;
						var pos = Math.round(ani.ctrlStatusBasePos + ani.ctrlStatusWidth * (t / dur)) ;
						if(pos < ani.ctrlStatusBasePos || pos > ani.ctrlStatusBasePos + ani.ctrlStatusWidth ) return;
						var obj = $(o);
						obj.css("display","block");
						obj.css("left", pos);
						
					});
				}

				if(ctMain.Vars.param["cueIdx"]) { 
					var point = ctPlayer.CuePoint.points[parseInt(ctMain.Vars.param["cueIdx"],10)];
					if(!point) return;
					var ms = point["time"] - this.seekAheadPos;
					if(ms<0) ms = 0;
					ctPlayer.Player.seek(ms);
				}
			}
		},

		/////////////////////////////////////////////
		progressShow: function (ms) {
			var cue = ctPlayer.CuePoint;
			var ani = cue.Animation;
			var obj;
			for(var i=0; i< cue.points.length; i++) {
				if(cue.points[i].time -500 < ms && ms < cue.points[i].time +500 ){
					if(i>0) {
						obj = $(".BrightCoveCT [jClass='cuePointItem'] [jClass='Cover'][jItemIdx='"+(i-1)+"']");
						if(obj.attr("cueOn")=='on') {
							obj.attr("cueOn","off");
							ani.inActiveItem(obj);
						}
					}
					obj = $(".BrightCoveCT [jClass='cuePointItem'] [jClass='Cover'][jItemIdx='"+i+"']");
					if(obj.attr("cueOn")!='on' ) { 
						obj.attr("cueOn","on");
						ani.activeItem(obj);
					}
				}else if(cue.points[i].time + ani.timeOutDelay -500 < ms && ms < cue.points[i].time + ani.timeOutDelay +500) {
					obj = $(".BrightCoveCT [jClass='cuePointItem'] [jClass='Cover'][jItemIdx='"+i+"']");
					if(obj.attr("cueOn")=='on') { 
						obj.attr("cueOn","off");
						ani.inActiveItem(obj);
					}
				}
			}
		},
		refreshMediaStop: function (ms) {
			// ctPlayer.CuePoint.Animation.refresh(ms);
		},
		refreshMediaPlay: function (ms) {
			ctPlayer.CuePoint.closeWindow();
			ctPlayer.CuePoint.Animation.refresh(ms);
		},
		refreshMediaSeek: function (ms) {
			ctPlayer.CuePoint.Animation.refresh(ms);
		},
		refreshMediaComplete: function (ms) {
			ctPlayer.CuePoint.Animation.refresh(0);
		},
		/////////////////////////////////////////////

		Event: {
			onOver: function(e) {
				var obj = e.data.obj;
				var cue = ctPlayer.CuePoint;
				var ani = cue.Animation;
				if(obj.attr("jClass") == "spotPointer") {
					/*
					var idx = parseInt(obj.attr("jItemIdx"),10);
					var o = $(".BrightCoveCT .cuePointItem .Cover[jItemIdx='"+idx+"']");
					if(o.attr("cueOn")=='off') {
						var oo = $(".BrightCoveCT .cuePointItem .Cover[cueOn='on']");
						if(oo) {
							oo.attr("cueOn","off");
							ani.inActiveItem(oo);
						}
						ani.activeItem(o);
					}
					*/
				}
			},
			onOut: function (e) {
				var obj = e.data.obj;
				var cue = ctPlayer.CuePoint;
				var ani = cue.Animation;
				if(obj.attr("jClass") == "spotPointer") {
					/*
					var idx = parseInt(obj.attr("jItemIdx"),10);
					var o = $(".BrightCoveCT .cuePointItem .Cover[jItemIdx='"+idx+"']");
					if(o.attr("cueOn")=='off') {
						//var oo = $(".BrightCoveCT .cuePointItem .Cover[cueOn='on']");
						//ani.activeItem(oo);
						setTimeout(function () {
							ctPlayer.CuePoint.Animation.inActiveItem(o);
						},5000);
					}
					*/
				}
			},
			onClick: function(e) {
				var obj = e.data.obj;
				var i = 0;
				e.data.idx ? i = e.data.idx : i = 0;
				if(obj.attr("jClass") == "Cover") {
					ctPlayer.Player.pause();
					ctPlayer.CuePoint.openWindow({url:obj.attr("jLink"),target:obj.attr("jTarget"), cueIdx:obj.attr("jItemIdx")});
				}else if(obj.attr("jClass") == "CloseBtn") {
					ctPlayer.CuePoint.closeWindow();
				}else if(obj.attr("jClass") == "cuePointCloseBtn"){
					var cue = ctPlayer.CuePoint;
					var ani = cue.Animation;
					//for(var i=0; i< cue.points.length; i++) {
						var idx = $($(".BrightCoveCT [jClass='cuePointCloseBtn']")[i]).attr("jItemIdx");
						var o = $(".BrightCoveCT [jClass='cuePointItem'] [jClass='Cover'][jItemIdx='"+idx+"']");
						if(o.attr("cueOn")=='on') { 
							o.attr("cueOn","off");
							ani.inActiveItem(o);
						}
				//	}
				}

			},
			set: function(){
				var cuePoints = ctPlayer.CuePoint.getPoints();
				var cue = ctPlayer.CuePoint;
				var ani = cue.Animation;
				if(!cuePoints) return;
				$(".BrightCoveCT [jBtn='on']").each(function (idx, obj) {
					$(obj).on("mouseover", {obj:$(obj)}, ctPlayer.CuePoint.Event.onOver);
					$(obj).on("mouseout", {obj:$(obj)}, ctPlayer.CuePoint.Event.onOut);
					$(obj).on("click", {obj:$(obj)}, ctPlayer.CuePoint.Event.onClick);
				});
				for(var i=0; i< cue.points.length; i++) {
					$($(".BrightCoveCT [jClass='cuePointCloseBtn']")[i]).on("click", {obj:$($(".BrightCoveCT [jClass='cuePointCloseBtn']")[i]), idx:i }, ctPlayer.CuePoint.Event.onClick);
				}
			}
		},

		setHtml : function(){
			if(!gConfig.Player.showCuePoint) return;
			var cuePoints = ctPlayer.CuePoint.points;
			var cIdx = CCtCuePoint.Metadata.index;
			var sp = "";
			var s='<div jClass="cuePointItemsBox">';
			for(var i=0; i<cuePoints.length; i++){
				sp += '<div jClass="spotPointer" jBtn="on" jItemIdx="'+i+'"></div>';
				var metadata = cuePoints[i]["metadata"].split('|'); // metadata[4]: overlay or window (new window)
				var tdText = metadata[cIdx.prdtText];
				if(metadata[cIdx.prdtPrice]) {
					if(gConfig.LanguageCode != 'en'){
						tdText += "<br>"+(metadata[cIdx.prdtPrice] != 0 ? (_U.addComma(metadata[cIdx.prdtPrice]) + ' ' +ctLanguage.getMsg({msg:'PriceUnit'})) : '');
					}else{
						tdText += "<br>"+(metadata[cIdx.prdtPrice] != 0 ? ctLanguage.getMsg({msg:'PriceUnit'}) + ' ' +(_U.addComma(metadata[cIdx.prdtPrice])) : '');
					}
				}
				s+= 
				'<div jClass="cuePointItem">'+
					'<table border="0px" cellpadding="0" cellspacing="0" jClass="itemTable">'+
						'<tr><td jClass="tdImg" ><img src="'+metadata[cIdx.thumbnailUrl]+'" /></td>'+
					'</table>'+
					'<div jClass="Cover" jLink="'+metadata[cIdx.targetUrl]+'" jTarget="'+metadata[cIdx.targetMode]+'" jBtn="on" jItemIdx="'+i+'"></div>'+
					'<div jClass="cuePointCloseBtn" jItemIdx="'+i+'"></div>'+
				'</div>';
			}
			s+='</div>';
			$(".BrightCoveCT [jClass='cuePointBox']").html(s);
			$(".BrightCoveCT #brPlayer").append(sp);
			ctPlayer.CuePoint.setCtStyle();
			ctPlayer.CuePoint.Animation.init();
		},
		setCtStyle: function () {
			var item = ctPlayer.Data['item'];
			var playerType ='';
			for(var i=0; i<item['tags'].length; i++){
				if(item['tags'][i].indexOf("cm_player_") == 0){
					playerType = item['tags'][i].substring(item['tags'][i].lastIndexOf("_")+1).toUpperCase();
				}
			}
			_O.Vars.playerType= playerType;
			$(".BrightCoveCT [jClass='cuePointBox']").attr("style",gCtStyle.get(".cuePointBox"));
			if(playerType == 'S'){
				$(".BrightCoveCT [jClass='spotPointer']").attr("style",gCtStyle.get(".spotPointer"));
			}
			$(".BrightCoveCT [jClass='cuePointItemsBox']").attr("style",gCtStyle.get(".cuePointItemsBox"));
			$(".BrightCoveCT [jClass='cuePointItem']").attr("style",gCtStyle.get(".cuePointItem"));
			$(".BrightCoveCT [jClass='cuePointItem'] [jClass='itemTable']").attr("style",gCtStyle.get(".cuePointItem .itemTable"));
			$(".BrightCoveCT [jClass='cuePointItem'] [jClass='Cover']").attr("style",gCtStyle.get(".cuePointItem .Cover"));
			$(".BrightCoveCT [jClass='cuePointItem'] [jClass='itemTable'] [jClass='tdImg']").attr("style",gCtStyle.get(".cuePointItem .itemTable .tdImg"));
			$(".BrightCoveCT [jClass='cuePointItem'] [jClass='itemTable'] [jClass='tdImg'] > img").attr("style",gCtStyle.get(".cuePointItem .itemTable .tdImg > img"));
			$(".BrightCoveCT [jClass='cuePointItem'] [jClass='cuePointCloseBtn']").attr("style",gCtStyle.get(".cuePointItem .cuePointCloseBtn"));
			

			//$(".BrightCoveCT [jClass='cuePointItem'] [jClass='itemTable'] [jClass='tdText']").attr("style",gCtStyle.get(".cuePointItem .itemTable .tdText"));
		},
		getPlayerObject: function (id) {
			var item = ctPlayer.Data['item'];
			var playerType ='';
			for(var i=0; i<item['tags'].length; i++){
				if(item['tags'][i].indexOf("cm_player_") == 0){
					playerType = item['tags'][i].substring(item['tags'][i].lastIndexOf("_")+1).toUpperCase();
				}
			}
			_O.Vars.playerType= playerType;
			var str=
				'<object id="myExperience" class="BrightcoveExperience">'+
					'<param name="wmode" value="opaque"/>'+
					'<param name="bgcolor" value="#FFFFFF" />'+
					'<param name="width" value="'+gConfig.Player.width+'" />'+
					'<param name="height" value="'+gConfig.Player.height+'" />';
					if(playerType == 'C'){
						str+=
						'<param name="playerID" value="'+gConfig.Player.ChromelessPlayerID+'" />'+
						'<param name="playerKey" value="'+gConfig.Player.ChromelessPlayerKey+'" />';
					}else{
						str+=
						'<param name="playerID" value="'+gConfig.Player.SinglePlayerID+'" />'+
						'<param name="playerKey" value="'+gConfig.Player.SinglePlayerKEY+'" />';
					}
					//https code for Facebook app - Sean - 14.Oct.2013
					if(gConfig.Security.protocol=="https"){
						str+=
						'<param name="secureConnections" value="true" />'+
						'<param name="secureHTMLConnections" value="true" />'						
					}
					
					str+=
					'<param name="isVid" value="true" />'+
					'<param name="isUI" value="true" />'+
					'<param name="dynamicStreaming" value="true" />'+
					'<param name="@videoPlayer" value="'+id+'" />'+ 
					'<param name="includeAPI" value="true" />'+ 
					'<param name="templateLoadHandler" value="ctPlayer.Player.playerLoaded" />'+ 
					'<param name="templateReadyHandler" value="ctPlayer.Player.playerReady" />'+ 
				'</object>';
			return str;
		}
	};

	}) (CCtCuePoint); 
}
