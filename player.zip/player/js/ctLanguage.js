
ctLanguage = {

	"en" : {
		"CategoryTitle" : "Category",
		"all"		: "All",
		"women"		: "Women",
		"men"		: "Men",
		"kids"		: "Kids", 
		"family"	: "Family", 
		"gift"		: "Gift", 
		"life"		: "Life",

		"created"	: "Created.",
		"num_play"	: "Play",

		"NoDataAvailable"	: "No Data Available.",

		"PriceUnit"	: "$",

		'SnsCaution' : "Press Ctrl-C<br>copy to clipboard",		
		'naver_blog' : "Publish code for Naver blog",		

		'none': 'none'
	},
	"ko" : {
		"CategoryTitle" : "Category",
		"all"		: "All",
		"women"		: "Women",
		"men"		: "Men",
		"kids"		: "Kids", 
		"family"	: "Family", 
		"gift"		: "Gift", 
		"life"		: "Life",
		
		"created"	: "등록일",
		"num_play"	: "재생회수",
		
		"PriceUnit"	: "원",

		"NoDataAvailable"	: "No Data Available.",

		'SnsCaution' : "선택후  Ctrl-C를<br> 눌러 클립보드로<br>복사하세요.",
		'naver_blog' : "네이버블로그 공유하기",		

		'none': 'none'
	}

};


ctLanguage.getMsg = function (J) { // J.lang, J.msg
	return this[gConfig.LanguageCode][J.msg];
};