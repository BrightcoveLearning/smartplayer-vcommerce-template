
if(!window['ctList']) { 
	ctList = {}; 
	( function (_O) {
		
	_U = jjfw.Util;

	_O.Vars={
		initialPlay:0,
		jParam:{}
	};
	
	_O.init= function() {
	};

	_O.ctPlayer={},
	_O.start= function (J,ctPlayer) { // {vId:vId,ctName:ctName, page:page}

		var v= _O.Vars;
		_O.ctPlayer = ctPlayer;

		if(typeof J.vId== 'undefined' || J.vId == 0) {
			v.initialPlay=1;
		}else{
			v.initialPlay=0;
		}
		v.jParam = J;
		_O.List.load(J);
	};

	_O.jsOnError= function() {
	};

	_O.Item = {
		id:0,
		load:function(J) {//{ vId: , ctName: , page: }
			this.id=J.vId;
			var url='';
			if(this.id) {
				url= ctMain.URL.getFindUrl({vId:vId, callback:"ctList.Item.onLoad"}); // --> loadCategory --> loadList
			}else{
				this.onLoad();
				return;
			}
			_U.jcejs({url:url,fonerror:ctList.jsOnError});
		},
		onLoad: function (J) {
			if(!J) {
				alert("No Data");
				return;
			}
		}
	};

	_O.Paging = {
		page_number: 0,
		page_size:12,
		total_count:0,
		set: function (J) {
			this.page_number= parseInt(J["page_number"],10);
			this.page_size= parseInt(J["page_size"],10);
			this.total_count = parseInt(J["total_count"],10);
		},
		getTotalPageNum: function() {
			return parseInt((this.total_count-1)/this.page_size,10)+1;
		},
		go: function(page) {
			if(page < 0) return;
			else if(page > (this.getTotalPageNum()-1)) return;
			ctMain.reload({
				page:page, 
				ctName:gConfig.Categories.func.getTag(_O.Category.ctIdx),
				id:'',
				query:ctMain.Search.getQuery()
			});
		},
		setHtml: function() {
			var s= '';
			s+= '<div class="leftArrow"> < </div>';
			for(var i=0; i<this.getTotalPageNum(); i++){
				s+=	'<div class="page '+(i==this.page_number ? 'on' : 'off')+'" jIdx="'+(i+1)+'">'+(i+1)+'</div>';
			}
			s+=	'<div class="rightArrow"> > </div>';
			$(".BrightCoveCT .pageBox").html(s);
			$(".BrightCoveCT .pageBox .page.on").css({
				"color":gConfig.SetCss.listPageBoxOnFontColor,
				"background-color":gConfig.SetCss.listPageBoxOnBGColor
			});
			$(".BrightCoveCT .pageBox .page.off").css({
				"color":gConfig.SetCss.listPageBoxOffFontColor,
				"background-color":gConfig.SetCss.listPageBoxOffBGColor
			});
			this.setEvent();
		},
		setEvent: function () {
			$(".pageBox .page").each( function (idx,obj) {
				$(obj).on("click",{page:idx}, function (e) {
						var num  = parseInt($(".pageBox .page").length/2,10);
						ctList.Paging.go((e.data.page%num)); 
				});
			});
		}
	};

	_O.Category = {
		ctIdx:0,
		go: function (ctIdx) {
			ctMain.reload({
				page:0, 
				ctName:gConfig.Categories.func.getTag(ctIdx),
				id:'',
				query:ctMain.Search.getQuery()
			});
		},
		setHtml: function (ctIdx){
			(ctIdx >= 0) ? (this.ctIdx = ctIdx) : (this.ctIdx = 0);
			var s= '';
			var tagsNames= gConfig.Categories.tags;
			s+=
				'<li class="menuTitle">'+
					'<div class="leftMenuTitle">'+ctLanguage.getMsg({"msg":"CategoryTitle"})+'</div>';
			for(var i=0; i<tagsNames.length; i++){
				s +=
					'<li class="menuItem '+(i == ctIdx ? 'menuSelect' : '' )+'">'+
						'<div class="leftMenuItem">'+ctLanguage.getMsg({"msg":tagsNames[i]})+'</div>'+
					'</li>';
			}
			s+=	'</li>';
			$(".BrightCoveCT .left_tabs .menu").html(s);
			$(".BrightCoveCT .left_tabs").css("width",gConfig.Player.width*195/800);
			this.setEvent();
		},
		setEvent: function () {
			$(".BrightCoveCT .menu .menuItem").on("mouseover",function () { 
				$(this).addClass("menuFocus");
			});
			$(".BrightCoveCT .menu .menuItem").on("mouseout",function () { 
				$(this).removeClass("menuFocus"); 
			});
			$(".BrightCoveCT .menu .menuItem").each( function (idx,obj) {
				$(obj).on("click",{ctIdx:idx}, function(e) {
					ctMain.Search.setQuery('');
					ctList.Category.go(e.data.ctIdx); 
				});
			});
			
		}
	};

	_O.List = {
		items: [],
		curId:0,

		load: function (J) {
			if(typeof J.vId != 'undefined' && typeof J.ctName == 'undefined') {
				var url = ctMain.URL.getFindUrl({vId:J.vId,callback:"ctList.List.onLoadItem"});
			}else {
				var url = ctMain.URL.getSearchUrl({page:J.page,callback:"ctList.List.onLoad",ct:J.ctName, query:J.query  });
			}
			 _U.jcejs({url:url,fonerror:ctList.jsOnError});
		},

		onLoadItem: function (J) {
			if(!J) {
				alert("Sorry, Network error. Please try it again later.");
				return;
			}
			var item= J;
			var tags = J['tags'];
			var tag = 'all';
			for(var i=0;i<tags.length;i++) {
				if(tags[i].indexOf("ct_")==0) {
					tag = tags[i].split("_")[1];
					break;
				}
			}
			var url = ctMain.URL.getSearchUrl({page:0,callback:"ctList.List.onLoad",ct:tag, query:J.query  });
			_O.Vars.jParam.ctName = tag;
			 _U.jcejs({url:url,fonerror:ctList.jsOnError});
		},

		onLoad: function (J) {
			if(!J) {
				alert("Sorry, Network error. Please try it again later.");
				return;
			}
			this.items= J["items"];
			if(typeof this.items=='undefined' || this.items.length <= 0) {
				alert(ctLanguage.getMsg({"msg":"NoDataAvailable"}));
				// window.history.back(-1);
				var url = _U.getCookie('BrightcoveBackUrl');
				if(!url) ctMain.reload({page:0,ctName:'all'});
				else document.location.href = url;
				return;
			}
			_O.Paging.set(J);

			ctIdx= gConfig.Categories.func.getIdx(_O.Vars.jParam.ctName);
			this.curId= (_O.Vars.jParam.id ? _O.Vars.jParam.id : (_O.List.items[0] ? _O.List.items[0].id :'')) ;
			(ctIdx >= 0) ? (ctIdx = ctIdx) : (ctIdx = 0);
			_O.Category.setHtml(ctIdx);
			if(this.items.length !=0){
				_O.Paging.setHtml();
				_O.List.setHtml();
				//alert(1);
				if(_O.Vars.initialPlay==1) {
					_O.ctPlayer.start({vId:this.curId});
					_O.Vars.initialPlay=0;
				}
			}else{
				_O.List.setHtml();
			}
		
		},

		go: function(vId) {
			ctMain.reload({
				page:_O.Paging.page_number, 
				ctName:gConfig.Categories.func.getTag(_O.Category.ctIdx),
				id:vId,
				query:ctMain.Search.getQuery()
			});
		},

		setHtml: function () {
			s = '';
			if(this.items.length <= 0){
				s = ctLanguage.getMsg({"msg":"NoDataAvailable"});
			}
			for(i=0; i<this.items.length; i++){
				s+= '<div class="contentItem">'+
						'<div class="itemImg">'+
							'<div class="playImg"></div>'+
							'<div class="timeLength">'+
								'<div class="timeText">'+_U.getMsPlayTimeFormat(this.items[i]['length'])+'</div>'+
							'</div>'+
							((this.curId== this.items[i]["id"]) ?  '<div class="focus"></div>' : '')+
						'</div>'+
						'<div class="name EllipsisText" title="'+this.items[i]["name"]+'">'+this.items[i]["name"]+'</div>'+
					'</div>';
			}
			$('.BrightCoveCT .listBox .list').html(s);
			$(".BrightCoveCT .listBox .list .itemImg").each( function (idx,obj) {
				if(ctList.List.items[idx]["thumbnailURL"]){
					$(obj).css(
						{"backgroundImage":"url("+ctList.List.items[idx]["thumbnailURL"]+")","background-size": gConfig.SetCss.listItemImgWidth+"px "+gConfig.SetCss.listItemImgHeight+"px","background-repeat":"no-repat"}
					);
				}
			});
			this.setConfigCss(gConfig.SetCss);
			this.setEvent();
		},
		setConfigCss:function (J) {
			$(".itemImg .focus").css({
				"border-color":J.selectItemFocusColor,
				"width":J.listItemImgWidth-6,
				"height":J.listItemImgHeight-6
			});
			$(".contentItem .itemImg").css({
				"width":J.listItemImgWidth,
				"height":J.listItemImgHeight
			});
			$(".contentItem .name").css({
				"width":J.listItemImgWidth,
				"height":J.listItemNameHeight,
				"font-size":J.listItemNameFontSize,
				"line-height":J.listItemNameFontLineHeight+'px',
				"color":J.listItemNameFontColor
			});
		},
		setEvent: function () {
			$(".BrightCoveCT .listBox .list .itemImg").each( function (idx, obj) {
				$(obj).on("click",{vIdx:idx}, function(e) {
					ctList.List.go(ctList.List.items[e.data.vIdx]["id"]);
				});
				$(obj).on("mouseover", function() {
					$(obj).find(".playImg").css("opacity","1");
					$(obj).find(".timeLength").css("opacity","1");
				});
				$(obj).on("mouseout", function() {
					$(obj).find(".playImg").css("opacity","0.6");
					$(obj).find(".timeLength").css("opacity","0.6");
				});
			});
		}
	};
		
	}) (ctList); 
}
	