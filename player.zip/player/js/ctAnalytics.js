
if(!window['ctAnalytics']) { 
	ctAnalytics = {}; 
	( function (_O) {

	_U = jjfw.Util;

	_O.TrackPage = {
		view: function (J) {
			var str = "";
			if(J.ctName) str+="/"+J.ctName; else str+="/none";
			if(J.page) str+="/"+J.page; else str+="/0";
			if(J.id) str+="/"+J.id; else str+="/none";
			_gaq.push(['_trackPageview',str]);
		}
	};

	_O.TrackVideo = {
		item:{},
		timeWatched: 0,
		previousTimeStamp: 0,
		previousTime: 0,
		milestones:{},

		init: function (J) {
			this.item = J;
		},

		trackEvent: function (event, data) {
			if(!this.item || this.item.id == null) {
				return;
			}
			var label = "["+this.item.id.toString() + "] " + this.item.name
			var tracking = ['_trackEvent', '상품비디오 재생 통계', event, label];
			if (data) {
				tracking.push(data);
			}
			_gaq.push(tracking);
		},

		handleEvent: function (event) {
			switch(event.type) {
				case 'mediaBegin':
					this.trackEvent("비디오 시작");
					this.previousTimeStamp = new Date().getTime();
					this.timeWatched = 0;
					this.previousTime = 0;
					this.setupMilestones(event);
					break;
				case 'mediaStop':
					//this.trackEvent("비디오 종료");
					break;
				case 'mediaPlay':
					//this.trackEvent("Media Resume");
					break;
				case 'mediaComplete':
					//this.trackEvent("Media Complete", Math.round(timeWatched).toString());
					this.trackEvent("비디오 종료");
					break;
			}
		},

		handleProgress: function (event) {
			this.updateTrackedTime();
			var currentTime = event.position;
			if (currentTime !== this.previousTime) {
				this.checkMilestones(event);
				this.previousTime = currentTime;
			}
		},
		updateTrackedTime: function () {
			var currentTimeStamp = new Date().getTime();
			var timeElapsed = (currentTimeStamp - this.previousTimeStamp) / 1000;
			this.timeWatched += timeElapsed;
			this.previousTimeStamp = currentTimeStamp;
		},

		setupMilestones: function (event) {
			var duration = event.duration;
			this.milestones = {};
			this.milestones[Math.round(duration * 0.25)] = "25% Milestone Passed";
			this.milestones[Math.round(duration * 0.50)] = "50% Milestone Passed";
			this.milestones[Math.round(duration * 0.75)] = "75% Milestone Passed";
		},

		checkMilestones: function (event) {
			var currentTime = event.position;
			if (this.milestones[currentTime]) {
				this.trackEvent(this.milestones[currentTime]);
			}
		}

	};

	_O.TrackAD = {
		item:{},
		init: function (J) {
			this.item = J;
		},
		trackEvent: function (J) { // { id:item['id'],name:cuePoints[J.cueIdx].name,prdtId:metadata[cIdx.prdtId], price:metadata[cIdx.prdtPrice], text:metadata[cIdx.prdtText], targetMode:metadata[cIdx.targetMode], url:J.url }
			if(!J) {
				return;
			}
			if(!this.item || this.item.id == null) {
				return;
			}
			var event='',label ='';
			event = "["+J.name+"] "+J.text;
			label = J.url;
			var tracking = ['_trackEvent', "큐포인트별 클릭 통계", event, label, parseFloat(J.price)];
			_gaq.push(tracking);
			event = J.url;
			label = "["+J.name+"] "+J.text;
			var tracking2 = ['_trackEvent', "상품주소별 클릭 통계", event, label, parseFloat(J.price)];
			_gaq.push(tracking2);
		}
		
	};
	
	}) (ctAnalytics); 
}
