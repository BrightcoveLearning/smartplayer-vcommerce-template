
window["g_br_player_start"] = function () {};
(function(J) {
	
/* // http://closure-compiler.appspot.com/home , advanced. J.d 


window["g_br_player_start"] = function () {};
(function(J) {
var c="x",d=-1,f="js/jquery-1.8.2.js js/jquery.animate-shadow.js js/config.js js/ctStyle.js js/ctLanguage.js js/brObj.js".split(" "),g="";J.w.g_br_player_start=function(a){g=a;c=a.substring(0,a.lastIndexOf("js/api"));j()};
function j(){d++;if(d>=f.length){var a=J.w.jjfw.Util.getUrlParam_Json(g);J.w.ctMain.start({apiBaseUrl:c,id:a.id,ctOff:"off",snsOff:"off",cueData:a.cueData,cueIdx:a.cueIdx,cueType:a.cueType})}else if(-1<f[d].indexOf("jquery-1.8.2")&&"function"==typeof J.w.jQuery)j();else{var b=J.d.createElement("script");b.type="text/javascript";b.src=(0==f[d].indexOf("http")?"":c)+f[d]+"?r="+Math.random();var e,h=J.d;(a=h.getElementsByTagName("head")[0])||(a=h.body.parentNode.appendChild(h.createElement("head")));e=a;e.appendChild(b);
var k=!1;b.onload=b.onreadystatechange=function(){if(!k&&(!this.readyState||"loaded"===this.readyState||"complete"===this.readyState))k=!0,j(),b.onload=b.onreadystatechange=null,e&&b.parentNode&&e.removeChild(b)}}};
})({"d":document,"w":window});
g_br_player_start(window["g_br_api_url"]);

*/



	var apiBaseUrl="x";
	var loadingJSIndex =-1;
	var jsList = [
		"js/jquery-1.8.2.js",
		"js/jquery.animate-shadow.js",
		"js/config.js",
		"js/ctStyle.js",
		"js/ctLanguage.js",
		"js/jjfw.util.js",
		"js/ctList.js",
		"js/ctCuePoint.js",
		"js/ctPlayer.js",
		"js/ctMain.js",
		"js/ctAnalytics.js"
	];

	var p_url='';

	J["w"]["g_br_player_start"] = function(url) {
		// url = http://www.jnjt.co.kr/prj/Brightcove/player_working/js/api.js?id=2014686015001
		p_url = url;
		apiBaseUrl = url.substring(0,url.lastIndexOf("js/api"));
		loadJS();
	};

	function loadJS () {
		loadingJSIndex ++;
		if( loadingJSIndex >= jsList.length) {
			JSLoadingEnd();
			return;
		}
		if(jsList[loadingJSIndex].indexOf("jquery-1.8.2")>-1) {
			if(typeof J["w"]["jQuery"]=='function') {
				loadJS();
				return;
			}
		}
		var s = J["d"].createElement("script"); 
		s.type = "text/javascript"; 
		s.src = (jsList[loadingJSIndex].indexOf("http")==0?'':apiBaseUrl)+jsList[loadingJSIndex]+'?r='+Math.random();
		var head = getHead();
		head.appendChild(s);
		var done = false;
		s.onload = s.onreadystatechange = function() {
			if ( !done && (!this.readyState ||
					this.readyState === "loaded" || this.readyState === "complete") ) {
				done = true;
				loadJS();
				s.onload = s.onreadystatechange = null;
				if ( head && s.parentNode ) {
					head.removeChild( s );
				}
			}
		};
	}
	function JSLoadingEnd () {
		var param = J["w"]["jjfw"]["Util"]["getUrlParam_Json"](p_url);
		J["w"]["ctMain"]["start"]({"apiBaseUrl":apiBaseUrl, "id":param["id"], "ctOff":"off", "snsOff":gConfig.Player.showPubCodeInfoSNS, "playerWrapper":"off", "cueData":param["cueData"],"cueIdx":param["cueIdx"],"cueType":param["cueType"]});
	}

	function getHead () {
		var h, d=J["d"];
		(h = d.getElementsByTagName ("head")[0]) || (h = d.body.parentNode.appendChild (d.createElement ("head")));
		return h;
	}

})({"d":document,"w":window});
g_br_player_start(window["g_br_api_url"]);

